# Christmas Escape — JavaScript

Das gesamte Spiel läuft im Browser mit JavaScript, HTML und CSS.
Kein C++, kein Kompilieren, kein npm und keine zusätzlichen Downloads nötig.

## Dateien

- index.html: Startseite
- game.js: vollständige Spiellogik, alle Modelle, Musik, Missionen und Steuerung
- styles.css: Gestaltung und Handyanpassung

Lass diese drei Dateien im gleichen Ordner. Öffne index.html zum Spielen.

## Auf GitHub Pages veröffentlichen

1. ZIP-Datei auf deinem Computer entpacken.
2. index.html, game.js und styles.css direkt ins Hauptverzeichnis deines GitHub-Repositories hochladen. Die ZIP-Datei selbst wird nicht als Spiel ausgeführt.
3. Die Datei muss exakt index.html heissen (nicht index(6).html).
4. In Settings → Pages unter Source „Deploy from a branch“ auswählen.
5. Branch main und Ordner /(root) wählen und speichern. Falls dein Repository einen anderen Hauptbranch hat, wähle diesen.
6. Nach erfolgreicher Bereitstellung steht die Spieladresse in den Pages-Einstellungen.

Wenn GitHub Pages bereits eingerichtet ist, genügt es, die drei Dateien zu ersetzen.
Die leere Datei .nojekyll ist optional enthalten, um eine unveränderte statische Auslieferung zu verwenden.

Anleitung: https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site

## Steuerung

WASD / Pfeile bewegen, Space springen, F Angriff, P / Esc Pause.
E an Tafel oder Garderobe. V wechselt die 3D-Kamera, L die Taschenlampe.
In Etappe 3: Shift halten zum Rennen und X zum Dashen.
Handys haben Joystick und Aktionstasten. Musik startet nach der ersten Interaktion.
Bonbons und Outfits werden im jeweiligen Browser gespeichert.

Alle bisherigen Spielinhalte und 3D-Modelle sind enthalten.
