(() => {
  let paused=false,pauseRealAt=0,pausedTotal=0,menuView='home';
  function gameNow(){return (paused?pauseRealAt:performance.now())-pausedTotal}

  const canvas = document.getElementById('game');
  const ctx = canvas.getContext('2d');
  const overlay = document.getElementById('overlay');
  const startBtn = document.getElementById('startBtn');
  const hud = document.getElementById('hud');
  const message = document.getElementById('message');
  const stageLabel = document.getElementById('stageLabel');
  const mobileUse = document.getElementById('mobileUse');
  const mobileJump = document.getElementById('mobileJump');
  const mobileAttack = document.getElementById('mobileAttack');
  const mobileHint = document.getElementById('mobileHint');
  // Embedded game configuration. No build step or external services are needed.
const GAME_DATA={"motion":{"walkSpeed":310,"sprintSpeed":465,"mazeSpeed":2.15,"response":[0,0.01192828714,0.02371429024,0.03535970652,0.04686621292,0.05823546642,0.06946910419,0.0805687439,0.09153598393,0.1023724036,0.1130795633,0.1236590049,0.1341122519,0.1444408096,0.1546461653,0.1647297886,0.1746931315,0.1845376288,0.1942646981,0.2038757402,0.2133721389,0.2227552619,0.2320264603,0.2411870692,0.2502384078,0.2591817793,0.2680184718,0.2767497576,0.2853768942,0.2939011238,0.3023236739,0.3106457575,0.3188685728,0.3269933041,0.3350211212,0.3429531802,0.3507906233,0.3585345792,0.3661861629,0.3737464763,0.3812166082,0.3885976342,0.3958906171,0.4030966073,0.4102166424,0.4172517476,0.4242029361,0.4310712088,0.4378575548,0.4445629513,0.4511883639,0.4577347467,0.4642030423,0.4705941823,0.4769090869,0.4831486655,0.4893138166,0.4954054281,0.501424377,0.5073715302,0.513247744,0.5190538647,0.5247907283,0.530459161,0.5360599789,0.5415939887,0.5470619872,0.5524647619,0.5578030907,0.5630777424,0.5682894766,0.5734390437,0.5785271852,0.583554634,0.5885221139,0.5934303403,0.5982800199,0.6030718512,0.6078065241,0.6124847205,0.617107114,0.6216743703,0.6261871471,0.6306460941,0.6350518535,0.6394050598,0.6437063398,0.6479563129,0.6521555911,0.6563047791,0.6604044744,0.6644552673,0.6684577412,0.6724124725,0.6763200306,0.6801809782,0.6839958713,0.6877652593,0.6914896849,0.6951696846,0.6988057881],"gait":[0,0.06082973117,0.121427979,0.1815646357,0.2410123339,0.2995477883,0.3569531052,0.4130170475,0.4675362461,0.5203163478,0.5711730903,0.6199332959,0.6664357769,0.7105321448,0.7520875178,0.790981122,0.8271067812,0.8603732926,0.890704687,0.9180403718,0.9423351562,0.9635591617,0.9816976178,0.9967505475,1.008732346,1.017671259,1.023608764,1.026598862,1.026707292,1.024010671,1.018595565,1.010557513,1,0.9870333994,0.971773888,0.9543423487,0.9348632685,0.9134636448,0.8902719078,0.8654168711,0.8390267188,0.8112280387,0.7821449109,0.7518980583,0.7206040684,0.6883746912,0.6553162197,0.6215289582,0.5871067812,0.5521367876,0.5166990505,0.4808664642,0.4447046891,0.4082721925,0.3716203833,0.334793839,0.2978306186,0.2607626593,0.2236162493,0.1864125715,0.1491683101,0.1118963132,0.07460630169,0.03730561749,9.307315674e-17,-0.03730561749,-0.07460630169,-0.1118963132,-0.1491683101,-0.1864125715,-0.2236162493,-0.2607626593,-0.2978306186,-0.334793839,-0.3716203833,-0.4082721925,-0.4447046891,-0.4808664642,-0.5166990505,-0.5521367876,-0.5871067812,-0.6215289582,-0.6553162197,-0.6883746912,-0.7206040684,-0.7518980583,-0.7821449109,-0.8112280387,-0.8390267188,-0.8654168711,-0.8902719078,-0.9134636448,-0.9348632685,-0.9543423487,-0.971773888,-0.9870333994,-1,-1.010557513,-1.018595565,-1.024010671,-1.026707292,-1.026598862,-1.023608764,-1.017671259,-1.008732346,-0.9967505475,-0.9816976178,-0.9635591617,-0.9423351562,-0.9180403718,-0.890704687,-0.8603732926,-0.8271067812,-0.790981122,-0.7520875178,-0.7105321448,-0.6664357769,-0.6199332959,-0.5711730903,-0.5203163478,-0.4675362461,-0.4130170475,-0.3569531052,-0.2995477883,-0.2410123339,-0.1815646357,-0.121427979,-0.06082973117]},"stealth":{"revealSeconds":8,"coolRate":0.24,"memoryMs":6500},"circuit":[1,0,2],"questions":[{"q":"Eine Firma sagt ab. Was ist dein nächster Schritt?","a":["Rückmeldung erfragen und weiter bewerben","Alle Bewerbungen löschen","Nie mehr nachfragen"],"correct":0},{"q":"Du verstehst eine Aufgabe beim Schnuppern nicht.","a":["Einfach raten","Gezielt nachfragen und zuhören","Den Arbeitsplatz verlassen"],"correct":1},{"q":"Was gehört in ein Bewerbungsdossier?","a":["Nur ein Foto","Nur dein Lieblingsspiel","Lebenslauf, Zeugnisse und Motivationsschreiben"],"correct":2}]};

  function response(dt){const a=GAME_DATA.motion.response;return a[Math.min(100,Math.max(0,Math.round(dt*1000)))];}
  function gait(phase){const a=GAME_DATA.motion.gait;return a[((Math.floor(phase/(Math.PI*2)*a.length)%a.length)+a.length)%a.length]}
  const cosmetics=[
    {id:'classic',name:'Schuljacke',kind:'outfit',price:0,color:'#285b90',scarf:'#dd315b'},
    {id:'red',name:'Winterrot',kind:'outfit',price:6,color:'#b73350',scarf:'#f2c46d'},
    {id:'mint',name:'Polargrün',kind:'outfit',price:8,color:'#248b78',scarf:'#e7f6ef'},
    {id:'violet',name:'Nachtviolett',kind:'outfit',price:10,color:'#8252b1',scarf:'#56e3e7'},
    {id:'gold',name:'Goldjacke',kind:'outfit',price:12,color:'#bd8b2d',scarf:'#513584'},
    {id:'none',name:'Ohne Kopfbedeckung',kind:'hat',price:0,color:'#334050'},
    {id:'beanie',name:'Wintermütze',kind:'hat',price:8,color:'#dd315b'},
    {id:'phones',name:'Kopfhörer',kind:'hat',price:10,color:'#54d8df'}
  ];
  let profile={candies:0,outfit:'classic',hat:'none',owned:['classic','none'],claimed:{}},saveAvailable=true;
  try{
    const raw=JSON.parse(localStorage.getItem('bvj-christmas-profile-v1')||'null');
    if(raw){profile.candies=Number.isFinite(raw.candies)?Math.max(0,Math.floor(raw.candies)):0;
      profile.owned=[...new Set(['classic','none',...(Array.isArray(raw.owned)?raw.owned.filter(id=>cosmetics.some(c=>c.id===id)):[])])];
      if(profile.owned.includes(raw.outfit)&&cosmetics.some(c=>c.id===raw.outfit&&c.kind==='outfit'))profile.outfit=raw.outfit;
      if(profile.owned.includes(raw.hat)&&cosmetics.some(c=>c.id===raw.hat&&c.kind==='hat'))profile.hat=raw.hat;
      if(raw.claimed&&typeof raw.claimed==='object')profile.claimed=Object.fromEntries(Object.keys(raw.claimed).filter(id=>/^candy-|^finish-/.test(id)).map(id=>[id,true]));
    }
  }catch(_){saveAvailable=false}
  function saveProfile(){try{localStorage.setItem('bvj-christmas-profile-v1',JSON.stringify(profile));saveAvailable=true}catch(_){saveAvailable=false}}
  function outfit(){return cosmetics.find(c=>c.id===profile.outfit)||cosmetics[0]}
  function rgb(hex){return [1,3,5].map(i=>parseInt(hex.slice(i,i+2),16)/255)}
  function awardCandy(id,amount=1){
    if(profile.claimed[id])return false;
    profile.claimed[id]=true;profile.candies+=amount;saveProfile();beep(1050,.07);return true;
  }
  function purchaseCosmetic(id){
    const item=cosmetics.find(c=>c.id===id);if(!item)return false;
    if(!profile.owned.includes(id)){if(profile.candies<item.price)return false;profile.candies-=item.price;profile.owned.push(id)}
    profile[item.kind]=id;saveProfile();return true;
  }
  function drawCandy(x,y,scale=1){
    ctx.save();ctx.translate(x,y);ctx.scale(scale,scale);ctx.rotate(Math.sin(gameNow()*.002+x)*.16);
    ctx.fillStyle='#e96eae';ctx.beginPath();ctx.moveTo(-6,0);ctx.lineTo(-13,-7);ctx.lineTo(-13,7);ctx.closePath();ctx.fill();
    ctx.beginPath();ctx.moveTo(6,0);ctx.lineTo(13,-7);ctx.lineTo(13,7);ctx.closePath();ctx.fill();
    ctx.fillStyle='#fff0cf';ctx.beginPath();ctx.ellipse(0,0,8,6,0,0,Math.PI*2);ctx.fill();ctx.fillStyle='#e5559e';ctx.fillRect(-2,-5,4,10);ctx.restore();
  }
  function activeCandies(){return gameStage===1?(state.candies||[]):gameStage===3?(stage3.candies||[]):(gameStage===2||gameStage===0)?(stage2.candies||[]):[]}
  function collectCandies(){
    const px=gameStage===1?player.x+14:gameStage===3?stage3.x+14:stage2.x;
    const py=gameStage===1?player.y+14:gameStage===3?stage3.y+22:stage2.y;
    for(const candy of activeCandies())if(!profile.claimed[candy.id]&&Math.hypot(px-candy.x,py-candy.y)<((gameStage===2||gameStage===0)?.43:27)){
      if(awardCandy(candy.id))showMessage('🍬 Bonbon gesammelt · '+profile.candies,850);
    }
  }
  const W = canvas.width, H = canvas.height;
  const keys = new Set();
  let started = false;
  let finished = false;
  let gameStage = 1; // 1 = klassische 2D-Welt, 2 = 3D-Welt, 3 = Neon-Action
  let levelIndex = 0;
  let startTime = 0;
  let levelStartTime = 0;
  let msgTimer = 0;
  let snow = [];
  let particles = [];
  let collectBursts = [];
  let rulerProjectiles = [];
  let attackUntil = 0;
  let attackStartedAt = 0;
  let lastAttack = 0;
  let playerInvulnerableUntil = 0;

  const player = {
    x: 70, y: 440, w: 28, h: 28,
    speed: 215,
    facing: "down",
    maxHealth: 3,
    health: 3,
    jumpStart: 0,
    jumpUntil: 0,
    lastJump: 0
  };

  function isCompactMobile(){
    return window.matchMedia("(pointer:coarse), (max-width:900px) and (orientation:landscape), (max-width:760px)").matches;
  }

  function updateMobileUI(){
    if(!mobileUse || !mobileJump || !mobileAttack || !mobileHint) return;
    document.getElementById("mobile").dataset.stage=String(gameStage);
    document.getElementById("cameraToggle").style.display=(gameStage===2||gameStage===0)?"block":"none";
    if(gameStage===1){
      mobileUse.dataset.key="KeyE";mobileUse.innerHTML='<span class="ctrl-main">E</span><span class="ctrl-caption">BENUTZEN</span>';mobileUse.style.display="flex";
      mobileJump.style.display="flex";
      mobileAttack.style.display="flex";
      mobileHint.textContent="2D · Pfeile bewegen · E nehmen · ↑ springen · F werfen";
    }else if((gameStage===2||gameStage===0)){
      mobileUse.style.display="flex";mobileUse.dataset.key=gameStage===0?"KeyE":"KeyL";mobileUse.innerHTML=gameStage===0?'<span class="ctrl-main">E</span><span class="ctrl-caption">BENUTZEN</span>':'<span class="ctrl-main">☀</span><span class="ctrl-caption">LAMPE</span>';
      mobileJump.style.display="flex";
      mobileAttack.style.display=gameStage===0?"none":"flex";
      mobileHint.textContent="3D · Joystick laufen · Bild wischen = Kamera · F Abwehr";
    }else{
      mobileUse.style.display="flex";mobileUse.dataset.key="KeyX";mobileUse.innerHTML='<span class="ctrl-main">X</span><span class="ctrl-caption">DASH</span>';
      mobileJump.style.display="flex";
      mobileAttack.style.display="flex";
      mobileHint.textContent="Neon · ←→ laufen · ↑ springen · F Angriff · » Dash";
    }
  }

  const levels = [
    {
      name: "Klassenzimmer",
      subtitle: "Die ersten Schritte",
      bg: "#24325d",
      floor: "#d7d8df",
      start: {x:70,y:440},
      exit: {x:875,y:50,w:45,h:70,label:"WEITER"},
      walls: [
        {x:0,y:0,w:960,h:25},{x:0,y:515,w:960,h:25},{x:0,y:0,w:25,h:540},{x:935,y:0,w:25,h:540},

        // Level 1: breite horizontale Gänge / Zickzack
        {x:120,y:105,w:250,h:24},
        {x:470,y:105,w:210,h:24},
        {x:250,y:225,w:330,h:24},
        {x:90,y:340,w:220,h:24},
        {x:430,y:320,w:260,h:24},
        {x:710,y:110,w:24,h:240}
      ],
      items: [
        {x:195,y:150,label:"Schüler",icon:"🧑‍🎓"},
        {x:650,y:390,label:"Teamwork",icon:"🤝"},
        {x:470,y:410,label:"Mut",icon:"⭐"}
      ],
      enemies: [
        {x:350,y:160,label:"Stress",axis:"x",min:300,max:405,speed:64,dir:1},
        {x:655,y:405,label:"Chaos",axis:"y",min:365,max:475,speed:55,dir:-1}
      ],
      holes: [],
      redButtons: [
        {id:"bridgeButton1",x:250,y:165,targetType:"bridge",targetId:"bridge1",label:"Brücke bauen"}
      ],
      buildSites: [
        {id:"bridge1",x:800,y:440,w:65,h:55,label:"Einziger Übergang",built:false}
      ],
      chasmSegments: [
        {x:800,y:25,w:65,h:415},
        {x:800,y:495,w:65,h:20}
      ],
      jumpBarriers: [{x:25,y:380,w:65,h:14,label:"Sprungstrecke"}],
      signs: [
        {x:55,y:60,text:""}
      ]
    },
    {
      name: "Werkstatt",
      subtitle: "Planen, bauen, verbessern",
      bg: "#172d2b",
      floor: "#d8d2c4",
      start: {x:70,y:455},
      exit: {x:875,y:50,w:45,h:70,label:"WEITER"},
      walls: [
        {x:0,y:0,w:960,h:25},{x:0,y:515,w:960,h:25},{x:0,y:0,w:25,h:540},{x:935,y:0,w:25,h:540},

        // Level 2: senkrechte Werkstatt-Gänge
        {x:165,y:70,w:26,h:220},
        {x:165,y:360,w:26,h:90},
        {x:350,y:150,w:26,h:260},
        {x:535,y:70,w:26,h:220},
        {x:535,y:355,w:26,h:90},
        {x:690,y:155,w:26,h:255}
      ],
      items: [
        {x:230,y:170,label:"Planung",icon:"📐"},
        {x:730,y:325,label:"Technik",icon:"⚙️"},
        {x:480,y:445,label:"Geduld",icon:"🔧"}
      ],
      enemies: [
        {x:380,y:455,label:"Fehler",axis:"x",min:365,max:430,speed:72,dir:1},
        {x:570,y:175,label:"Zeitdruck",axis:"y",min:145,max:220,speed:62,dir:1},
        {x:860,y:320,label:"Stress",axis:"y",min:290,max:455,speed:50,dir:-1}
      ],
      holes: [],
      redButtons: [
        {id:"bridgeButton2",x:650,y:130,targetType:"bridge",targetId:"bridge2",label:"Brücke bauen"}
      ],
      buildSites: [
        {id:"bridge2",x:800,y:440,w:65,h:55,label:"Einziger Übergang",built:false}
      ],
      chasmSegments: [
        {x:800,y:25,w:65,h:415},
        {x:800,y:495,w:65,h:20}
      ],
      jumpBarriers: [{x:25,y:335,w:140,h:14,label:"Sprungstrecke"}],
      signs: [
        {x:55,y:55,text:"In der Werkstatt gilt: planen → bauen → testen → verbessern."}
      ]
    },
    {
      name: "Lehrstelle",
      subtitle: "Das Ziel rückt näher",
      bg: "#3a274b",
      floor: "#d9d6e0",
      start: {x:65,y:445},
      exit: {x:870,y:45,w:50,h:82,label:"🎄 ZIEL"},
      walls: [
        {x:0,y:0,w:960,h:25},{x:0,y:515,w:960,h:25},{x:0,y:0,w:25,h:540},{x:935,y:0,w:25,h:540},

        // Level 3: unregelmäßiges Bewerbungs-Labyrinth
        {x:95,y:95,w:210,h:26},
        {x:385,y:75,w:260,h:26},
        {x:235,y:205,w:240,h:26},
        {x:555,y:215,w:190,h:26},
        {x:95,y:325,w:250,h:26},
        {x:430,y:340,w:280,h:26},
        {x:360,y:125,w:26,h:210}
      ],
      items: [
        {x:620,y:155,label:"Dossier",icon:"📄"},
        {x:690,y:285,label:"Schnuppern",icon:"👀"},
        {x:480,y:455,label:"Lehrstelle",icon:"🎓"}
      ],
      enemies: [
        {x:430,y:145,label:"Absage",axis:"y",min:120,max:174,speed:60,dir:1},
        {x:620,y:455,label:"Nervosität",axis:"x",min:540,max:830,speed:67,dir:-1},
        {x:875,y:185,label:"Deadline",axis:"y",min:140,max:360,speed:54,dir:1}
      ],
      holes: [],
      redButtons: [
        {id:"bridgeButton3",x:150,y:250,targetType:"bridge",targetId:"bridge3",label:"Brücke bauen"}
      ],
      buildSites: [
        {id:"bridge3",x:800,y:440,w:65,h:55,label:"Einziger Übergang",built:false}
      ],
      chasmSegments: [
        {x:800,y:25,w:65,h:415},
        {x:800,y:495,w:65,h:20}
      ],
      jumpBarriers: [{x:25,y:370,w:70,h:14,label:"Sprungstrecke"}],
      signs: [
        {x:55,y:55,text:"Fast geschafft! Sammle die letzten drei Stationen deines Weges."}
      ]
    }
  ];

  let state = null;

  function cloneLevel(i){
    const src = levels[i];
    return {
      ...src,
      walls: src.walls.map(o=>({...o})),
      items: src.items.map((o,idx)=>({
        ...o,
        baseX:o.x, baseY:o.y,
        phase:idx*2.1 + i*.7,
        collected:false
      })),
      enemies: (src.enemies||[]).map((o,idx)=>({
        ...o,
        w:30, h:30,
        hp:2,
        maxHp:2,
        defeated:false,
        hitFlashUntil:0,
        deformUntil:0,
        hitDirX:0,
        hitDirY:0,
        dent:0,
        phase:idx*1.4,
        chasing:false,
        sawPlayerUntil:0,
        lastSeenX:o.x,
        lastSeenY:o.y
      })),
      holes: (src.holes||[]).map((o,idx)=>({
        ...o,
        repaired:false,
        phase:idx*1.7+i*.5,
        lastDamageAt:0
      })),
      redButtons: (src.redButtons||[]).map(o=>({
        ...o,
        pressed:false,
        pulse:0
      })),
      buildSites: (src.buildSites||[]).map(o=>({...o,built:false})),
      chasmSegments: (src.chasmSegments||[]).map(o=>({...o})),
      jumpBarriers: (src.jumpBarriers||[]).map(o=>({...o})),
      signs: src.signs.map(o=>({...o}))
    };
  }

  function resetLevel(){
    state = cloneLevel(levelIndex);
    initSchoolMission();
    state.candies=[...state.items.map(i=>({x:i.x,y:i.y})),{x:state.start.x+35,y:state.start.y},{x:state.exit.x+12,y:state.exit.y+40}].map((c,i)=>({...c,id:'candy-school-'+levelIndex+'-'+i}));
    for(const enemy of state.enemies) freeEnemyFromWall(enemy);
    player.x = state.start.x;
    player.y = state.start.y;
    player.facing = "down";
    player.health = player.maxHealth;
    player.jumpStart = 0;
    player.jumpUntil = 0;
    player.lastJump = 0;
    attackUntil = 0;
    lastAttack = 0;
    playerInvulnerableUntil = 0;
    particles = [];
    collectBursts = [];
    rulerProjectiles = [];
    levelStartTime = gameNow();
    showMessage(`${state.name}: ${state.subtitle}`, 1800);
  }

  function rectsOverlap(a,b){
    return a.x < b.x+b.w && a.x+a.w > b.x && a.y < b.y+b.h && a.y+a.h > b.y;
  }

  function isJumping(now=gameNow()){
    return now < player.jumpUntil;
  }

  function jumpHeight(now=gameNow()){
    if(!isJumping(now) || player.jumpUntil<=player.jumpStart) return 0;
    const p=(now-player.jumpStart)/(player.jumpUntil-player.jumpStart);
    return Math.sin(Math.PI*Math.max(0,Math.min(1,p)))*24;
  }

  function jump(){
    if(!started || finished) return;
    const now=gameNow();
    if(now-player.lastJump<760 || isJumping(now)) return;
    player.lastJump=now;
    player.jumpStart=now;
    player.jumpUntil=now+620;
    effect('jump');
  }

  function setFacingFromVector(dx,dy){
    if(dx===0 && dy===0) return;
    if(dx>0 && dy<0) player.facing="up-right";
    else if(dx<0 && dy<0) player.facing="up-left";
    else if(dx>0 && dy>0) player.facing="down-right";
    else if(dx<0 && dy>0) player.facing="down-left";
    else if(dx>0) player.facing="right";
    else if(dx<0) player.facing="left";
    else if(dy<0) player.facing="up";
    else if(dy>0) player.facing="down";
  }

  function facingVector(){
    const d=Math.SQRT1_2;
    const map={
      "right":[1,0], "left":[-1,0], "up":[0,-1], "down":[0,1],
      "up-right":[d,-d], "up-left":[-d,-d],
      "down-right":[d,d], "down-left":[-d,d]
    };
    return map[player.facing] || [0,1];
  }

  function movePlayer(dx,dy,dt){
    const stepX = dx * player.speed * dt;
    const stepY = dy * player.speed * dt;

    const missingBridges=(state.buildSites||[])
      .filter(s=>!s.built)
      .map(s=>({x:s.x,y:s.y,w:s.w,h:s.h}));

    const chasmBlocks=(state.chasmSegments||[]).map(s=>({...s}));

    // Der Abgrund bleibt immer fest. Die Sprungstrecke blockiert nur,
    // solange der Held nicht springt.
    const blockers = isJumping()
      ? state.walls.concat(chasmBlocks, missingBridges)
      : state.walls.concat(state.jumpBarriers||[], chasmBlocks, missingBridges);

    // X-Achse:
    // Nur dann an die Seitenkante setzen, wenn der Held die Kante wirklich
    // von außen betritt. So wird er bei diagonaler Bewegung nicht mehr
    // plötzlich bis zum Rand eines langen Hindernisses "teleportiert".
    if(stepX!==0){
      const oldX=player.x;
      const oldLeft=oldX;
      const oldRight=oldX+player.w;

      player.x += stepX;

      for(const w of blockers){
        if(!rectsOverlap(player,w)) continue;

        if(stepX>0 && oldRight<=w.x){
          player.x=w.x-player.w;
        }else if(stepX<0 && oldLeft>=w.x+w.w){
          player.x=w.x+w.w;
        }
      }
    }

    // Y-Achse:
    // Dasselbe Prinzip oben/unten. Besonders wichtig für die horizontale
    // Sprungstrecke: sie stoppt den Spieler sauber, ohne seine X-Position
    // zu verändern.
    if(stepY!==0){
      const oldY=player.y;
      const oldTop=oldY;
      const oldBottom=oldY+player.h;

      player.y += stepY;

      for(const w of blockers){
        if(!rectsOverlap(player,w)) continue;

        if(stepY>0 && oldBottom<=w.y){
          player.y=w.y-player.h;
        }else if(stepY<0 && oldTop>=w.y+w.h){
          player.y=w.y+w.h;
        }
      }
    }

    // Zusätzliche Sicherheitsbegrenzung für den Spielfeldrand.
    player.x=Math.max(25,Math.min(W-25-player.w,player.x));
    player.y=Math.max(25,Math.min(H-25-player.h,player.y));
  }

  function centerDist(a,b){
    const ax=a.x+a.w/2, ay=a.y+a.h/2;
    const bx=b.x+(b.w||0)/2, by=b.y+(b.h||0)/2;
    return Math.hypot(ax-bx,ay-by);
  }

  function pointInRect(px,py,r){
    return px>=r.x && px<=r.x+r.w && py>=r.y && py<=r.y+r.h;
  }

  function hasClearInteractionPath(targetX,targetY){
    const startX=player.x+player.w/2;
    const startY=player.y+player.h/2;

    const missingBridges=(state.buildSites||[])
      .filter(s=>!s.built)
      .map(s=>({x:s.x,y:s.y,w:s.w,h:s.h}));

    const blockers=[
      ...state.walls,
      ...(state.chasmSegments||[]),
      ...missingBridges
    ];

    const dist=Math.hypot(targetX-startX,targetY-startY);
    const steps=Math.max(1,Math.ceil(dist/5));

    for(let i=1;i<steps;i++){
      const t=i/steps;
      const x=startX+(targetX-startX)*t;
      const y=startY+(targetY-startY)*t;
      if(blockers.some(r=>pointInRect(x,y,r))){
        return false;
      }
    }
    return true;
  }

  function collectedCount(){
    return state.items.filter(i=>i.collected).length;
  }

  function showMessage(text,ms=1200){
    message.textContent=text;
    message.classList.add('show');
    clearTimeout(msgTimer);
    msgTimer=setTimeout(()=>message.classList.remove('show'),ms);
  }

  // Procedural soundtrack: no downloads, audio starts only after a user gesture.
  const sound={ctx:null,music:true,fx:true,next:0,beat:0,stage:0,lastStep:0};
  function unlockAudio(){
    try{
      if(!sound.ctx){
        sound.ctx=new (window.AudioContext||window.webkitAudioContext)();
        sound.musicBus=sound.ctx.createGain();sound.fxBus=sound.ctx.createGain();
        sound.musicBus.gain.value=sound.music?.17:0;
        sound.fxBus.gain.value=sound.fx?.35:0;
        sound.musicBus.connect(sound.ctx.destination);sound.fxBus.connect(sound.ctx.destination);
      }
      if(sound.ctx.state==='suspended') sound.ctx.resume().catch(()=>{});
    }catch(_){}
  }
  function tone(freq,dur=.12,type='sine',volume=.2,delay=0,music=false,endFreq=null){
    const ac=sound.ctx;if(!ac||ac.state!=='running')return;
    const t=ac.currentTime+delay,o=ac.createOscillator(),g=ac.createGain();
    o.type=type;o.frequency.setValueAtTime(freq,t);
    if(endFreq)o.frequency.exponentialRampToValueAtTime(endFreq,t+dur);
    g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(volume,t+.008);
    g.gain.exponentialRampToValueAtTime(.0001,t+dur);
    o.connect(g);g.connect(music?sound.musicBus:sound.fxBus);o.start(t);o.stop(t+dur+.02);
    o.onended=()=>{o.disconnect();g.disconnect()};
  }
  function beep(freq=620,dur=.08){
    tone(freq,dur,freq<220?'triangle':'sine',.24,0,false,freq<220?70:null);
    if(freq>=720)tone(freq*1.5,dur+.08,'sine',.13,.06);
  }
  function effect(kind){
    if(kind==='jump')tone(260,.22,'triangle',.22,0,false,780);
    if(kind==='attack')tone(600,.14,'sawtooth',.10,0,false,100);
    if(kind==='step')tone(95,.045,'triangle',.10,0,false,45);
    if(kind==='alert'){tone(330,.16,'square',.08);tone(440,.16,'square',.08,.18)}
    if(kind==='win')[523,659,784,1047].forEach((f,i)=>tone(f,.4,'sine',.22,i*.13));
  }
  function technoHat(delay,open=false,clap=false){
    const ac=sound.ctx;if(!ac||ac.state!=='running')return;
    if(!sound.noise){sound.noise=ac.createBuffer(1,Math.ceil(ac.sampleRate*.25),ac.sampleRate);
      const data=sound.noise.getChannelData(0);for(let i=0;i<data.length;i++)data[i]=Math.random()*2-1;}
    const src=ac.createBufferSource(),filter=ac.createBiquadFilter(),gain=ac.createGain();
    src.buffer=sound.noise;filter.type='highpass';filter.frequency.value=clap?1200:6500;
    const t=ac.currentTime+delay,dur=clap?.12:open?.16:.035;
    gain.gain.setValueAtTime(clap?.24:open?.13:.08,t);gain.gain.exponentialRampToValueAtTime(.0001,t+dur);
    src.connect(filter);filter.connect(gain);gain.connect(sound.musicBus);src.start(t);src.stop(t+dur);
    src.onended=()=>{src.disconnect();filter.disconnect();gain.disconnect()};
  }
  function technoSynth(midi,delay,bright=false){
    const ac=sound.ctx;if(!ac||ac.state!=='running')return;
    const osc=ac.createOscillator(),filter=ac.createBiquadFilter(),gain=ac.createGain(),t=ac.currentTime+delay;
    osc.type='sawtooth';osc.frequency.value=440*2**((midi-69)/12);
    filter.type='lowpass';filter.Q.value=bright?3:5;
    filter.frequency.setValueAtTime(bright?2600:1100,t);filter.frequency.exponentialRampToValueAtTime(bright?600:130,t+.14);
    gain.gain.setValueAtTime(.0001,t);gain.gain.exponentialRampToValueAtTime(bright?.10:.22,t+.008);
    gain.gain.exponentialRampToValueAtTime(.0001,t+.17);
    osc.connect(filter);filter.connect(gain);gain.connect(sound.musicBus);osc.start(t);osc.stop(t+.19);
    osc.onended=()=>{osc.disconnect();filter.disconnect();gain.disconnect()};
  }
  function updateAudio(now){
    if(!sound.ctx)return;
    const active=started&&!paused&&!finished&&!document.hidden;
    sound.musicBus.gain.setTargetAtTime(active&&sound.music?.17:0,sound.ctx.currentTime,.08);
    if(!active){sound.next=sound.ctx.currentTime;return}
    if(sound.stage!==gameStage){sound.stage=gameStage;sound.beat=0;sound.next=sound.ctx.currentTime}
    const ac=sound.ctx,bpm=gameStage===3?140:(gameStage===2||gameStage===0)?112:124,step=60/bpm/4;
    if(sound.next<ac.currentTime-.1)sound.next=ac.currentTime;
    const lead={1:[76,0,79,0,76,0,72,74,76,0,79,0,77,76,74,0],2:[64,0,0,71,0,67,0,0,62,0,0,69,0,67,0,0],3:[76,79,83,79,74,79,81,79,76,79,84,83,74,79,81,83]};
    while(sound.next<ac.currentTime+.12){
      const tick=sound.beat%16,bar=Math.floor(sound.beat/16),delay=Math.max(0,sound.next-ac.currentTime);
      if(gameStage!==3){
        if(gameStage===1||gameStage===0){
          const melody=[76,79,83,79,74,78,81,78,72,76,79,76,74,78,81,86];
          if(tick%2===0){const n=melody[(tick/2+bar*8)%16];tone(440*2**((n-69)/12),.26,'sine',.28,delay,true);tone(440*2**((n-57)/12),.12,'sine',.045,delay+.04,true)}
          if(tick%4===0)tone(120,.17,'sine',.62,delay,true,45);
          if(tick%4===2)technoHat(delay);
          if(tick===4||tick===12)technoHat(delay,false,true);
          if(tick%4===2)technoSynth([40,36,43,38][bar%4],delay);
        }else{
          const arp=[52,59,64,67,50,57,62,65];
          if(tick%2===0)technoSynth(arp[(tick/2+bar*2)%8],delay,true);
          if(tick===0||tick===10)tone(105,.24,'sine',.68,delay,true,34);
          if(tick===4||tick===12)technoHat(delay,false,true);
          if(tick%4===3)technoHat(delay);
          if(tick===0)tone([82.41,65.41,73.42,61.74][bar%4],.8,'triangle',.24,delay,true);
        }
        sound.beat++;sound.next+=step;continue;
      }
      const root=[40,40,36,38][Math.floor(bar/2)%4];
      // Four-on-the-floor kick, offbeat hats, clap on beats two and four.
      if(tick%4===0){tone(145,.20,'sine',.85,delay,true,43);tone(1000,.018,'triangle',.14,delay,true,150)}
      if(tick%2===0)technoHat(delay,tick%4===2);
      if(tick===4||tick===12)technoHat(delay,false,true);
      if(tick%4===2||tick%4===3)technoSynth(root+(tick%4===3?12:0),delay);
      const note=lead[gameStage][tick];
      if(note&&(bar%4!==3||tick<12))technoSynth(note,delay,true);
      if(bar%4===3&&tick>=12)technoHat(delay,false,false);
      sound.beat++;sound.next+=step;
    }
    const moving=['KeyW','KeyS','KeyA','KeyD','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].some(k=>keys.has(k));
    if(moving&&now-sound.lastStep>330&&(gameStage!==3||stage3.onGround)){
      effect('step');sound.lastStep=now;
    }
  }
  for(const [id,key] of [['musicToggle','music'],['fxToggle','fx']]){
    document.getElementById(id).onclick=()=>{
      unlockAudio();sound[key]=!sound[key];
      document.getElementById(id).setAttribute('aria-pressed',String(sound[key]));
      document.getElementById(id).textContent=(key==='music'?'♫ Musik':'♪ Geräusche')+(sound[key]?'':' aus');
      if(sound.ctx)sound.fxBus.gain.value=sound.fx?.35:0;
    };
  }
  document.addEventListener('visibilitychange',()=>{
    if(document.hidden&&started&&!paused&&!finished)openGameMenu();
    keys.clear();if(sound.ctx){if(document.hidden)sound.ctx.suspend();else sound.ctx.resume().catch(()=>{})}
  });


  function burst(x,y,color="#f0c85b",count=16){
    for(let i=0;i<count;i++){
      const a=Math.random()*Math.PI*2;
      const sp=45+Math.random()*105;
      particles.push({
        x,y,
        vx:Math.cos(a)*sp,
        vy:Math.sin(a)*sp,
        life:.45+Math.random()*.35,
        maxLife:.8,
        r:2+Math.random()*3,
        color
      });
    }
  }

  function updateParticles(dt){
    for(const p of particles){
      p.x += p.vx*dt;
      p.y += p.vy*dt;
      p.vy += 80*dt;
      p.life -= dt;
    }
    particles = particles.filter(p=>p.life>0);

    for(const b of collectBursts) b.t += dt;
    collectBursts = collectBursts.filter(b=>b.t<.5);
  }

  function updateMovingItems(now){
    const t=now/1000;
    for(const item of state.items){
      if(item.collected) continue;
      const ampX=7, ampY=5;
      item.x = item.baseX + Math.sin(t*1.4 + item.phase)*ampX;
      item.y = item.baseY + Math.cos(t*1.7 + item.phase)*ampY;
    }
  }

  function holesClosed(){
    return (state.holes||[]).filter(h=>h.repaired).length;
  }

  function updateHoles(now){
    if(isJumping(now)) return;
    for(const h of state.holes||[]){
      if(h.repaired) continue;
      const hit={x:h.x-h.r*.78,y:h.y-h.r*.50,w:h.r*1.56,h:h.r};
      if(rectsOverlap(player,hit) && now-h.lastDamageAt>1000){
        h.lastDamageAt=now;
        player.health=Math.max(0,player.health-1);
        playerInvulnerableUntil=now+850;
        burst(h.x,h.y,"#563c31",14);
        beep(150,.1);
        player.x=Math.max(30,player.x-34);
        player.y=Math.min(H-60,player.y+32);

        if(player.health<=0){
          showMessage("Du bist ins Loch gefallen! Das Level startet neu.",1200);
          setTimeout(()=>{ if(started && !finished) resetLevel(); },850);
        }else{
          showMessage(`Ins Loch gefallen! Noch ${player.health} ${player.health===1?"Herz":"Herzen"}. Springen mit Leertaste!`,1200);
        }
      }
    }
  }

  function activateNearbyButton(){
    for(const b of state.redButtons||[]){
      const bb={x:b.x-18,y:b.y-18,w:36,h:36};
      if(centerDist(player,bb)>=64) continue;

      if(!hasClearInteractionPath(b.x,b.y)){
        showMessage("Die Wand ist im Weg – geh auf die andere Seite.",900);
        return true;
      }

      if(b.pressed){
        showMessage("Diese rote Taste wurde schon benutzt.",750);
        return true;
      }

      b.pressed=true;
      b.pulse=gameNow();
      burst(b.x,b.y,"#ff4b4b",16);
      beep(720,.08);
      if(b.targetType==="bridge"){
        const site=(state.buildSites||[]).find(s=>s.id===b.targetId);
        if(site){
          site.built=true;
          burst(site.x+site.w/2,site.y+site.h/2,"#7dcf88",28);
          showMessage("Brücke gebaut! Unten ist jetzt der einzige freie Durchgang zum Finish. 🌉",1300);
          beep(980,.15);
        }
      }

      return true;
    }
    return false;
  }

  function bridgeBuilt(){
    const sites=state.buildSites||[];
    return sites.length===0 || sites.every(s=>s.built);
  }

  function enemyBlockers(){
    const missingBridges=(state.buildSites||[])
      .filter(s=>!s.built)
      .map(s=>({x:s.x,y:s.y,w:s.w,h:s.h}));

    return [
      ...state.walls,
      ...(state.chasmSegments||[]),
      ...missingBridges,
      ...(state.jumpBarriers||[])
    ];
  }

  function enemyBlockedAt(e,x,y){
    const box={x,y,w:e.w,h:e.h};
    return enemyBlockers().some(w=>rectsOverlap(box,w));
  }

  function enemyVisionBlockers(){
    const missingBridges=(state.buildSites||[])
      .filter(s=>!s.built)
      .map(s=>({x:s.x,y:s.y,w:s.w,h:s.h}));

    // Niedrige Sprunghindernisse blockieren die Sicht nicht,
    // aber Wände und der Abgrund schon.
    return [
      ...state.walls,
      ...(state.chasmSegments||[]),
      ...missingBridges
    ];
  }

  function clearLineBetween(x1,y1,x2,y2,blockers){
    const dist=Math.hypot(x2-x1,y2-y1);
    const steps=Math.max(1,Math.ceil(dist/6));

    for(let i=1;i<steps;i++){
      const t=i/steps;
      const x=x1+(x2-x1)*t;
      const y=y1+(y2-y1)*t;

      if(blockers.some(r=>pointInRect(x,y,r))){
        return false;
      }
    }
    return true;
  }

  function enemyCanSeePlayer(e){
    const ex=e.x+e.w/2;
    const ey=e.y+e.h/2;
    const px=player.x+player.w/2;
    const py=player.y+player.h/2;

    // Sichtweite des Feindes
    if(Math.hypot(px-ex,py-ey)>245) return false;

    return clearLineBetween(ex,ey,px,py,enemyVisionBlockers());
  }

  function freeEnemyFromWall(e){
    if(!enemyBlockedAt(e,e.x,e.y))return;
    // Recover to the closest free position if level data or knockback overlap a wall.
    for(let radius=2;radius<=960;radius+=2){
      for(const [dx,dy] of [[0,-1],[0,1],[-1,0],[1,0],[-1,-1],[1,-1],[-1,1],[1,1]]){
        const x=e.x+dx*radius,y=e.y+dy*radius;
        if(x>=25&&y>=25&&x+e.w<=935&&y+e.h<=515&&!enemyBlockedAt(e,x,y)){
          e.x=x;e.y=y;return;
        }
      }
    }
  }

  function updateEnemies(dt, now){
    for(const e of state.enemies){
      if(e.defeated) continue;

      freeEnemyFromWall(e);
      // Wenn der Feind den Helden ohne Wand dazwischen sieht,
      // merkt er sich die Position kurz und beginnt zu verfolgen.
      if(enemyCanSeePlayer(e)){
        e.chasing=true;
        e.sawPlayerUntil=now+1200;
        e.lastSeenX=player.x;
        e.lastSeenY=player.y;
      }else if(now>e.sawPlayerUntil){
        e.chasing=false;
      }

      if(e.chasing){
        const targetX=e.lastSeenX;
        const targetY=e.lastSeenY;
        const dx=targetX-e.x;
        const dy=targetY-e.y;
        const len=Math.hypot(dx,dy)||1;
        const chaseSpeed=Math.max(105,e.speed*1.65);
        const stepX=(dx/len)*chaseSpeed*dt;
        const stepY=(dy/len)*chaseSpeed*dt;

        // X und Y getrennt bewegen, damit der Feind an Wänden entlanggleiten
        // kann, aber niemals durch sie hindurchläuft.
        const nextX=e.x+stepX;
        if(!enemyBlockedAt(e,nextX,e.y)){
          e.x=nextX;
        }

        const nextY=e.y+stepY;
        if(!enemyBlockedAt(e,e.x,nextY)){
          e.y=nextY;
        }
      }else if(e.axis==="x"){
        let nextX=e.x + e.speed*e.dir*dt;

        if(nextX<e.min){
          if(e.x>=e.min)nextX=e.min;
          e.dir=1;
        }else if(nextX>e.max){
          if(e.x<=e.max)nextX=e.max;
          e.dir=-1;
        }

        if(enemyBlockedAt(e,nextX,e.y)){
          e.dir*=-1;
        }else{
          e.x=nextX;
        }
      }else{
        let nextY=e.y + e.speed*e.dir*dt;

        if(nextY<e.min){
          if(e.y>=e.min)nextY=e.min;
          e.dir=1;
        }else if(nextY>e.max){
          if(e.y<=e.max)nextY=e.max;
          e.dir=-1;
        }

        if(enemyBlockedAt(e,e.x,nextY)){
          e.dir*=-1;
        }else{
          e.y=nextY;
        }
      }

      // Kontakt mit Feind: 1 Herz Schaden + kurzer Rückstoß.
      if(!isJumping(now) && now > playerInvulnerableUntil && rectsOverlap(player,e)){
        playerInvulnerableUntil = now + 950;
        player.health = Math.max(0, player.health - 1);

        const px=player.x+player.w/2, py=player.y+player.h/2;
        const ex=e.x+e.w/2, ey=e.y+e.h/2;
        const dx=px-ex, dy=py-ey;
        const len=Math.hypot(dx,dy)||1;
        player.x += (dx/len)*24;
        player.y += (dy/len)*24;
        player.x=Math.max(26,Math.min(W-26-player.w,player.x));
        player.y=Math.max(26,Math.min(H-26-player.h,player.y));

        burst(px,py,"#e06464",14);
        beep(170,.1);

        if(player.health <= 0){
          showMessage("Keine Herzen mehr! Das Level startet neu.",1300);
          setTimeout(()=>{
            if(started && !finished) resetLevel();
          }, 900);
        }else{
          showMessage(`Autsch! Noch ${player.health} ${player.health===1?"Herz":"Herzen"}.`,950);
        }
      }
    }
  }


  function updateProjectiles(dt){
    for(const p of rulerProjectiles){
      if(!p.alive) continue;

      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.rot += p.rotSpeed * dt;
      p.life -= dt;

      // Wandkollision / Lebenszeit
      if(
        p.life <= 0 ||
        p.x < 20 || p.x > W-20 || p.y < 20 || p.y > H-20 ||
        state.walls.some(w => rectsOverlap({x:p.x-18,y:p.y-4,w:36,h:8}, w))
      ){
        p.alive = false;
        burst(p.x,p.y,"#f0c85b",8);
        continue;
      }

      // Treffer auf Feinde
      for(const e of state.enemies){
        if(e.defeated || !p.alive) continue;
        const hitbox = {x:p.x-18,y:p.y-6,w:36,h:12};
        if(rectsOverlap(hitbox,e)){
          p.alive = false;
          e.hp -= 1;
          const hitNow=gameNow();
          e.hitFlashUntil=hitNow+180;

          // Treffer verformt den Feind sichtbar.
          const hitLen=Math.hypot(p.vx,p.vy)||1;
          e.hitDirX=p.vx/hitLen;
          e.hitDirY=p.vy/hitLen;
          e.deformUntil=hitNow+340;
          e.dent=Math.min(1,e.dent+0.55);

          const knock=18;
          const knockX=e.x + Math.sign(p.vx||0)*knock;
          const knockY=e.y + Math.sign(p.vy||0)*knock;

          // Auch der Rückstoß darf den Feind nicht durch eine Wand schieben.
          if(!enemyBlockedAt(e,knockX,e.y)) e.x=knockX;
          if(!enemyBlockedAt(e,e.x,knockY)) e.y=knockY;

          burst(e.x+e.w/2,e.y+e.h/2,"#f0c85b",14);
          beep(e.hp<=0?760:560,.08);

          if(e.hp<=0){
            e.defeated=true;
            burst(e.x+e.w/2,e.y+e.h/2,"#ffffff",22);
            showMessage(`${e.label} besiegt!`,850);
          }else{
            showMessage(`${e.label} getroffen – und deformiert! Noch 1 Treffer.`,850);
          }
        }
      }
    }

    rulerProjectiles = rulerProjectiles.filter(p => p.alive);
  }

  function attack(){
    if(!started || finished) return;
    const now=gameNow();
    if(now-lastAttack<280) return;
    lastAttack=now;
    attackStartedAt=now;
    attackUntil=now+120;
    effect('attack');

    const [dx,dy]=facingVector();
    const angle=Math.atan2(dy,dx);

    rulerProjectiles.push({
      x: player.x + player.w/2 + dx*18,
      y: player.y + player.h/2 + dy*18,
      vx: dx*430,
      vy: dy*430,
      rot: angle,
      rotSpeed: 10,
      life: 1.3,
      alive: true
    });
  }

  function aliveEnemies(){
    return state.enemies.filter(e=>!e.defeated).length;
  }

  function initSchoolMission(){
    const titles=['Werkstatt · Stromausfall','Transport · Rettungsdrohne','Bewerbung · Dein Gespräch'];
    state.name=titles[levelIndex];state.subtitle=['Finde die Schalttafel und repariere die Stromversorgung.','Starte die Drohne mit E und begleite sie sicher zum Ausgang.','Finde das Gesprächspult und beantworte drei Fragen.'][levelIndex];
    state.mission={done:false,step:0,drone:null,trail:[],active:false};
    state.items=state.items.slice(0,1);state.items[0].label=['Schalttafel','Rettungsdrohne','Gesprächspult'][levelIndex];state.items[0].icon=['⚡','🤖','💬'][levelIndex];
  }
  function schoolInteract(){
    const m=state.mission;if(!m||m.done)return true;
    const item=state.items[0];
    if(levelIndex===1&&m.active){showMessage('Führe die Drohne zum Ausgang. Bleibe in ihrer Nähe.',1500);return true;}
    if(Math.hypot(player.x+14-item.x,player.y+14-item.y)>62||!hasClearInteractionPath(item.x,item.y))return true;
    if(levelIndex===1){m.active=true;m.drone={x:player.x+14,y:player.y+14};m.trail=[];item.collected=true;showMessage('Drohne gestartet! Führe sie zum Ausgang und baue die Brücke.',2300);return true;}
    showSchoolTask();return true;
  }
  function completeSchoolMission(){state.mission.done=true;state.items.forEach(i=>i.collected=true);awardCandy('finish-mission-'+levelIndex,2);showMessage('Mission geschafft! Der Ausgang ist bereit.',2200);}
  function showSchoolTask(){
    openGameMenu('mission');const m=state.mission;
    const question=GAME_DATA.questions[m.step];
    const labels=['ROT','BLAU','GELB'];
    const heading=levelIndex===0?'Stromversorgung reparieren':'Bewerbungsgespräch';
    const prompt=levelIndex===0?'Schalte die Leitungen in dieser Reihenfolge: '+GAME_DATA.circuit.map(i=>labels[i]).join(' → '):question.q;
    const choices=levelIndex===0?labels:question.a;
    overlay.innerHTML=`<div class="card menu-card"><h1>${heading}</h1><p>${prompt}</p><div class="task-progress">${[0,1,2].map(i=>`<span class="${i<m.step?'complete':''}">${i<m.step?'✓':i+1}</span>`).join('')}</div><p>Schritt ${m.step+1} / 3</p><div class="menu-actions">${choices.map((v,i)=>`<button data-answer="${i}">${v}</button>`).join('')}</div><p id="taskFeedback">${levelIndex===0?'Eine falsche Leitung setzt die Reihenfolge zurück.':'Wähle eine Antwort. Bei einem Fehler kannst du es erneut versuchen.'}</p><button id="taskBack">Zurück ins Spiel</button></div>`;
    document.getElementById('taskBack').onclick=resumeGame;
    overlay.querySelectorAll('[data-answer]').forEach(button=>button.onclick=()=>{
      const correct=levelIndex===0?GAME_DATA.circuit[m.step]:question.correct;
      if(Number(button.dataset.answer)!==correct){if(levelIndex===0){m.step=0;showSchoolTask();}document.getElementById('taskFeedback').textContent='Noch nicht richtig. Versuche es noch einmal.';return;}
      m.step++;if(m.step===3){resumeGame();completeSchoolMission();}else showSchoolTask();
    });
  }
  function updateSchoolMission(dt){
    const m=state.mission;if(!m||!m.active||m.done)return;
    const p={x:player.x+14,y:player.y+14},last=m.trail[m.trail.length-1]||m.drone;
    if(Math.hypot(p.x-last.x,p.y-last.y)>3)m.trail.push(p);
    let budget=190*dt;
    while(m.trail.length&&budget>0){const target=m.trail[0],dx=target.x-m.drone.x,dy=target.y-m.drone.y,d=Math.hypot(dx,dy);if(d<=budget){m.drone={...target};m.trail.shift();budget-=d;}else{m.drone.x+=dx/d*budget;m.drone.y+=dy/d*budget;budget=0;}}
    if(Math.hypot(m.drone.x-(state.exit.x+state.exit.w/2),m.drone.y-(state.exit.y+state.exit.h/2))<46&&bridgeBuilt())completeSchoolMission();
  }
  function drawSchoolMission(){
    const m=state.mission;if(!m)return;
    drawRoundedRect(24,H-65,W-48,40,9,'rgba(4,14,24,.90)');ctx.fillStyle='#d8f9ed';ctx.font='bold 13px system-ui';ctx.fillText(m.done?'✓ Mission geschafft · Gehe zum Ausgang':state.subtitle,40,H-40);
    if(m.drone){const {x,y}=m.drone,bob=Math.sin(gameNow()*.005)*3;ctx.fillStyle='#152736';ctx.beginPath();ctx.ellipse(x,y+10,19,7,0,0,Math.PI*2);ctx.fill();drawRoundedRect(x-13,y-12+bob,26,21,6,'#69e9d0','#e0fffa');ctx.fillStyle='#082a38';ctx.fillRect(x-8,y-7+bob,16,6);for(const sign of [-1,1]){ctx.fillStyle='#d9f6ff';ctx.fillRect(x+sign*20-9,y-7+bob,18,3);}}
  }
  function interact(){
    if(!started || finished) return;
    if(activateNearbyButton()) return;
    if(schoolInteract())return;
    for(const item of state.items){
      const box={x:item.x-18,y:item.y-18,w:36,h:36};
      if(!item.collected && centerDist(player,box)<58){
        if(!hasClearInteractionPath(item.x,item.y)){
          showMessage("Du kannst den Gegenstand nicht durch die Wand nehmen.",900);
          return;
        }

        item.collected=true;
        collectBursts.push({x:item.x,y:item.y,icon:item.icon,t:0});
        burst(item.x,item.y,"#f0c85b",20);
        showMessage(`Gesammelt: ${item.label} ${item.icon}`);
        beep(760,.09);
        if(collectedCount()===state.items.length){
          showMessage("Ausgang geöffnet! Geh zum Ziel.",1700);
          beep(980,.16);
        }
        return;
      }
    }
  }

  function nextLevel(){
    if(!state.mission.done){
      showMessage("Schliesse zuerst die Mission ab.");
      return;
    }
    if(!bridgeBuilt()){
      showMessage("Baue zuerst die Brücke mit der roten Taste.");
      return;
    }

    beep(1000,.12);
    levelIndex++;

    if(levelIndex>=levels.length){
      awardCandy('finish-school',4);
      startPixelTransition(()=>startStage2(),"ETAPPE 2 · 3D-WELT");
    }else{
      startPixelTransition(()=>resetLevel(),`LEVEL ${levelIndex+1}`);
    }
  }

  function formatTime(sec){
    sec=Math.max(0,Math.floor(sec));
    const m=Math.floor(sec/60).toString().padStart(2,'0');
    const s=(sec%60).toString().padStart(2,'0');
    return `${m}:${s}`;
  }

  function drawRoundedRect(x,y,w,h,r,fill,stroke=null){
    ctx.beginPath();
    ctx.roundRect(x,y,w,h,r);
    ctx.fillStyle=fill; ctx.fill();
    if(stroke){ctx.strokeStyle=stroke;ctx.stroke()}
  }

  function drawReadableLabel(text,x,y,{
    font="700 12px system-ui",
    color="#ffffff",
    bg="rgba(7,12,27,.76)",
    padX=7,
    padY=4,
    radius=6,
    align="center"
  }={}){
    ctx.save();
    ctx.font=font;
    const metrics=ctx.measureText(text);
    const fontSize=parseInt(font.match(/(\d+)px/)?.[1]||"12",10);
    const w=Math.ceil(metrics.width)+padX*2;
    const h=fontSize+padY*2+2;

    let left=x-w/2;
    if(align==="left") left=x;
    if(align==="right") left=x-w;

    const top=y-h+3;

    drawRoundedRect(left,top,w,h,radius,bg,"rgba(255,255,255,.14)");
    ctx.shadowColor="rgba(0,0,0,.9)";
    ctx.shadowBlur=3;
    ctx.fillStyle=color;
    ctx.textAlign=align;
    ctx.textBaseline="alphabetic";
    ctx.fillText(text,x,y-padY+1);
    ctx.restore();
  }

  function drawSnow(){
    ctx.save();
    for(const s of snow){
      ctx.globalAlpha=s.a;
      ctx.fillStyle="#fff";
      ctx.beginPath();ctx.arc(s.x,s.y,s.r,0,Math.PI*2);ctx.fill();
    }
    ctx.restore();
  }

  function drawTree(x,y,scale=1){
    ctx.save();
    ctx.translate(x,y);ctx.scale(scale,scale);
    ctx.fillStyle="#5b3a29";ctx.fillRect(-7,20,14,22);
    ctx.fillStyle="#2d8c58";
    ctx.beginPath();ctx.moveTo(0,-42);ctx.lineTo(-30,0);ctx.lineTo(30,0);ctx.closePath();ctx.fill();
    ctx.beginPath();ctx.moveTo(0,-18);ctx.lineTo(-38,20);ctx.lineTo(38,20);ctx.closePath();ctx.fill();
    ctx.fillStyle="#f0c85b";ctx.font="24px serif";ctx.textAlign="center";ctx.fillText("★",0,-34);
    ctx.restore();
  }

  function draw(){
    if(!state) return;

    // Sichere Standardwerte für jeden Frame.
    // So können Text/Animationen aus dem vorherigen Frame nichts verschieben.
    ctx.setTransform(1,0,0,1,0,0);
    ctx.globalAlpha=1;
    ctx.textAlign="left";
    ctx.textBaseline="alphabetic";
    ctx.shadowBlur=0;

    ctx.clearRect(0,0,W,H);

    // background / room
    ctx.fillStyle=state.bg; ctx.fillRect(0,0,W,H);
    ctx.fillStyle=state.floor; ctx.fillRect(25,25,W-50,H-50);

    // Feste Level-Anzeige oben links.
    // Textausrichtung und Basislinie werden jedes Bild explizit gesetzt,
    // damit andere Animationen (z. B. Sammelobjekte) sie nicht verschieben können.
    ctx.save();
    ctx.textAlign="left";
    ctx.textBaseline="alphabetic";
    ctx.setTransform(1,0,0,1,0,0);

    const titleX=34;
    const titleY=34;
    const titleW=255;
    const titleH=56;

    ctx.shadowColor="rgba(0,0,0,.55)";
    ctx.shadowBlur=8;
    drawRoundedRect(titleX,titleY,titleW,titleH,12,"rgba(7,12,27,.58)","rgba(255,255,255,.16)");
    ctx.shadowBlur=0;

    ctx.fillStyle="rgba(255,255,255,.96)";
    ctx.font="800 19px system-ui";
    ctx.fillText(state.name,titleX+16,titleY+25);

    ctx.fillStyle="rgba(240,200,91,.96)";
    ctx.font="700 13px system-ui";
    ctx.fillText(state.subtitle,titleX+16,titleY+46);
    ctx.restore();

    // walls/desks
    for(const w of state.walls){
      ctx.fillStyle="#6b5f58";
      ctx.fillRect(w.x,w.y,w.w,w.h);
      if(w.w>80 && w.h<60){
        ctx.fillStyle="rgba(255,255,255,.12)";
        ctx.fillRect(w.x+6,w.y+5,w.w-12,4);
      }
    }

    // Level-Hinweise werden NACH den Wänden gezeichnet.
    // So kann keine Wand mehr Text übermalen oder "durchstreichen".
    for(const s of state.signs){
      if(!s.text) continue;
      const sy=Math.max(s.y,102);

      ctx.save();
      drawRoundedRect(
        s.x,sy,410,36,10,
        "rgba(7,12,27,.88)",
        "rgba(255,255,255,.28)"
      );
      ctx.fillStyle="#ffffff";
      ctx.font="800 13px system-ui";
      ctx.textAlign="left";
      ctx.textBaseline="alphabetic";
      ctx.shadowColor="rgba(0,0,0,.95)";
      ctx.shadowBlur=4;
      ctx.fillText(s.text,s.x+12,sy+23);
      ctx.restore();
    }

    // Rote Taste baut eine Brücke über eine echte Lücke im Weg.
    // Rote Tasten stehen bewusst an einem anderen Ort als ihr Ziel.
    for(const b of state.redButtons||[]){
      const pressOffset=b.pressed?4:0;
      const glow=!b.pressed && Math.sin(gameNow()*0.006)>0 ? 10 : 5;

      ctx.save();
      ctx.shadowColor="rgba(225,45,45,.7)";
      ctx.shadowBlur=glow;

      // Sockel
      ctx.fillStyle="#555";
      ctx.beginPath();ctx.roundRect(b.x-18,b.y+5,36,12,5);ctx.fill();

      // roter Knopf
      ctx.fillStyle=b.pressed?"#7b2a2a":"#e83d3d";
      ctx.strokeStyle="#8f2020";ctx.lineWidth=2;
      ctx.beginPath();ctx.arc(b.x,b.y+pressOffset,14,0,Math.PI*2);ctx.fill();ctx.stroke();
      ctx.restore();

      drawReadableLabel(
        b.pressed?"BENUTZT":"ROTE TASTE",
        b.x,b.y+37,
        {font:"800 11px system-ui",bg:"rgba(70,12,18,.76)"}
      );
    }

    // Der Abgrund teilt die Karte vollständig in zwei Seiten.
    // Nur an der Brückenstelle gibt es einen möglichen Übergang.
    for(const c of state.chasmSegments||[]){
      ctx.save();

      ctx.fillStyle="#17151b";
      ctx.fillRect(c.x,c.y,c.w,c.h);

      // Seitenkanten
      ctx.fillStyle="#6b5544";
      ctx.fillRect(c.x-4,c.y,4,c.h);
      ctx.fillRect(c.x+c.w,c.y,4,c.h);

      // Tiefenlinien
      ctx.strokeStyle="rgba(255,255,255,.08)";
      ctx.lineWidth=2;
      for(let y=c.y+18;y<c.y+c.h;y+=30){
        ctx.beginPath();
        ctx.moveTo(c.x+8,y);
        ctx.lineTo(c.x+c.w-8,y+12);
        ctx.stroke();
      }

      ctx.restore();
    }

    // Minispiel: eine echte Lücke im Weg -> rote Taste baut die Brücke.
    for(const s of state.buildSites||[]){
      ctx.save();

      if(!s.built){
        // Dunkler Abgrund: hier kann der Held nicht weiter.
        ctx.fillStyle="#17151b";
        ctx.beginPath();
        ctx.roundRect(s.x,s.y,s.w,s.h,5);
        ctx.fill();

        // Kanten des Bodens
        ctx.strokeStyle="#82694f";
        ctx.lineWidth=4;
        ctx.beginPath();
        ctx.moveTo(s.x,s.y+2);
        ctx.lineTo(s.x+s.w,s.y+2);
        ctx.moveTo(s.x,s.y+s.h-2);
        ctx.lineTo(s.x+s.w,s.y+s.h-2);
        ctx.stroke();

        // Tiefe / Warnlinien
        ctx.strokeStyle="rgba(255,255,255,.10)";
        ctx.lineWidth=2;
        for(let x=s.x+12;x<s.x+s.w;x+=24){
          ctx.beginPath();
          ctx.moveTo(x,s.y+8);
          ctx.lineTo(x-8,s.y+s.h-8);
          ctx.stroke();
        }

        drawReadableLabel(
          "EINZIGER WEG",
          s.x+s.w/2,s.y+s.h/2+8,
          {font:"800 12px system-ui",color:"#f6d66f",bg:"rgba(7,12,27,.82)"}
        );
      }else{
        // Holzbrücke verbindet beide Seiten.
        ctx.fillStyle="#8b633f";
        ctx.beginPath();
        ctx.roundRect(s.x,s.y,s.w,s.h,4);
        ctx.fill();

        // Planken
        ctx.strokeStyle="#5f432e";
        ctx.lineWidth=2;
        for(let x=s.x+8;x<s.x+s.w;x+=15){
          ctx.beginPath();
          ctx.moveTo(x,s.y+3);
          ctx.lineTo(x,s.y+s.h-3);
          ctx.stroke();
        }

        // Geländer / Seile
        ctx.strokeStyle="#4f3827";
        ctx.lineWidth=4;
        ctx.beginPath();
        ctx.moveTo(s.x+3,s.y+5);
        ctx.lineTo(s.x+s.w-3,s.y+5);
        ctx.moveTo(s.x+3,s.y+s.h-5);
        ctx.lineTo(s.x+s.w-3,s.y+s.h-5);
        ctx.stroke();

        drawReadableLabel(
          "WEG OFFEN ✓",
          s.x+s.w/2,s.y+s.h+19,
          {font:"800 11px system-ui",bg:"rgba(23,78,39,.78)"}
        );

        drawReadableLabel(
          "→",
          s.x+s.w+18,s.y+s.h/2+8,
          {font:"900 17px system-ui",bg:"rgba(23,78,39,.78)",padX:5,padY:2}
        );
      }

      ctx.restore();
      ctx.textAlign="left";
    }

    // Minispiel 2: über niedrige Hindernisse springen.
    // Jede Sprungstrecke schließt den jeweiligen Korridor vollständig ab.
    for(const b of state.jumpBarriers||[]){
      ctx.save();

      // Kleine Anschlussstücke zeigen klar, dass links/rechts kein Weg vorbeiführt.
      ctx.fillStyle="#8b5b20";
      ctx.fillRect(b.x,b.y-3,4,b.h+6);
      ctx.fillRect(b.x+b.w-4,b.y-3,4,b.h+6);

      ctx.fillStyle="#c98a32";
      ctx.strokeStyle="#6e4618";
      ctx.lineWidth=2;
      ctx.beginPath();
      ctx.roundRect(b.x,b.y,b.w,b.h,4);
      ctx.fill();
      ctx.stroke();

      ctx.strokeStyle="#f7e0a2";
      ctx.lineWidth=3;
      for(let x=b.x+8;x<b.x+b.w-4;x+=20){
        ctx.beginPath();
        ctx.moveTo(x,b.y+2);
        ctx.lineTo(Math.min(x+10,b.x+b.w-2),b.y+b.h-2);
        ctx.stroke();
      }
      ctx.restore();

      // Beschriftung exakt über der Mitte der Sprungstrecke.
      drawReadableLabel(
        "SPRUNG · LEERTASTE",
        b.x+b.w/2,b.y-7,
        {font:"800 10px system-ui",bg:"rgba(83,52,16,.88)",padX:6,padY:3}
      );
    }

    // Bewegtes Ziel / Ausgang
    const exitBob = Math.sin(gameNow()*0.0032)*5;
    drawTree(state.exit.x+state.exit.w/2, state.exit.y+state.exit.h+40+exitBob, .72);

    const unlocked=collectedCount()===state.items.length;
    drawRoundedRect(state.exit.x,state.exit.y+exitBob,state.exit.w,state.exit.h,10,unlocked?"#e9c44f":"#777");
    ctx.fillStyle=unlocked?"#111":"#fff";
    ctx.font="900 12px system-ui";
    ctx.textAlign="center";
    ctx.shadowColor=unlocked?"rgba(255,255,255,.55)":"rgba(0,0,0,.9)";
    ctx.shadowBlur=3;
    ctx.fillText(state.exit.label,state.exit.x+state.exit.w/2,state.exit.y+exitBob+state.exit.h/2+4);
    ctx.shadowBlur=0;
    ctx.textAlign="left";

    // Hinweis: Das Ziel liegt bewusst hinter dem Abgrund.
    drawReadableLabel(
      "FINISH-SEITE",
      895,140,
      {font:"800 11px system-ui",bg:"rgba(7,12,27,.76)"}
    );

    // Bewegliche Sammelobjekte
    for(const item of state.items){
      if(item.collected) continue;
      const pulse=1+Math.sin(gameNow()*0.006+item.phase)*.08;
      ctx.save();
      ctx.translate(item.x,item.y);
      ctx.scale(pulse,pulse);
      ctx.shadowColor="rgba(240,200,91,.65)";
      ctx.shadowBlur=18;
      ctx.fillStyle="#fff";
      ctx.beginPath();ctx.arc(0,0,22,0,Math.PI*2);ctx.fill();
      ctx.restore();

      ctx.font="26px serif";ctx.textAlign="center";ctx.fillText(item.icon,item.x,item.y+9);
      drawReadableLabel(
        item.label,
        item.x,item.y+43,
        {font:"800 12px system-ui",bg:"rgba(7,12,27,.78)"}
      );
    }

    // Sammel-Animation: Icon fliegt kurz nach oben und verschwindet
    for(const b of collectBursts){
      const p=Math.min(1,b.t/.5);
      ctx.save();
      ctx.globalAlpha=1-p;
      ctx.font=`${28+20*p}px serif`;
      ctx.textAlign="center";
      ctx.fillText(b.icon,b.x,b.y-35*p);
      ctx.restore();
    }

    // Bewegliche Feinde
    for(const e of state.enemies){
      if(e.defeated) continue;
      const wobble=Math.sin(gameNow()*0.008+e.phase)*2;
      ctx.save();
      const enemyNow=gameNow();
      ctx.translate(e.x+e.w/2,e.y+e.h/2+wobble);

      // Elastische Verformung direkt nach einem Treffer.
      // Der Feind wird in Einschlagrichtung zusammengedrückt und quer dazu gestreckt.
      if(enemyNow<e.deformUntil){
        const left=(e.deformUntil-enemyNow)/340;
        const pulse=Math.sin(Math.max(0,Math.min(1,left))*Math.PI/2);

        const horizontal=Math.abs(e.hitDirX);
        const vertical=Math.abs(e.hitDirY);

        const scaleX=1 - .20*pulse*horizontal + .11*pulse*vertical;
        const scaleY=1 - .20*pulse*vertical + .11*pulse*horizontal;

        ctx.translate(e.hitDirX*3.5*pulse,e.hitDirY*3.5*pulse);
        ctx.rotate((e.hitDirX-e.hitDirY)*.06*pulse);
        ctx.scale(scaleX,scaleY);
      }

      if(enemyNow<e.hitFlashUntil){
        ctx.globalAlpha=.55;
      }

      // Körper
      ctx.fillStyle="#a53a42";
      ctx.beginPath();
      ctx.roundRect(-15,-14,30,28,9);
      ctx.fill();

      // Nach einem Treffer bleibt bis zum nächsten Level eine kleine
      // sichtbare Delle auf der getroffenen Seite.
      if(e.dent>0){
        const impactX=-e.hitDirX*12;
        const impactY=-e.hitDirY*10;
        ctx.save();
        ctx.globalAlpha=.34+.20*e.dent;
        ctx.fillStyle="#64262e";
        ctx.beginPath();
        ctx.ellipse(
          impactX,impactY,
          3.2+e.dent*2.6,
          2.4+e.dent*1.8,
          Math.atan2(e.hitDirY,e.hitDirX),
          0,Math.PI*2
        );
        ctx.fill();

        // kleine helle Kante erzeugt den Eindruck einer eingedrückten Stelle
        ctx.globalAlpha=.30;
        ctx.strokeStyle="#d36a70";
        ctx.lineWidth=1.3;
        ctx.beginPath();
        ctx.arc(impactX-e.hitDirX*2,impactY-e.hitDirY*2,3.2+e.dent,0,Math.PI*1.35);
        ctx.stroke();
        ctx.restore();
      }

      // kleine Hörner
      ctx.fillStyle="#6f2630";
      ctx.beginPath();
      ctx.moveTo(-10,-12);ctx.lineTo(-16,-22);ctx.lineTo(-4,-15);ctx.closePath();ctx.fill();
      ctx.beginPath();
      ctx.moveTo(10,-12);ctx.lineTo(16,-22);ctx.lineTo(4,-15);ctx.closePath();ctx.fill();

      // Augen
      ctx.fillStyle="#fff";
      ctx.beginPath();ctx.arc(-5,-3,3,0,Math.PI*2);ctx.arc(5,-3,3,0,Math.PI*2);ctx.fill();
      ctx.fillStyle="#1b1420";
      ctx.beginPath();ctx.arc(-4,-3,1.3,0,Math.PI*2);ctx.arc(4,-3,1.3,0,Math.PI*2);ctx.fill();

      // Mund
      ctx.strokeStyle="#fff";ctx.lineWidth=1.8;
      ctx.beginPath();ctx.moveTo(-6,7);ctx.lineTo(0,4);ctx.lineTo(6,7);ctx.stroke();

      // HP
      ctx.fillStyle="rgba(0,0,0,.35)";
      ctx.fillRect(-15,18,30,4);
      ctx.fillStyle="#f0c85b";
      ctx.fillRect(-15,18,30*(e.hp/e.maxHp),4);

      // Alarmzeichen, sobald der Feind den Spieler entdeckt hat.
      if(e.chasing){
        ctx.shadowColor="#ffffff";
        ctx.shadowBlur=5;
        ctx.fillStyle="#ff3d48";
        ctx.font="900 24px system-ui";
        ctx.textAlign="center";
        ctx.fillText("!",0,-28);
        ctx.shadowBlur=0;
        ctx.textAlign="left";
      }

      ctx.restore();

      drawReadableLabel(
        e.label,
        e.x+e.w/2,e.y+e.h+22,
        {font:"800 11px system-ui",bg:"rgba(80,16,23,.80)"}
      );
    }

    for(const candy of state.candies||[])if(!profile.claimed[candy.id])drawCandy(candy.x,candy.y,1);
    // player: Schüler mit vier Blickrichtungen
    ctx.save();
    ctx.translate(player.x + player.w/2, player.y + player.h/2);

    // Nach einem Treffer blinkt der Held kurz als Schutzphase.
    if(gameNow() < playerInvulnerableUntil){
      ctx.globalAlpha = (Math.floor(gameNow()/90)%2===0) ? 0.35 : 1;
    }

    const isWalking =
      keys.has("ArrowLeft") || keys.has("KeyA") ||
      keys.has("ArrowRight") || keys.has("KeyD") ||
      keys.has("ArrowUp") || keys.has("KeyW") ||
      keys.has("ArrowDown") || keys.has("KeyS");

    const walkPhase = isWalking ? Math.sin(gameNow() * 0.018) : 0;
    const legSwing = walkPhase * 5.5;
    const armSwing = walkPhase * 3.2;

    // Schatten
    ctx.fillStyle="rgba(0,0,0,.18)";
    ctx.globalAlpha *= (1 - Math.min(.45,jumpHeight()/55));
    ctx.beginPath();
    ctx.ellipse(0,18,13+jumpHeight()*.12,4+jumpHeight()*.03,0,0,Math.PI*2);
    ctx.fill();

    ctx.globalAlpha = (gameNow() < playerInvulnerableUntil)
      ? ((Math.floor(gameNow()/90)%2===0) ? 0.35 : 1)
      : 1;
    ctx.translate(0,-jumpHeight());

    ctx.lineCap="round";

    if(["down","down-left","down-right"].includes(player.facing)){
      if(player.facing==="down-left") ctx.rotate(-0.10);
      if(player.facing==="down-right") ctx.rotate(0.10);
      // Beine
      ctx.strokeStyle="#26334f"; ctx.lineWidth=4;
      ctx.beginPath(); ctx.moveTo(-5,8); ctx.lineTo(-6+legSwing,17); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(5,8); ctx.lineTo(6-legSwing,17); ctx.stroke();

      // Arme
      ctx.strokeStyle="#f0c7a5"; ctx.lineWidth=3.5;
      ctx.beginPath(); ctx.moveTo(-9,0); ctx.lineTo(-12-armSwing,8); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(9,0); ctx.lineTo(12+armSwing,8); ctx.stroke();

      // Körper
      ctx.fillStyle=outfit().color;
      ctx.beginPath(); ctx.roundRect(-10,-3,20,16,5); ctx.fill();

      // Rucksack seitlich sichtbar
      ctx.fillStyle="#d7a94b";
      ctx.beginPath(); ctx.roundRect(7,0,6,11,3); ctx.fill();

      // Hals + Kopf
      ctx.fillStyle="#f0c7a5"; ctx.fillRect(-3,-7,6,5);
      ctx.beginPath(); ctx.arc(0,-13,8,0,Math.PI*2); ctx.fill();

      // Haare
      ctx.fillStyle="#4a3426";
      ctx.beginPath(); ctx.arc(0,-15,8,Math.PI,Math.PI*2);
      ctx.lineTo(8,-13); ctx.lineTo(-8,-13); ctx.closePath(); ctx.fill();

      // Gesicht
      ctx.fillStyle="#222";
      ctx.beginPath();
      ctx.arc(-2.5,-13,1,0,Math.PI*2);
      ctx.arc(2.5,-13,1,0,Math.PI*2);
      ctx.fill();
    }

    else if(["up","up-left","up-right"].includes(player.facing)){
      if(player.facing==="up-left") ctx.rotate(0.10);
      if(player.facing==="up-right") ctx.rotate(-0.10);
      // Beine
      ctx.strokeStyle="#26334f"; ctx.lineWidth=4;
      ctx.beginPath(); ctx.moveTo(-5,8); ctx.lineTo(-6+legSwing,17); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(5,8); ctx.lineTo(6-legSwing,17); ctx.stroke();

      // Arme
      ctx.strokeStyle="#f0c7a5"; ctx.lineWidth=3.5;
      ctx.beginPath(); ctx.moveTo(-9,0); ctx.lineTo(-12-armSwing,8); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(9,0); ctx.lineTo(12+armSwing,8); ctx.stroke();

      // Körper
      ctx.fillStyle=outfit().color;
      ctx.beginPath(); ctx.roundRect(-10,-3,20,16,5); ctx.fill();

      // Rucksack mittig auf dem Rücken
      ctx.fillStyle="#d7a94b";
      ctx.beginPath(); ctx.roundRect(-7,-1,14,13,4); ctx.fill();
      ctx.strokeStyle="#8f6b2d"; ctx.lineWidth=1.5;
      ctx.beginPath(); ctx.moveTo(-5,0); ctx.lineTo(-8,-5); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(5,0); ctx.lineTo(8,-5); ctx.stroke();

      // Hals + Hinterkopf
      ctx.fillStyle="#f0c7a5"; ctx.fillRect(-3,-7,6,5);
      ctx.beginPath(); ctx.arc(0,-13,8,0,Math.PI*2); ctx.fill();

      // Haare von hinten
      ctx.fillStyle="#4a3426";
      ctx.beginPath(); ctx.arc(0,-14,8,Math.PI,Math.PI*2);
      ctx.lineTo(8,-10); ctx.lineTo(-8,-10); ctx.closePath(); ctx.fill();
    }

    else {
      // Seitenansicht: Zeichnung zunächst nach rechts,
      // für links wird die Figur gespiegelt.
      if(player.facing === "left") ctx.scale(-1,1);

      // Beine laufen vor/zurück
      ctx.strokeStyle="#26334f"; ctx.lineWidth=4;
      ctx.beginPath(); ctx.moveTo(-2,8); ctx.lineTo(-6+legSwing,17); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(3,8); ctx.lineTo(7-legSwing,17); ctx.stroke();

      // hinterer Arm
      ctx.strokeStyle="#d7a98c"; ctx.lineWidth=3.5;
      ctx.beginPath(); ctx.moveTo(-2,0); ctx.lineTo(-5-armSwing,8); ctx.stroke();

      // Körper
      ctx.fillStyle=outfit().color;
      ctx.beginPath(); ctx.roundRect(-8,-3,16,16,5); ctx.fill();

      // Rucksack auf dem Rücken
      ctx.fillStyle="#d7a94b";
      ctx.beginPath(); ctx.roundRect(-12,-1,7,13,3); ctx.fill();

      // vorderer Arm
      ctx.strokeStyle="#f0c7a5"; ctx.lineWidth=3.5;
      ctx.beginPath(); ctx.moveTo(6,0); ctx.lineTo(10+armSwing,8); ctx.stroke();

      // Hals + Kopf
      ctx.fillStyle="#f0c7a5"; ctx.fillRect(-1,-7,5,5);
      ctx.beginPath(); ctx.arc(2,-13,8,0,Math.PI*2); ctx.fill();

      // Haare
      ctx.fillStyle="#4a3426";
      ctx.beginPath(); ctx.arc(1,-15,8,Math.PI,Math.PI*2);
      ctx.lineTo(8,-13); ctx.lineTo(-6,-13); ctx.closePath(); ctx.fill();

      // Auge
      ctx.fillStyle="#222";
      ctx.beginPath(); ctx.arc(5,-13,1.1,0,Math.PI*2); ctx.fill();

      // kleine Nase
      ctx.strokeStyle="#bd8f72"; ctx.lineWidth=1.3;
      ctx.beginPath(); ctx.moveTo(8,-12); ctx.lineTo(10,-11); ctx.stroke();
    }
    ctx.fillStyle=outfit().scarf;ctx.fillRect(-7,-5,14,3);
    if(profile.hat==='beanie'){ctx.fillStyle=outfit().scarf;ctx.beginPath();ctx.arc(0,-17,9,Math.PI,Math.PI*2);ctx.fill();ctx.fillRect(-9,-18,18,4)}
    if(profile.hat==='phones'){ctx.strokeStyle='#54d8df';ctx.lineWidth=3;ctx.beginPath();ctx.arc(0,-14,9,Math.PI,Math.PI*2);ctx.stroke();ctx.fillStyle='#54d8df';ctx.fillRect(-10,-17,4,8);ctx.fillRect(6,-17,4,8)}



    // Kurze Wurfbewegung beim Schießen
    if(gameNow() < attackUntil){
      const p=Math.min(1,(gameNow()-attackStartedAt)/120);
      ctx.save();
      const [fx,fy]=facingVector();
      const baseRot=Math.atan2(fy,fx);
      const ox=fx*14, oy=fy*14;
      const rot=baseRot-0.25+p*0.5;
      ctx.translate(ox,oy);
      ctx.rotate(rot);
      ctx.fillStyle="#f0c85b";
      ctx.strokeStyle="#8d6e24";
      ctx.lineWidth=1.4;
      ctx.beginPath();
      ctx.roundRect(3,-3,28,7,2);
      ctx.fill();ctx.stroke();
      ctx.restore();
    }

    ctx.restore();

    // Fliegende Lineale / Projektile
    for(const rp of rulerProjectiles){
      ctx.save();
      ctx.translate(rp.x,rp.y);
      ctx.rotate(rp.rot);
      ctx.fillStyle="#f0c85b";
      ctx.strokeStyle="#8d6e24";
      ctx.lineWidth=1.5;
      ctx.beginPath();
      ctx.roundRect(-18,-4,36,8,2);
      ctx.fill();
      ctx.stroke();

      // Markierungen auf dem Lineal
      ctx.strokeStyle="#5d4818";
      ctx.lineWidth=1;
      for(let m=-12;m<=12;m+=6){
        ctx.beginPath();
        ctx.moveTo(m,-4);
        ctx.lineTo(m,-1);
        ctx.stroke();
      }

      // leichte Spur dahinter
      ctx.globalAlpha=0.25;
      ctx.fillStyle="#fff6cf";
      ctx.fillRect(-30,-2,12,4);
      ctx.restore();
    }

    // Partikel über der Spielfläche
    // Partikel über der Spielfläche
    for(const p of particles){
      ctx.save();
      ctx.globalAlpha=Math.max(0,p.life/p.maxLife);
      ctx.fillStyle=p.color;
      ctx.beginPath();
      ctx.arc(p.x,p.y,p.r,0,Math.PI*2);
      ctx.fill();
      ctx.restore();
    }

    // hint when close to item
    let hint=false;
    for(const item of state.items){
      if(item.collected) continue;
      const box={x:item.x-18,y:item.y-18,w:36,h:36};
      if(centerDist(player,box)<58){ hint=true; break; }
    }
    if(hint){
      drawRoundedRect(player.x-18,player.y-34,64,24,8,"rgba(6,10,22,.85)");
      ctx.fillStyle="#fff";ctx.font="700 12px system-ui";ctx.textAlign="center";
      ctx.fillText("E drücken",player.x+14,player.y-18);ctx.textAlign="left";
    }

    drawSnow();
  }

  function updateSnow(dt){
    if(snow.length<45){
      snow.push({x:Math.random()*W,y:-10,r:1+Math.random()*2.6,v:25+Math.random()*55,a:.25+Math.random()*.55});
    }
    for(const s of snow){
      s.y+=s.v*dt;
      s.x+=Math.sin((s.y+s.v)*.015)*8*dt;
      if(s.y>H+8){s.y=-8;s.x=Math.random()*W}
    }
  }

  let last=gameNow();

  // Pixel-Übergang beim Wechseln des Levels / der Etappe
  const transitionBuffer=document.createElement("canvas");
  const transitionBufferCtx=transitionBuffer.getContext("2d");
  transitionBufferCtx.imageSmoothingEnabled=false;

  const transitionFX={
    active:false,
    start:0,
    inMs:260,
    holdMs:90,
    outMs:260,
    switched:false,
    onSwitch:null,
    label:""
  };

  function startPixelTransition(onSwitch,label="LEVEL WECHSEL"){
    if(transitionFX.active) return;
    transitionFX.active=true;
    transitionFX.start=gameNow();
    transitionFX.switched=false;
    transitionFX.onSwitch=onSwitch;
    transitionFX.label=label;
    keys.clear();
  }

  function updateTransitionFX(now){
    if(!transitionFX.active) return;

    const elapsed=now-transitionFX.start;
    if(!transitionFX.switched && elapsed>=transitionFX.inMs){
      transitionFX.switched=true;
      transitionFX.onSwitch?.();
    }

    const total=transitionFX.inMs+transitionFX.holdMs+transitionFX.outMs;
    if(elapsed>=total){
      transitionFX.active=false;
      transitionFX.onSwitch=null;
      transitionFX.label="";
    }
  }

  function transitionCover(now){
    const elapsed=now-transitionFX.start;
    if(elapsed<=transitionFX.inMs){
      return Math.max(0,Math.min(1,elapsed/transitionFX.inMs));
    }
    if(elapsed<=transitionFX.inMs+transitionFX.holdMs){
      return 1;
    }
    const outElapsed=elapsed-transitionFX.inMs-transitionFX.holdMs;
    return Math.max(0,1-Math.min(1,outElapsed/transitionFX.outMs));
  }

  function drawPixelTransition(now){
    if(!transitionFX.active) return;

    const cover=transitionCover(now);
    const pixelStep=Math.round(4+cover*34);
    const sampleW=Math.max(18,Math.round(W/pixelStep));
    const sampleH=Math.max(10,Math.round(H/pixelStep));

    if(transitionBuffer.width!==sampleW || transitionBuffer.height!==sampleH){
      transitionBuffer.width=sampleW;
      transitionBuffer.height=sampleH;
    }

    transitionBufferCtx.clearRect(0,0,sampleW,sampleH);
    transitionBufferCtx.drawImage(canvas,0,0,sampleW,sampleH);

    ctx.save();
    ctx.imageSmoothingEnabled=false;
    ctx.drawImage(transitionBuffer,0,0,sampleW,sampleH,0,0,W,H);

    // dunkle Einfärbung für klaren Wechsel
    ctx.fillStyle=`rgba(7,10,18,${0.12+cover*0.44})`;
    ctx.fillRect(0,0,W,H);

    // sichtbare Pixelraster-Linien
    const grid=Math.max(12,Math.round(14+cover*26));
    ctx.strokeStyle=`rgba(255,255,255,${0.02+cover*0.06})`;
    ctx.lineWidth=1;
    for(let x=0;x<=W;x+=grid){
      ctx.beginPath(); ctx.moveTo(x,0); ctx.lineTo(x,H); ctx.stroke();
    }
    for(let y=0;y<=H;y+=grid){
      ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(W,y); ctx.stroke();
    }

    drawReadableLabel(
      transitionFX.label || "WECHSEL",
      W/2,H/2+14,
      {
        font:"900 18px system-ui",
        bg:`rgba(7,12,27,${0.58+cover*0.20})`,
        padX:14,
        padY:7
      }
    );
    ctx.restore();
  }


  // ================================================================
  // ETAPPE 2: 3D-LABYRINTH
  // ================================================================
  function createMazeLayout(){
    const w=23,h=17,grid=Array.from({length:h},()=>Array(w).fill('#'));let seed=9147;
    const rnd=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296};
    const stack=[[1,1]];grid[1][1]='.';
    while(stack.length){const [x,y]=stack[stack.length-1],options=[[2,0],[-2,0],[0,2],[0,-2]].filter(([dx,dy])=>x+dx>0&&x+dx<w-1&&y+dy>0&&y+dy<h-1&&grid[y+dy][x+dx]==='#');
      if(!options.length){stack.pop();continue}const [dx,dy]=options[Math.floor(rnd()*options.length)];grid[y+dy/2][x+dx/2]='.';grid[y+dy][x+dx]='.';stack.push([x+dx,y+dy]);}
    for(let y=1;y<=4;y++)for(let x=1;x<=5;x++)grid[y][x]='.';
    for(let i=0;i<18;i++){const x=2+Math.floor(rnd()*(w-4)),y=2+Math.floor(rnd()*(h-4));if((grid[y][x-1]==='.'&&grid[y][x+1]==='.')||(grid[y-1][x]==='.'&&grid[y+1][x]==='.'))grid[y][x]='.';}
    return grid.map(row=>row.join(''));
  }
  const labyrinthMap=createMazeLayout();
  const classroomMap=Array.from({length:11},(_,y)=>y===0||y===10?'#############':'#...........#');
  let stage2Map=labyrinthMap;
  const hubFurniture=[{x:2.3,z:2.3,w:2,d:.85},...[4.4,6.5].flatMap(z=>[3,4.8,8.2,10].map(x=>({x,z,w:1.1,d:.65})))];
  const hubTargets=[{id:'levels',x:6.5,z:1.5,name:'Wandtafel · Level wählen'},{id:'shop',x:11.3,z:7.8,name:'Garderobe · Kleidung kaufen'}];


  const stage2 = {
    x:1.5, y:1.5, angle:0,
    collected:0,
    items:[],
    exit:{x:10.5,y:1.5},
    depth:[]
  };

  function resetStage2(hub=false){
    stage2Map=hub?classroomMap:labyrinthMap;stage2.hub=hub;
    gameStage=hub?0:2;stage2.jumpZ=0;stage2.jumpV=0;stage2.vx=0;stage2.vz=0;stage2.flashlight=true;stage2.lightHeat=0;stage2.lightPingAt=0;
    stage2.x=3.5;
    stage2.y=2.5;
    stage2.angle=0;stage2.cameraYaw=0;stage2.zoom=1.9;stage2.pitch=-.18;
    stage2.thirdPerson=stage2.thirdPerson??true;stage2.walkPhase=0;stage2.walking=false;
    document.getElementById('cameraToggle').textContent=stage2.thirdPerson?'Kamera: hinten':'Kamera: Augen';
    stage2.collected=0;
    stage2.items=[
      {x:21.5,y:1.5,label:"Idee",icon:"◆",got:false},
      {x:1.5,y:15.5,label:"Technik",icon:"◆",got:false},
      {x:11.5,y:9.5,label:"Zukunft",icon:"◆",got:false}
    ];
    stage2.exit={x:21.5,y:15.5};
    stage2.depth=[];
    stage2.health=3;stage2.invuln=0;stage2.attackUntil=0;stage2.lastAttack=-1000;
    stage2.enemies=[[19.5,3.5],[3.5,13.5],[17.5,13.5]].map(([x,y],kind)=>({x,y,kind,stunned:0,alert:false,pathAt:0,target:null}));
    stage2.enemy=stage2.enemies[0];stage2.obstacles=[];
    const candidates=[];
    for(let z=2;z<stage2Map.length-2;z++)for(let x=2;x<stage2Map[0].length-2;x++){
      if(stage2Map[z][x]!=='#'&&(x>6||z>5)){
        const horizontal=stage2Map[z-1][x]==='#'&&stage2Map[z+1][x]==='#';
        const vertical=stage2Map[z][x-1]==='#'&&stage2Map[z][x+1]==='#';
        if(horizontal||vertical)candidates.push({x:x+.5,z:z+.5,w:horizontal?.18:.98,d:horizontal?.98:.18,h:.42});
      }
    }
    for(let i=0;i<8&&candidates.length;i++)stage2.obstacles.push(candidates[Math.floor((i+.5)*candidates.length/8)]);
    stage2.candies=[];const cells=[];
    for(let z=1;z<stage2Map.length-1;z+=2)for(let x=1;x<stage2Map[0].length-1;x+=2)if(stage2Map[z][x]!== '#')cells.push({x:x+.5,y:z+.5});
    for(let i=0;i<24;i++)stage2.candies.push({...cells[Math.floor(i*cells.length/24)],id:'candy-maze-'+i});
    if(hub){stage2.x=6.5;stage2.y=7.4;stage2.angle=-Math.PI/2;stage2.cameraYaw=stage2.angle;stage2.pitch=-.10;stage2.zoom=2.35;stage2.items=[];stage2.candies=[];stage2.enemies=[];stage2.obstacles=[];}

    keys.clear();
    stageLabel.innerHTML="<strong>BVJ 2026/27</strong> · Etappe 2: 3D-Welt";
    hud.textContent=isCompactMobile() ? "3D · ◆ 0/3" : "Etappe 2/3 · 3D-Labyrinth · ◆ 0/3";
    updateMobileUI();
  }

  function showStageCard(title,subtitle,text,buttonText,onStart){
    started=false;
    keys.clear();
    overlay.innerHTML=`
      <div class="card">
        <h1>${title}</h1>
        <h2>${subtitle}</h2>
        <p>${text}</p>
        <button id="stageContinueBtn">${buttonText}</button>
        <p class="small">BVJ 2026/27 · Technology &amp; Design</p>
      </div>`;
    overlay.style.display="flex";
    const stageContinueBtn=document.getElementById("stageContinueBtn");
    let stageButtonHandled=false;

    const continueStage=()=>{
      unlockAudio();
      if(stageButtonHandled) return;
      stageButtonHandled=true;
      overlay.style.display="none";
      started=true;
      keys.clear();
      onStart?.();
    };

    stageContinueBtn.addEventListener("click",continueStage);
    stageContinueBtn.addEventListener("pointerup",e=>{
      if(e.pointerType==="touch"){
        e.preventDefault();
        continueStage();
      }
    });
  }

  function startStage2(){
    resetStage2();
    showStageCard(
      "🧊 Etappe 2",
      "3D-Labyrinth",
      "Die Perspektive wechselt vollständig. Finde drei leuchtende Stationen im Labyrinth und erreiche danach das grüne Portal. Echtes 3D mit animierten Figuren. V oder die Kamera-Taste wechselt zwischen Rückansicht und Ich-Perspektive. Maus bewegen = Kamera frei drehen. Ein Klick ins Bild fängt die Maus ein; Esc gibt sie frei. Mausrad = Zoom. WASD/Pfeile = laufen, Q/C = Kamera drehen, V = Ansicht wechseln. Space = über die gelb markierten Hindernisse springen. Handy: links laufen, rechts auf dem Bild wischen. Das Stress-Monster patrouilliert im Labyrinth und verfolgt dich, wenn er dich sieht! F = mit dem Lineal kurz betäuben. Drei Monster bewachen das grosse Labyrinth. Du hast drei Herzen und keine Minikarte.",
      "3D-Welt starten"
    );
  }

  function s2IsWall(x,y){
    const gx=Math.floor(x), gy=Math.floor(y);
    if(gy<0 || gy>=stage2Map.length || gx<0 || gx>=stage2Map[0].length) return true;
    return stage2Map[gy][gx]==="#";
  }

  function s2CanStand(x,y){
    const r=.18;
    return !s2IsWall(x-r,y-r) &&
           !s2IsWall(x+r,y-r) &&
           !s2IsWall(x-r,y+r) &&
           !s2IsWall(x+r,y+r);
  }

  function s2PlayerCanStand(x,z){
    if(!s2CanStand(x,z))return false;
    const boxes=stage2.hub?[...hubFurniture.map(b=>({...b,h:1})),...hubFurniture.filter(b=>b.z>3).map(b=>({x:b.x,z:b.z+.64,w:.47,d:.52,h:.92})),{x:11.4,z:7.8,w:.9,d:2.95,h:2.2},{x:10,z:2,w:1.4,d:1.4,h:2.1}]:stage2.obstacles;
    return !boxes.some(b=>stage2.jumpZ<b.h+.025&&Math.abs(x-b.x)<b.w/2+.18&&Math.abs(z-b.z)<b.d/2+.18);
  }
  function s2Jump(){if(stage2.jumpZ===0){stage2.jumpV=4.8;effect('jump')}}
  function hubInteract(){
    const target=hubTargets.find(t=>Math.hypot(stage2.x-t.x,stage2.y-t.z)<1.85);
    if(target)openGameMenu(target.id);else showMessage('Gehe zur Wandtafel oder zur Garderobe und drücke E.',1600);
  }
  function s2Visible(ax,ay,bx,by){
    const steps=Math.ceil(Math.hypot(bx-ax,by-ay)*18);
    for(let i=1;i<=steps;i++)if(s2IsWall(ax+(bx-ax)*i/steps,ay+(by-ay)*i/steps))return false;
    return true;
  }
  function s2Attack(){
    if(stage2.hub)return;const now=gameNow();if(now-stage2.lastAttack<650)return;
    stage2.angle=stage2.cameraYaw??stage2.angle;stage2.lastAttack=now;stage2.attackUntil=now+220;effect('attack');
    for(const e of stage2.enemies){const dist=Math.hypot(e.x-stage2.x,e.y-stage2.y);
      if(dist<1.65&&Math.abs(angleDiff(Math.atan2(e.y-stage2.y,e.x-stage2.x),stage2.angle))<.8&&s2Visible(stage2.x,stage2.y,e.x,e.y)){
        e.stunned=now+2100;beep(880,.12);showMessage('Monster betäubt! Lauf weiter.',1000);
      }
    }
  }
  function toggleFlashlight(){stage2.flashlight=!stage2.flashlight;effect('click');showMessage(stage2.flashlight?'Taschenlampe an · lange Nutzung verrät dich!':'Taschenlampe aus · Aufmerksamkeit sinkt',1600)}
  function updateFlashlight(dt){
    if(stage2.hub)return;
    stage2.lightHeat=Math.max(0,Math.min(1,stage2.lightHeat+dt*(stage2.flashlight?1/GAME_DATA.stealth.revealSeconds:-GAME_DATA.stealth.coolRate)));
    if(stage2.lightHeat>=1&&gameNow()>=stage2.lightPingAt){
      stage2.lightPingAt=gameNow()+1800;
      for(const e of stage2.enemies){e.lastSeen={x:stage2.x,y:stage2.y};e.memory=gameNow()+GAME_DATA.stealth.memoryMs;e.pathAt=0;}
      showMessage('Das Licht hat dich verraten! Ausschalten und Position wechseln.',1600);
    }
  }
  function updateMazeEnemy(dt,e=stage2.enemy){
    const now=gameNow();if(now<e.stunned)return;
    const sees=s2Visible(e.x,e.y,stage2.x,stage2.y)&&Math.hypot(e.x-stage2.x,e.y-stage2.y)<6;
    if(sees&&!e.alert){effect('alert');showMessage('Der Bewerbungsstress hat dich entdeckt! F = abwehren',1500)}
    e.alert=sees;
    if(sees){e.memory=now+5000;e.lastSeen={x:stage2.x,y:stage2.y};}
    if(now>e.pathAt){
      e.pathAt=now+450;
      const chasing=now<(e.memory||0);
      if(!e.patrol||Math.hypot(e.x-e.patrol.x,e.y-e.patrol.y)<.45){
        const points=[{x:1.5,y:1.5},{x:21.5,y:1.5},{x:1.5,y:15.5},{x:21.5,y:15.5}];
        e.patrol=points[(e.patrolIndex=(e.patrolIndex??-1)+1)%4];
      }
      const goal=chasing?(e.lastSeen||stage2):e.patrol;
      const sx=Math.floor(e.x),sy=Math.floor(e.y),gx=Math.floor(goal.x),gy=Math.floor(goal.y);
      const queue=[[sx,sy,[]]],seen=new Set([sx+','+sy]);e.target=null;
      while(queue.length){
        const [x,y,path]=queue.shift();
        if(x===gx&&y===gy){e.target=path.length?{x:path[0][0]+.5,y:path[0][1]+.5}: {x:goal.x,y:goal.y};break}
        for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){
          const nx=x+dx,ny=y+dy,k=nx+','+ny;
          if(!seen.has(k)&&!s2IsWall(nx+.5,ny+.5)){seen.add(k);queue.push([nx,ny,[...path,[nx,ny]]])}
        }
      }
    }
    if(e.target){
      const dx=e.target.x-e.x,dy=e.target.y-e.y,d=Math.hypot(dx,dy),step=Math.min(d,dt*(e.alert?1.52:.95));
      if(d>.02){const nx=e.x+dx/d*step,ny=e.y+dy/d*step;
        if(s2CanStand(nx,e.y))e.x=nx;if(s2CanStand(e.x,ny))e.y=ny;
      }
    }
    if(Math.hypot(e.x-stage2.x,e.y-stage2.y)<.52&&now>stage2.invuln&&s2Visible(e.x,e.y,stage2.x,stage2.y)){
      stage2.health--;stage2.invuln=now+1800;e.stunned=now+1400;beep(160,.18);
      showMessage('Autsch! F hält den Stress auf Abstand.',1200);
      if(stage2.health<=0){resetStage2();showMessage('Neuer Versuch im Labyrinth – du schaffst das!',1800)}
    }
  }
  function updateStage2(dt){
    updateFlashlight(dt);
    if(!stage2.hub)for(const e of stage2.enemies){updateMazeEnemy(dt,e)}
    stage2.jumpV-=12*dt;stage2.jumpZ=Math.max(0,stage2.jumpZ+stage2.jumpV*dt);if(stage2.jumpZ===0)stage2.jumpV=0;
    const oldPX=stage2.x,oldPY=stage2.y;
    // Camera yaw is independent; walking follows the camera's horizontal axes.
    const turn=(keys.has('KeyC')?1:0)-(keys.has('KeyQ')?1:0);
    stage2.cameraYaw+=turn*1.65*dt;
    const f=(keys.has('KeyW')||keys.has('ArrowUp')?1:0)-(keys.has('KeyS')||keys.has('ArrowDown')?1:0);
    const side=(keys.has('KeyD')||keys.has('ArrowRight')?1:0)-(keys.has('KeyA')||keys.has('ArrowLeft')?1:0);
    {const a=stage2.cameraYaw,n=Math.hypot(f,side)||1,targetX=(Math.cos(a)*f-Math.sin(a)*side)/n*GAME_DATA.motion.mazeSpeed,targetZ=(Math.sin(a)*f+Math.cos(a)*side)/n*GAME_DATA.motion.mazeSpeed;
      stage2.vx+=(targetX-stage2.vx)*response(dt);stage2.vz+=(targetZ-stage2.vz)*response(dt);
      const vx=stage2.vx,vy=stage2.vz,nx=stage2.x+vx*dt,ny=stage2.y+vy*dt;
      if(s2PlayerCanStand(nx,stage2.y))stage2.x=nx;if(s2PlayerCanStand(stage2.x,ny))stage2.y=ny;
      if(stage2.thirdPerson&&Math.hypot(vx,vy)>.04)stage2.angle+=angleDiff(Math.atan2(vy,vx),stage2.angle)*Math.min(1,dt*14);
    }
    if(!stage2.thirdPerson)stage2.angle=stage2.cameraYaw;

    const travelled=Math.hypot(stage2.x-oldPX,stage2.y-oldPY);
    stage2.walking=travelled>.0001;stage2.walkPhase+=travelled*8;
    if(stage2.hub){hud.textContent='Klassenzimmer · 🍬 '+profile.candies+' · E an Tafel / Garderobe';return}
    for(const item of stage2.items){
      if(item.got) continue;
      if(Math.hypot(stage2.x-item.x,stage2.y-item.y)<.46){
        item.got=true;
        stage2.collected++;
        beep(720,.08);
        showMessage(`${item.label} gefunden! ${stage2.collected}/3`,900);
      }
    }

    if(Math.hypot(stage2.x-stage2.exit.x,stage2.y-stage2.exit.y)<.52){
      if(stage2.collected<stage2.items.length){
        showMessage("Das Portal ist noch gesperrt – finde zuerst alle 3 Stationen.",1000);
      }else{
        awardCandy('finish-maze',4);startPixelTransition(()=>startStage3(),"ETAPPE 3 · NEON-ACTION");
      }
    }

    hud.textContent=isCompactMobile()
      ? `${"♥".repeat(stage2.health)} · ◆ ${stage2.collected}/3`
      : `Etappe 2/3 · ${"♥".repeat(stage2.health)} · ◆ ${stage2.collected}/3 · F abwehren`;
  }

  function castStage2Ray(angle){
    let dist=0;
    const step=.025;
    while(dist<18){
      dist+=step;
      const x=stage2.x+Math.cos(angle)*dist;
      const y=stage2.y+Math.sin(angle)*dist;
      if(s2IsWall(x,y)) break;
    }
    return dist;
  }

  function angleDiff(a,b){
    let d=a-b;
    while(d>Math.PI) d-=Math.PI*2;
    while(d<-Math.PI) d+=Math.PI*2;
    return d;
  }

  function drawStage2Sprite(sprite,kind){
    const dx=sprite.x-stage2.x;
    const dy=sprite.y-stage2.y;
    const dist=Math.hypot(dx,dy);
    const a=Math.atan2(dy,dx);
    const diff=angleDiff(a,stage2.angle);
    const fov=Math.PI/3;

    if(Math.abs(diff)>fov*.58 || dist<.1) return;

    const corrected=dist*Math.cos(diff);
    const sx=(.5+diff/fov)*W;
    const size=Math.max(18,Math.min(150,210/corrected));
    const rayIndex=Math.max(0,Math.min(stage2.depth.length-1,
      Math.floor((.5+diff/fov)*stage2.depth.length)));

    if(stage2.depth[rayIndex] && corrected>stage2.depth[rayIndex]+.16) return;

    ctx.save();
    ctx.translate(sx,H/2+size*.10);
    ctx.shadowBlur=Math.min(38,size*.28);

    if(kind==="enemy"){
      const stunned=gameNow()<sprite.stunned;
      ctx.shadowColor=stunned?'#79ddff':'#ff4768';ctx.fillStyle=stunned?'#5187ac':'#bd244b';
      ctx.fillRect(-size*.28,-size*.25,size*.56,size*.65);
      ctx.fillStyle='#ecdbbd';ctx.fillRect(-size*.23,-size*.49,size*.46,size*.30);
      ctx.fillStyle='#d63956';ctx.beginPath();ctx.moveTo(-size*.30,-size*.47);ctx.lineTo(size*.15,-size*.85);ctx.lineTo(size*.30,-size*.47);ctx.fill();
      ctx.fillStyle='white';ctx.fillRect(-size*.29,-size*.49,size*.58,size*.07);
      ctx.fillStyle='#151725';ctx.fillRect(-size*.15,-size*.38,size*.09,size*.05);ctx.fillRect(size*.06,-size*.38,size*.09,size*.05);
      ctx.fillStyle='#f7ce66';ctx.fillRect(-size*.28,size*.15,size*.56,size*.07);
    }else if(kind==="item"){
      ctx.shadowColor="#61e9ff";
      ctx.fillStyle="#73ecff";
      ctx.rotate(gameNow()*.0016);
      ctx.fillRect(-size*.18,-size*.18,size*.36,size*.36);
      ctx.strokeStyle="#ffffff";
      ctx.lineWidth=Math.max(1,size*.018);
      ctx.strokeRect(-size*.18,-size*.18,size*.36,size*.36);
    }else{
      ctx.shadowColor="#72ff9b";
      ctx.fillStyle=stage2.collected===3?"#64f08e":"#55615b";
      const w=size*.50,h=size*.82;
      ctx.fillRect(-w/2,-h/2,w,h);
      ctx.strokeStyle=stage2.collected===3?"#dffff0":"#8c9690";
      ctx.lineWidth=Math.max(2,size*.025);
      ctx.strokeRect(-w/2,-h/2,w,h);
      ctx.fillStyle=stage2.collected===3?"#e8fff0":"#aeb8b2";
      ctx.fillRect(-w*.24,-h*.10,w*.48,h*.08);
    }
    ctx.restore();
  }

  function drawStage2Legacy(){
    ctx.setTransform(1,0,0,1,0,0);
    ctx.textAlign="left";
    ctx.textBaseline="alphabetic";
    ctx.shadowBlur=0;
    ctx.globalAlpha=1;
    ctx.clearRect(0,0,W,H);

    // Decke und Boden
    ctx.fillStyle="#080d18";
    ctx.fillRect(0,0,W,H/2);
    ctx.fillStyle="#18202c";
    ctx.fillRect(0,H/2,W,H/2);

    // Perspektivlinien im Boden
    ctx.save();
    ctx.strokeStyle="rgba(83,209,231,.11)";
    ctx.lineWidth=1;
    for(let i=1;i<=8;i++){
      const yy=H/2+(H/2)*(i/8)*(i/8);
      ctx.beginPath();ctx.moveTo(0,yy);ctx.lineTo(W,yy);ctx.stroke();
    }
    for(let i=-8;i<=8;i++){
      ctx.beginPath();
      ctx.moveTo(W/2,H/2);
      ctx.lineTo(W/2+i*95,H);
      ctx.stroke();
    }
    ctx.restore();

    // Raycasting
    const rays=240;
    const fov=Math.PI/3;
    stage2.depth=new Array(rays);
    const stripW=W/rays+1;

    for(let i=0;i<rays;i++){
      const rayAngle=stage2.angle-fov/2+(i/(rays-1))*fov;
      const raw=castStage2Ray(rayAngle);
      const d=Math.max(.05,raw*Math.cos(rayAngle-stage2.angle));
      stage2.depth[i]=d;

      const wallH=Math.min(H*1.45,390/d);
      const y=(H-wallH)/2;
      const shade=Math.max(35,210-d*20);
      const blue=Math.min(255,shade+28);
      ctx.fillStyle=`rgb(${Math.floor(shade*.48)},${Math.floor(shade*.68)},${Math.floor(blue)})`;
      ctx.fillRect(i*stripW,y,stripW+1,wallH);

      if(i%5===0){
        ctx.fillStyle="rgba(255,255,255,.035)";
        ctx.fillRect(i*stripW,y,1,wallH);
      }
    }

    const sprites=[...stage2.items.filter(i=>!i.got).map(i=>[i,'item']),[stage2.exit,'exit'],[stage2.enemy,'enemy']];
    sprites.sort((a,b)=>Math.hypot(b[0].x-stage2.x,b[0].y-stage2.y)-Math.hypot(a[0].x-stage2.x,a[0].y-stage2.y));
    for(const [sprite,kind] of sprites)drawStage2Sprite(sprite,kind);
    if(gameNow()<stage2.invuln){ctx.fillStyle='rgba(255,30,60,.13)';ctx.fillRect(0,0,W,H)}
    if(gameNow()<stage2.attackUntil){
      ctx.save();ctx.translate(W*.63,H*.83);ctx.rotate(-.7);ctx.fillStyle='#f3ce72';ctx.fillRect(-12,-190,24,230);ctx.fillStyle='#46371b';
      for(let i=-180;i<30;i+=15)ctx.fillRect(-12,i,10,2);ctx.restore();
    }

    // Crosshair
    ctx.save();
    ctx.strokeStyle="rgba(255,255,255,.75)";
    ctx.lineWidth=2;
    ctx.beginPath();
    ctx.moveTo(W/2-8,H/2);ctx.lineTo(W/2+8,H/2);
    ctx.moveTo(W/2,H/2-8);ctx.lineTo(W/2,H/2+8);
    ctx.stroke();
    ctx.restore();

    // Titel / Steuerung
    drawRoundedRect(24,24,410,60,12,"rgba(3,8,18,.74)","rgba(118,235,255,.22)");
    ctx.fillStyle="#ffffff";
    ctx.font="900 20px system-ui";
    ctx.fillText(stage2.hub?"KLASSENZIMMER · START":"DAS VERLASSENE LABYRINTH",40,51);
    ctx.fillStyle="#7deeff";
    ctx.font="700 12px system-ui";
    ctx.fillText(stage2.hub?"Maus · WASD · Space Sprung · V Kamera · E Benutzen":"Maus · WASD · Space Sprung · V Kamera · L Lampe",40,72);

  }


  // Real triangle-based WebGL renderer. All geometry and shaders are embedded.
  let mazeGL=null,mazeGLFailed=false;
  function initMazeGL(){
    if(mazeGL&&mazeGL.mapRef===stage2Map)return;
    if(!mazeGL)try{
      const surface=document.createElement('canvas');surface.width=W;surface.height=H;
      const gl=surface.getContext('webgl',{antialias:true,alpha:false,preserveDrawingBuffer:true});
      if(!gl)throw new Error('WebGL unavailable');
      const vs=`precision mediump float;attribute vec3 aPos;attribute vec3 aNormal;attribute vec3 aColor;attribute float aGlow;
        uniform vec3 uEye,uForward,uRight,uUp;uniform float uAspect;
        varying vec3 vPos,vNormal,vColor;varying float vGlow;
        void main(){vec3 d=aPos-uEye;float z=dot(d,uForward);
          gl_Position=vec4(dot(d,uRight)*1.32/uAspect,dot(d,uUp)*1.32,1.0050125*z-.1002506,z);
          vPos=aPos;vNormal=aNormal;vColor=aColor;vGlow=aGlow;}`;
      const fs=`precision mediump float;varying vec3 vPos,vNormal,vColor;varying float vGlow;
        uniform vec3 uEye,uForward;uniform float uLamp,uHub;
        void main(){vec3 n=normalize(vNormal);vec3 delta=uEye-vPos;float dist=length(delta);
          vec3 light=normalize(delta);float cone=smoothstep(.55,.94,dot(-light,uForward));
          float lamp=max(dot(n,light),0.)*(uHub*.35+uLamp*cone*1.65)/(1.+dist*dist*.14);
          float sky=.09+uHub*.15+.20*max(dot(n,normalize(vec3(-.4,1.,.3))),0.);
          float checker=1.;if(abs(n.y)>.9&&vPos.y<.05){vec2 tile=floor(vPos.xz*2.);checker=.82+.18*mod(tile.x+tile.y,2.);}
          vec3 col=vColor*checker*(sky+lamp)+vColor*vGlow;
          float fog=1.-exp(-dist*dist*.009);col=mix(col,vec3(.018,.031,.055),fog);
          gl_FragColor=vec4(pow(clamp(col,0.,1.),vec3(.88)),1.);}`;
      function shader(type,code){const sh=gl.createShader(type);gl.shaderSource(sh,code);gl.compileShader(sh);if(!gl.getShaderParameter(sh,gl.COMPILE_STATUS))throw new Error(gl.getShaderInfoLog(sh));return sh}
      const program=gl.createProgram();gl.attachShader(program,shader(gl.VERTEX_SHADER,vs));gl.attachShader(program,shader(gl.FRAGMENT_SHADER,fs));gl.linkProgram(program);
      if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw new Error(gl.getProgramInfoLog(program));
      gl.useProgram(program);gl.enable(gl.DEPTH_TEST);gl.clearColor(.018,.031,.055,1);
      const buffer=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buffer);
      for(const [name,size,offset] of [['aPos',3,0],['aNormal',3,12],['aColor',3,24],['aGlow',1,36]]){
        const loc=gl.getAttribLocation(program,name);gl.enableVertexAttribArray(loc);gl.vertexAttribPointer(loc,size,gl.FLOAT,false,40,offset);
      }
      const uniforms={};for(const name of ['uEye','uForward','uRight','uUp','uAspect','uLamp','uHub'])uniforms[name]=gl.getUniformLocation(program,name);
      mazeGL={gl,surface,program,buffer,uniforms,static:[]};
      surface.addEventListener('webglcontextlost',event=>{event.preventDefault();mazeGLFailed=true;mazeGL.software=true;showMessage('Grafikmodus gewechselt – 3D bleibt aktiv.',2200)});
    }catch(error){
      mazeGLFailed=true;mazeGL={software:true,static:[],reason:String(error.message||error)};
      showMessage('3D-Kompatibilitätsmodus aktiv – beide Kameras sind verfügbar.',3200);
    }
      mazeGL.mapRef=stage2Map;const mesh=mazeGL.static=[];
      const hub=stage2.hub,mw=stage2Map[0].length,mh=stage2Map.length;
      mazeBox(mesh,mw/2,-.12,mh/2,mw,.24,mh,hub?[.48,.32,.19]:[.13,.15,.18]);
      mazeBox(mesh,mw/2,2.65,mh/2,mw,.15,mh,hub?[.65,.66,.59]:[.06,.07,.10]);
      for(let z=0;z<mh;z++)for(let x=0;x<mw;x++){
        if(stage2Map[z][x]==='#'){
          mazeBox(mesh,x+.5,1.25,z+.5,1,2.5,1,hub?[.72,.67,.49]:[.20,.19,.25]);
          mazeBox(mesh,x+.5,.12,z+.5,1.012,.13,1.012,[.10,.09,.12]);
          if(!hub){for(const y of [.62,1.24,1.86])mazeBox(mesh,x+.5,y,z+.5,1.008,.018,1.008,[.09,.08,.12]);
            if((x*7+z*3)%9===0){mazeBox(mesh,x+.5,2.32,z+.5,1.04,.09,1.04,[.20,.24,.27]);mazeBox(mesh,x+.5,1.25,z+.5,.065,2.5,1.04,[.25,.19,.15]);}}

        }else if((x+z)%(hub?4:11)===0){
          mazeBox(mesh,x+.5,2.54,z+.5,.65,.045,.30,hub?[1,.87,.63]:[.72,.09,.16],1.6);
          if(!hub)mazeBox(mesh,x+.5,.012,z+.5,.12,.015,.12,[.6,.07,.12],1.2);
        }
      }
      if(hub)mazeClassroomModels(mesh);
  }


  function mazeBox(out,x,y,z,w,h,d,color,glow=0,yaw=0){
    const c=Math.cos(yaw),s=Math.sin(yaw);
    const faces=[[[1,0,0],[[1,-1,-1],[1,1,-1],[1,1,1],[1,-1,1]]],
      [[-1,0,0],[[-1,-1,1],[-1,1,1],[-1,1,-1],[-1,-1,-1]]],
      [[0,1,0],[[-1,1,-1],[-1,1,1],[1,1,1],[1,1,-1]]],
      [[0,-1,0],[[-1,-1,1],[-1,-1,-1],[1,-1,-1],[1,-1,1]]],
      [[0,0,1],[[1,-1,1],[1,1,1],[-1,1,1],[-1,-1,1]]],
      [[0,0,-1],[[-1,-1,-1],[-1,1,-1],[1,1,-1],[1,-1,-1]]]];
    for(const [normal,points] of faces)for(const i of [0,1,2,0,2,3]){
      const v=points[i],px=v[0]*w/2,pz=v[2]*d/2;
      out.push(x+px*c-pz*s,y+v[1]*h/2,z+px*s+pz*c,normal[0]*c-normal[2]*s,normal[1],normal[0]*s+normal[2]*c,...color,glow);
    }
  }
  function toggleMazeCamera(){
    if(gameStage!==2&&gameStage!==0)return;
    stage2.thirdPerson=!stage2.thirdPerson;
    if(!stage2.thirdPerson)stage2.angle=stage2.cameraYaw;
    document.getElementById('cameraToggle').textContent=stage2.thirdPerson?'Kamera: hinten':'Kamera: Augen';
    showMessage(stage2.thirdPerson?'Kamera hinter dem Helden · V wechseln':'Ich-Perspektive · V wechseln',1300);
  }
  document.getElementById('cameraToggle').onclick=toggleMazeCamera;

  // Smooth ellipsoids with per-vertex normals; limbs use a local joint basis.
  const sphereTemplate=[];
  for(let row=0;row<8;row++)for(let col=0;col<12;col++){
    const point=(r,c)=>{const p=Math.PI*r/8,t=Math.PI*2*c/12;return [Math.sin(p)*Math.cos(t),Math.cos(p),Math.sin(p)*Math.sin(t)]};
    const q=[point(row,col),point(row+1,col),point(row+1,col+1),point(row,col+1)];
    for(const i of [0,1,2,0,2,3])sphereTemplate.push(q[i]);
  }
  const sphereLow=[];
  for(let r=0;r<5;r++)for(let c=0;c<8;c++){
    const pt=(y,x)=>[Math.sin(Math.PI*y/5)*Math.cos(Math.PI*2*x/8),Math.cos(Math.PI*y/5),Math.sin(Math.PI*y/5)*Math.sin(Math.PI*2*x/8)];
    const q=[pt(r,c),pt(r+1,c),pt(r+1,c+1),pt(r,c+1)];for(const i of [0,1,2,0,2,3])sphereLow.push(q[i]);
  }
  function mazeRound(out,center,scale,color,basis=null,glow=0){
    basis=basis||[[1,0,0],[0,1,0],[0,0,1]];
    for(const unit of (mazeGL?.software?sphereLow:sphereTemplate)){
      const p=unit.map((v,i)=>v*scale[i]),n=unit.map((v,i)=>v/scale[i]);
      const len=Math.hypot(...n);
      const world=[0,1,2].map(i=>center[i]+basis[0][i]*p[0]+basis[1][i]*p[1]+basis[2][i]*p[2]);
      const normal=[0,1,2].map(i=>(basis[0][i]*n[0]+basis[1][i]*n[1]+basis[2][i]*n[2])/len);
      out.push(...world,...normal,...color,glow);
    }
  }
  function mazeLimb(out,a,b,radius,color){
    const delta=b.map((v,i)=>v-a[i]),len=Math.hypot(...delta);if(len<.001)return;
    const y=delta.map(v=>v/len),ref=Math.abs(y[1])>.95?[1,0,0]:[0,1,0];
    const x=[ref[1]*y[2]-ref[2]*y[1],ref[2]*y[0]-ref[0]*y[2],ref[0]*y[1]-ref[1]*y[0]];
    const m=Math.hypot(...x);for(let i=0;i<3;i++)x[i]/=m;
    const z=[x[1]*y[2]-x[2]*y[1],x[2]*y[0]-x[0]*y[2],x[0]*y[1]-x[1]*y[0]];
    mazeRound(out,a.map((v,i)=>(v+b[i])/2),[radius,len/2+radius*.30,radius],color,[x,y,z]);
  }
  // Authored ring meshes give clothing and faces a shaped silhouette with smooth normals.
  function mazeProfile(out,origin,rings,color,basis=null,segments=12){
    basis=basis||[[1,0,0],[0,1,0],[0,0,1]];
    const world=p=>origin.map((v,i)=>v+basis[0][i]*p[0]+basis[1][i]*p[1]+basis[2][i]*p[2]);
    const vertex=(r,t)=>{const ring=rings[r],prev=rings[Math.max(0,r-1)],next=rings[Math.min(rings.length-1,r+1)],dy=next[0]-prev[0]||1,c=Math.cos(t),s=Math.sin(t),rx=Math.max(.001,ring[1]),rz=Math.max(.001,ring[2]);
      const n=[c/rx,-((next[1]-prev[1])/dy/rx*c*c+(next[2]-prev[2])/dy/rz*s*s+((next[3]||0)-(prev[3]||0))/dy*s/rz)*1,s/rz];
      const len=Math.hypot(...n);return [...world([c*ring[1],ring[0],s*ring[2]+(ring[3]||0)]),...[0,1,2].map(i=>(basis[0][i]*n[0]+basis[1][i]*n[1]+basis[2][i]*n[2])/len),...color,0];};
    for(let r=0;r<rings.length-1;r++)for(let i=0;i<segments;i++){const a=i*Math.PI*2/segments,b=(i+1)*Math.PI*2/segments,v=[vertex(r,a),vertex(r+1,a),vertex(r+1,b),vertex(r,b)];for(const k of [0,1,2,0,2,3])out.push(...v[k]);}
    for(const r of [0,rings.length-1])for(let i=0;i<segments;i++){const top=r!==0,center=world([0,rings[r][0],rings[r][3]||0]),normal=basis[1].map(n=>n*(top?1:-1)),a=vertex(r,(i+(top?1:0))*Math.PI*2/segments),b=vertex(r,(i+(top?0:1))*Math.PI*2/segments);out.push(...center,...normal,...color,0,...a,...b);}
  }
  function mazeTube(out,a,b,r1,r2,color){
    const delta=b.map((v,i)=>v-a[i]),len=Math.hypot(...delta);if(len<.0001)return;
    const y=delta.map(v=>v/len),ref=Math.abs(y[1])>.95?[1,0,0]:[0,1,0];let x=[ref[1]*y[2]-ref[2]*y[1],ref[2]*y[0]-ref[0]*y[2],ref[0]*y[1]-ref[1]*y[0]];const n=Math.hypot(...x);x=x.map(v=>v/n);const z=[x[1]*y[2]-x[2]*y[1],x[2]*y[0]-x[0]*y[2],x[0]*y[1]-x[1]*y[0]];
    mazeProfile(out,a,[[0,r1,r1],[len*.18,r1,r1],[len*.85,r2,r2],[len,r2*.9,r2*.9]],color,[x,y,z],8);
  }
  function mazeCharacter(out,x,z,yaw,phase,walking,enemy=false,stunned=false,attack=0,jumpZ=0){
    const c=Math.cos(yaw),s=Math.sin(yaw),basis=[[c,0,s],[0,1,0],[-s,0,c]],stride=walking?Math.sin(phase)*.23:0;
    const bob=walking?Math.cos(phase*2)*.012:Math.sin(gameNow()*.002)*.005;
    const pos=(dx,y,dz)=>[x+dx*c-dz*s,y+jumpZ,z+dx*s+dz*c];
    const ball=(dx,y,dz,rx,ry,rz,col,glow=0)=>mazeRound(out,pos(dx,y,dz),[rx,ry,rz],col,basis,glow);
    const tube=(a,b,r1,r2,col)=>mazeTube(out,pos(...a),pos(...b),r1,r2,col);
    const shape=(dx,y,dz,rings,col)=>mazeProfile(out,pos(dx,y,dz),rings,col,basis);
    const box=(dx,y,dz,w,h,d,col)=>{const p=pos(dx,y,dz);mazeBox(out,...p,w,h,d,col,0,yaw)};
    const cloth=rgb(outfit().color),scarf=rgb(outfit().scarf),shade=cloth.map(v=>v*.67),skin=[.76,.53,.38],pants=[.09,.13,.18],metal=[.55,.64,.69];
    // Contact shadow, articulated legs and separate sneaker sole/upper/toe.
    mazeRound(out,[x,.008,z],[.25,.005,.21],[.045,.045,.05],basis);
    for(const side of [-1,1]){
      const cycle=phase+(side<0?Math.PI:0),lift=walking?Math.max(0,Math.sin(cycle))*.095:0;
      const knee=[side*.105,.39+bob,stride*side*.45+.035],foot=[side*.105,.075+lift,stride*side];
      tube([side*.10,.70+bob,0],knee,.077,.063,pants);tube(knee,foot,.063,.047,pants);
      ball(...knee,.065,.061,.063,pants);box(foot[0],foot[1]-.037,foot[2]+.042,.15,.035,.255,[.70,.73,.70]);
      ball(foot[0],foot[1],foot[2]+.038,.078,.055,.122,[.055,.085,.105]);
      box(foot[0],foot[1]+.037,foot[2]+.067,.09,.008,.083,[.30,.42,.46]);
      for(let i=0;i<3;i++)box(foot[0],foot[1]+.044,foot[2]+.035+i*.022,.074,.006,.007,[.80,.83,.78]);
    }
    shape(0,bob,0,[[.62,.13,.095],[.70,.16,.11],[.76,.16,.11]],pants);
    // Tailored jacket: squared shoulders, fitted waist and collar rather than ellipsoid torso.
    shape(0,bob,0,[[.72,.155,.118],[.76,.168,.125],[.91,.17,.132],[1.10,.208,.133],[1.16,.19,.12],[1.20,.075,.067]],cloth);
    shape(0,bob,0,[[.728,.167,.127],[.76,.17,.129]],shade);
    tube([0,.775+bob,.13],[0,1.16+bob,.132],.005,.005,metal);
    box(.015,1.11+bob,.143,.018,.03,.008,metal);
    for(const side of [-1,1]){box(side*.105,.86+bob,.128,.065,.058,.012,shade);box(side*.105,.894+bob,.139,.068,.01,.008,metal);}
    shape(0,bob,0,[[1.17,.06,.055],[1.26,.057,.055]],skin);
    // Jaw, cheeks, brow and crown are an authored continuous mesh.
    shape(0,bob,0,[[1.255,.045,.055,.027],[1.29,.082,.077,.021],[1.34,.105,.094,.015],[1.42,.114,.102,0],[1.49,.108,.098,-.007],[1.55,.08,.078,-.01],[1.575,.024,.026,-.01]],skin);
    ball(0,1.375+bob,.105,.021,.033,.031,skin);ball(0,1.358+bob,.123,.027,.013,.018,[.72,.45,.32]);
    for(const side of [-1,1]){
      ball(side*.122,1.405+bob,0,.021,.037,.023,skin);
      ball(side*.049,1.43+bob,.094,.029,.014,.012,[.91,.91,.87]);ball(side*.049,1.43+bob,.105,.010,.011,.007,[.10,.19,.23]);
      tube([side*.022,1.455+bob,.102],[side*.076,1.457+bob,.081],.006,.009,[.075,.045,.03]);
    }
    tube([-.032,1.317+bob,.091],[.032,1.317+bob,.091],.004,.004,[.37,.16,.12]);
    // Scalp cap, swept fringe and individually shaped locks.
    shape(0,bob,-.009,[[1.452,.113,.096,-.018],[1.51,.118,.105,-.01],[1.562,.09,.08,-.012],[1.587,.025,.025,-.02]],[.045,.032,.027]);
    ball(0,1.43+bob,-.084,.108,.105,.028,[.045,.032,.027]);
    for(let i=0;i<5;i++){const dx=-.087+i*.039;tube([dx,1.55+bob,.045],[dx+.025,1.465+bob+(i%2)*.014,.085],.022,.010,[.065,.043,.030]);}
    for(const side of [-1,1]){
      const elbow=[side*.25,1.00+bob,-stride*side*.5],hand=[side*.25,.80+bob,-stride*side];
      if(side===1&&attack>0){elbow[2]=.18;hand[0]=.25-attack*.36;hand[1]=1.08+bob;hand[2]=.38;}
      tube([side*.186,1.12+bob,0],elbow,.067,.056,cloth);tube(elbow,hand,.056,.041,cloth);
      ball(...elbow,.057,.057,.058,cloth);tube([hand[0],hand[1]+.025,hand[2]],hand,.044,.044,shade);
      ball(hand[0],hand[1]-.032,hand[2],.039,.051,.029,skin);
      for(let i=0;i<3;i++)tube([hand[0]-.023+i*.022,hand[1]-.05,hand[2]+.008],[hand[0]-.023+i*.022,hand[1]-.083,hand[2]+.023],.009,.007,skin);
      if(side===1&&!stage2.hub){const h=pos(...hand);mazeBox(out,h[0],h[1]+.14,h[2],.028,.32,.018,[.67,.43,.13],0,yaw);}
      if(side===-1&&!stage2.hub){tube([hand[0],hand[1]-.01,hand[2]],[hand[0],hand[1]+.01,hand[2]+.15],.030,.040,[.08,.11,.14]);ball(hand[0],hand[1]+.01,hand[2]+.162,.037,.037,.012,stage2.flashlight?[.9,.85,.5]:[.2,.25,.25],stage2.flashlight?.8:0);}
    }
    // Structured backpack, piping, shoulder straps, buckles and stitched pocket.
    shape(0,bob,-.172,[[.79,.10,.045],[.82,.135,.065],[1.07,.135,.065],[1.13,.10,.045]],[.48,.26,.10]);
    box(0,.88+bob,-.247,.20,.12,.032,[.65,.37,.13]);box(0,.948+bob,-.267,.19,.009,.012,metal);
    for(const side of [-1,1]){tube([side*.12,1.13+bob,-.16],[side*.13,.83+bob,-.13],.014,.014,[.20,.16,.10]);box(side*.10,1.05+bob,-.244,.023,.043,.014,metal);}
    tube([-.045,1.145+bob,-.19],[.045,1.145+bob,-.19],.010,.010,[.2,.15,.09]);
    shape(0,bob,0,[[1.185,.087,.078],[1.222,.093,.082]],scarf);
    tube([-.065,1.21+bob,-.06],[-.12,1.04+bob,-.20-Math.abs(stride)*.3],.028,.024,scarf);
    if(profile.hat==='beanie'){shape(0,bob,0,[[1.49,.123,.111],[1.54,.125,.113],[1.62,.087,.080],[1.65,.02,.02]],scarf);shape(0,bob,0,[[1.49,.13,.116],[1.525,.13,.116]],shade);ball(0,1.66+bob,0,.036,.036,.036,[.9,.88,.77]);}
    if(profile.hat==='phones'){for(const side of [-1,1]){ball(side*.13,1.42+bob,0,.025,.048,.035,[.09,.13,.17]);ball(side*.151,1.42+bob,0,.008,.030,.022,[.2,.75,.8]);}tube([-.13,1.45+bob,-.01],[-.08,1.59+bob,-.01],.015,.015,[.2,.75,.8]);tube([-.08,1.59+bob,-.01],[.08,1.59+bob,-.01],.015,.015,[.2,.75,.8]);tube([.08,1.59+bob,-.01],[.13,1.45+bob,-.01],.015,.015,[.2,.75,.8]);}
  }
  function mazeClassroomModels(mesh){
    const wood=[.55,.34,.18],edge=[.25,.18,.12],steel=[.23,.29,.32],blue=[.18,.34,.41];
    // Blackboard, tray, chalk, eraser and a clock, all actual geometry.
    mazeBox(mesh,6.5,1.62,1.06,6,1.45,.12,edge);
    mazeBox(mesh,6.5,1.62,1.14,5.76,1.22,.035,[.045,.22,.17],.3);
    mazeBox(mesh,6.5,.89,1.21,6,.055,.22,steel);
    for(let i=0;i<3;i++)mazeBox(mesh,4.1+i*.11,.929,1.24,.08,.018,.024,[.9,.88,.73]);
    mazeBox(mesh,8.7,.95,1.25,.21,.065,.11,[.24,.25,.21]);
    mazeRound(mesh,[9.98,2.13,1.08],[.24,.24,.035],[.18,.23,.26]);mazeRound(mesh,[9.98,2.13,1.115],[.211,.211,.012],[.92,.89,.77]);
    mazeTube(mesh,[9.98,2.13,1.133],[9.88,2.20,1.133],.009,.009,steel);mazeTube(mesh,[9.98,2.13,1.135],[10.02,2.30,1.135],.007,.007,steel);
    for(const desk of hubFurniture){
      const {x,z,w,d}=desk,teacher=z<3;
      mazeBox(mesh,x,.785,z,w,.10,d,wood);mazeBox(mesh,x,.728,z,w-.04,.03,d-.04,edge);
      // Braced metal legs and a shallow drawer below each desktop.
      for(const dx of [-1,1])for(const dz of [-1,1]){mazeBox(mesh,x+dx*(w/2-.10),.36,z+dz*(d/2-.10),.045,.72,.045,steel);mazeBox(mesh,x+dx*(w/2-.10),.025,z+dz*(d/2-.10),.065,.05,.065,[.07,.09,.11]);}
      for(const dx of [-1,1])mazeBox(mesh,x+dx*(w/2-.10),.17,z,.035,.035,d-.15,steel);
      mazeBox(mesh,x,.65,z,w-.18,.11,d-.14,[.36,.25,.16]);
      if(teacher){
        mazeBox(mesh,x+.32,.86,z-.02,.37,.025,.24,steel);mazeBox(mesh,x+.32,1.00,z-.08,.035,.28,.04,steel);
        mazeBox(mesh,x+.32,1.23,z-.08,.70,.43,.055,[.06,.09,.12]);mazeBox(mesh,x+.32,1.23,z-.045,.64,.36,.012,[.07,.32,.39],.65);
        for(let i=0;i<3;i++)mazeBox(mesh,x+.19,1.30-i*.065,z-.032,.25+i*.07,.017,.009,[.27,.68,.67],.4);
        mazeBox(mesh,x+.3,.852,z+.24,.52,.025,.15,[.12,.16,.19]);
        for(let i=0;i<8;i++)mazeBox(mesh,x+.08+i*.06,.87,z+.24,.035,.009,.09,[.44,.52,.55]);
        mazeRound(mesh,[x+.72,.86,z+.22],[.05,.025,.073],[.22,.27,.3]);
        for(let i=0;i<3;i++){mazeBox(mesh,x-.62,.85+i*.06,z,.34,.045,.30,[.13+i*.10,.27+i*.06,.35]);mazeBox(mesh,x-.62,.85+i*.06,z+.153,.28,.025,.012,[.82,.80,.68]);}
      }else{
        // An open exercise book with a visible spine and ruled pages.
        mazeBox(mesh,x-.12,.85,z,.39,.025,.29,[.18,.40,.48]);
        mazeBox(mesh,x-.12,.867,z,.36,.013,.265,[.87,.85,.73]);mazeBox(mesh,x-.12,.879,z,.007,.005,.25,[.48,.42,.32]);
        for(let i=0;i<4;i++)mazeBox(mesh,x-.12,.879,z-.08+i*.046,.30,.004,.005,[.37,.49,.51]);
        mazeBox(mesh,x+.32,.86,z+.03,.012,.012,.23,[.88,.56,.15],0,.28);
        const cz=z+.64;
        mazeBox(mesh,x,.43,cz,.47,.07,.43,blue);mazeBox(mesh,x,.73,cz+.18,.47,.35,.065,blue);
        for(const dx of [-1,1]){mazeBox(mesh,x+dx*.18,.21,cz,.035,.42,.035,steel);mazeBox(mesh,x+dx*.18,.025,cz,.055,.04,.55,steel);mazeBox(mesh,x+dx*.18,.58,cz+.18,.03,.48,.03,steel);}
      }
    }
    // Recessed windows, sill and ribbed radiators.
    for(const z of [3,6,8]){
      mazeBox(mesh,1.035,1.65,z,.04,1.20,1.45,[.30,.55,.68],.8);
      for(const dz of [-.76,0,.76])mazeBox(mesh,1.075,1.65,z+dz,.06,1.32,.045,[.81,.78,.65]);
      for(const y of [1.0,1.66,2.3])mazeBox(mesh,1.075,y,z,.06,.045,1.56,[.81,.78,.65]);
      mazeBox(mesh,1.13,.97,z,.25,.06,1.7,[.69,.68,.60]);
      for(let i=0;i<10;i++)mazeBox(mesh,1.10,.43,z-.59+i*.13,.17,.60,.077,[.54,.58,.56]);
    }
    // Open wardrobe: individual shaped coats on real hangers.
    mazeBox(mesh,11.72,1.10,7.8,.30,2.2,2.8,wood);
    for(const zz of [6.37,9.23])mazeBox(mesh,11.36,1.1,zz,1.0,2.2,.10,edge);
    for(const yy of [.12,2.15])mazeBox(mesh,11.36,yy,7.8,1.0,.1,2.9,edge);
    mazeTube(mesh,[11.29,1.96,6.5],[11.29,1.96,9.1],.02,.02,steel);
    const facing=[[0,0,-1],[0,1,0],[1,0,0]];
    for(let i=0;i<4;i++){
      const z=6.82+i*.65,x=11.26,col=rgb(cosmetics[i+1].color);
      mazeTube(mesh,[x,1.94,z],[x,1.80,z-.13],.012,.012,[.71,.68,.51]);mazeTube(mesh,[x,1.94,z],[x,1.80,z+.13],.012,.012,[.71,.68,.51]);
      mazeProfile(mesh,[x,.89,z],[[0,.17,.055],[.14,.17,.06],[.67,.20,.07],[.85,.085,.045]],col,facing,8);
      for(const side of [-1,1])mazeTube(mesh,[x,1.65,z+side*.17],[x,1.13,z+side*.25],.06,.045,col);
      mazeBox(mesh,x-.075,1.37,z,.012,.60,.012,[.8,.75,.6]);
    }
    // Layered fir branches, decorations and wrapped gifts.
    mazeProfile(mesh,[10,0,2],[[0,.16,.16],[.30,.12,.12]],[.31,.20,.10]);
    for(let i=0;i<4;i++){const y=.33+i*.36,r=.70-i*.14;mazeProfile(mesh,[10,y,2],[[0,r,r],[.06,r*.95,r*.95],[.55,.015,.015]],[.045,.24+i*.018,.12],null,12);}
    for(let i=0;i<15;i++){const a=i*2.4,y=.55+(i%4)*.30,r=.62-(y-.55)*.3;mazeRound(mesh,[10+Math.cos(a)*r,y,2+Math.sin(a)*r],[.045,.045,.045],i%2?[.8,.2,.12]:[.96,.65,.12],null,.35);}
    mazeRound(mesh,[10,2.02,2],[.10,.13,.10],[1,.7,.13],null,1);
    for(const [x,z,col] of [[9.40,2.18,[.66,.12,.2]],[10.4,2.35,[.14,.38,.52]],[9.9,2.60,[.62,.43,.12]]]){mazeBox(mesh,x,.15,z,.35,.3,.32,col);mazeBox(mesh,x,.31,z,.36,.04,.33,col);mazeBox(mesh,x,.16,z,.045,.33,.335,[.88,.76,.45]);mazeBox(mesh,x,.34,z,.36,.014,.045,[.88,.76,.45]);}
  }
  function mazeSpike(out,a,b,radius,color){
    const delta=b.map((v,i)=>v-a[i]),len=Math.hypot(...delta),axis=delta.map(v=>v/len);
    const ref=Math.abs(axis[1])>.9?[1,0,0]:[0,1,0];
    let u=[ref[1]*axis[2]-ref[2]*axis[1],ref[2]*axis[0]-ref[0]*axis[2],ref[0]*axis[1]-ref[1]*axis[0]];
    const size=Math.hypot(...u);u=u.map(v=>v/size);
    const v=[axis[1]*u[2]-axis[2]*u[1],axis[2]*u[0]-axis[0]*u[2],axis[0]*u[1]-axis[1]*u[0]];
    for(let i=0;i<10;i++){
      const theta=i*Math.PI/5,next=(i+1)*Math.PI/5;
      const p=a.map((n,j)=>n+radius*(Math.cos(theta)*u[j]+Math.sin(theta)*v[j]));
      const q=a.map((n,j)=>n+radius*(Math.cos(next)*u[j]+Math.sin(next)*v[j]));
      const normal=u.map((n,j)=>n*Math.cos((theta+next)/2)+v[j]*Math.sin((theta+next)/2)+axis[j]*radius/len);
      const norm=Math.hypot(...normal);for(const point of [p,q,b])out.push(...point,...normal.map(n=>n/norm),...color,0);
    }
  }
  function mazeStressMonster(out,e,now){
    const targetOut=out;out=[];
    const stunned=now<e.stunned,target=e.alert?stage2:(e.target||stage2);
    const yaw=Math.atan2(target.y-e.y,target.x-e.x)-Math.PI/2,c=Math.cos(yaw),s=Math.sin(yaw);
    const basis=[[c,0,s],[0,1,0],[-s,0,c]],phase=now*(e.alert?.014:.009);
    const stride=stunned?0:gait(phase)*.17,bob=stunned?0:Math.abs(Math.cos(phase))*.04;
    const kind=e.kind||0;
    const palettes=[[[.16,.045,.23],[.36,.09,.40]],[[.045,.18,.19],[.10,.36,.32]],[[.24,.045,.065],[.44,.12,.12]]];
    const skin=stunned?[.13,.24,.35]:palettes[kind][0],ridge=stunned?[.20,.40,.52]:palettes[kind][1];
    const bone=[.80,.68,.47],eye=stunned?[.12,.83,1]:[1,.42,.035];
    const stepUp=(stage2.obstacles||[]).some(b=>Math.abs(e.x-b.x)<b.w/2+.25&&Math.abs(e.y-b.z)<b.d/2+.25)?.46:0;
    const pos=(x,y,z)=>[e.x+x*c-z*s,y+stepUp,e.y+x*s+z*c];
    const ball=(x,y,z,rx,ry,rz,color,glow=0)=>mazeRound(out,pos(x,y,z),[rx,ry,rz],color,basis,glow);
    const limb=(a,b,r,color)=>mazeLimb(out,pos(...a),pos(...b),r,color);
    const spike=(a,b,r,color)=>mazeSpike(out,pos(...a),pos(...b),r,color);
    // Low, hunched silhouette, crooked legs, a heavy jaw and a pointed tail.
    mazeProfile(out,pos(0,bob,-.06),[[.47,.19,.17],[.65,.27,.23],[.90,kind===1?.25:.34,.26,-.04],[1.09,.27,.22,-.07],[1.18,.15,.14]],skin,basis);
    for(let i=0;i<4;i++){const y=.65+i*.13;ball(0,y+bob,-.27,.26-i*.025,.10,.055,ridge);}
    for(const side of [-1,1])for(let i=0;i<3;i++){const y=.68+i*.105;limb([side*.07,y+bob,.20],[side*(.21+i*.012),y+.06+bob,.12],.018,ridge);}
    ball(0,.69+bob,.12,.21,.23,.11,ridge.map(v=>v*.8));
    for(const side of [-1,1]){
      const swing=stride*side,hip=[side*.17,.57+bob,-.02],knee=[side*.22,.33,.11+swing*.5],foot=[side*.21,.09,.13+swing];
      limb(hip,knee,.11,skin);limb(knee,foot,.075,ridge);ball(...foot,.12,.075,.17,skin);
      for(const dx of [-.065,0,.065])spike([foot[0]+dx,.08,foot[2]+.10],[foot[0]+dx,.045,foot[2]+.25],.025,bone);
      const elbow=[side*.34,.70+bob,-swing],hand=[side*.34,.46+bob,.18-swing];
      limb([side*.24,1.0+bob,0],elbow,.105,ridge);limb(elbow,hand,.08,skin);ball(...hand,.095,.11,.09,skin);
      for(const dx of [-.05,0,.05])spike([hand[0]+dx,hand[1]-.055,hand[2]+.035],[hand[0]+dx,hand[1]-.19,hand[2]+.14],.024,bone);
    }
    mazeProfile(out,pos(0,bob,.10),[[1.03,.16,.15,.05],[1.10,.25,.20,.04],[1.28,.27,.20],[1.39,.20,.15,-.03],[1.46,.08,.07,-.06]],skin,basis);
    mazeProfile(out,pos(0,bob,.26),[[.99,.12,.06],[1.04,.21,.12],[1.12,.23,.10],[1.15,.18,.06]],ridge,basis);
    ball(0,1.075+bob,.375,.17,.068,.023,[.018,.008,.025]);
    for(const side of [-1,1]){
      ball(side*.105,1.24+bob,.276,.070,.046,.030,eye,1.15);
      ball(side*.105,1.24+bob,.305,.012,.039,.009,[.025,.005,.02]);
      limb([side*.035,1.29+bob,.27],[side*.19,1.34+bob,.20],.04,ridge);
      spike([side*.10,1.12+bob,.37],[side*.085,1.015+bob,.39],.027,bone);
      limb([side*.20,1.36+bob,.01],[side*.28,1.52+bob,-.04],.067,ridge);
      spike([side*.28,1.52+bob,-.04],[side*(kind===1?.36:.31),1.77+bob,-.17],.055,bone);
      spike([side*.24,1.02+bob,-.13],[side*.36,1.23+bob,-.22],.06,ridge);
    }
    limb([0,.55,-.20],[Math.sin(phase*.45)*.10,.33,-.43],.075,skin);
    spike([Math.sin(phase*.45)*.10,.33,-.43],[Math.sin(phase*.45)*.17,.25,-.68],.07,ridge);
    for(const y of [.70,.90,1.10])spike([0,y+bob,-.24],[0,y+.13+bob,-.40],.055,ridge);
    // Uneven teeth, a split crown and species-specific growths.
    for(let i=0;i<7;i++){const dx=-.14+i*.046;spike([dx,1.12+bob,.387],[dx*.93,1.07+bob-(i%2)*.025,.40],.012,bone);}
    if(kind===1){for(const side of [-1,1]){ball(side*.19,1.37+bob,.21,.034,.027,.02,eye,.8);for(let i=0;i<2;i++){const a=[side*(.25+i*.04),1.13+bob,-.12],b=[side*(.39+i*.03),1.42+bob,-.27];limb(a,b,.025,ridge);spike(b,[b[0]+side*.06,b[1]+.12,b[2]-.07],.025,bone);}}}
    if(kind===1){for(const side of [-1,1])for(let i=0;i<2;i++){const sway=Math.sin(phase+i*Math.PI+side)*.05,a=[side*.23,.85+bob,-.06-i*.14],b=[side*.42,.55+bob,-.04-i*.18+sway],end=[side*.36,.07,.12-i*.37+sway];limb(a,b,.048,ridge);limb(b,end,.035,skin);spike(end,[end[0],.04,end[2]+.13],.035,bone);}}
    if(kind===2){for(const side of [-1,1])for(let i=0;i<3;i++)spike([side*.27,.89+i*.10+bob,-.09],[side*(.42+i*.025),1.03+i*.11+bob,-.28],.045,bone);}
    if(stunned)for(let i=0;i<3;i++){
      const a=now*.004+i*Math.PI*2/3;ball(Math.cos(a)*.26,1.83+Math.sin(a*2)*.035,Math.sin(a)*.18,.035,.035,.035,[.2,.8,1],1.5);
    }
    const scale=kind===1?[1.08,.78,1.08]:kind===2?[.87,1.10,.92]:[1,1,1];
    for(let i=0;i<out.length;i+=10){out[i]=e.x+(out[i]-e.x)*scale[0];out[i+1]=stepUp+(out[i+1]-stepUp)*scale[1];out[i+2]=e.y+(out[i+2]-e.y)*scale[2];const n=[out[i+3]/scale[0],out[i+4]/scale[1],out[i+5]/scale[2]],len=Math.hypot(...n);for(let j=0;j<3;j++)out[i+3+j]=n[j]/len;}
    for(let i=0;i<out.length;i++)targetOut.push(out[i]);
  }
  function mazeCamera(now){
    const angle=stage2.cameraYaw??stage2.angle,pitch=stage2.pitch||0,cp=Math.cos(pitch),sp=Math.sin(pitch);
    const forward=[Math.cos(angle)*cp,sp,Math.sin(angle)*cp],right=[-Math.sin(angle),0,Math.cos(angle)],up=[-Math.cos(angle)*sp,cp,-Math.sin(angle)*sp];
    const target=[stage2.x,Math.min(2.34,(stage2.thirdPerson?1.12:1.43)+(stage2.jumpZ||0)),stage2.y];
    let distance=0;
    if(stage2.thirdPerson){
      for(let d=.025;d<=(stage2.zoom||1.9);d+=.025){
        const q=target.map((v,i)=>v-forward[i]*d);
        if(q[1]<.18||q[1]>2.38||!s2CanStand(q[0],q[2]))break;
        distance=d;
      }
    }
    const eye=target.map((v,i)=>v-forward[i]*distance);
    return {eye,forward,right,up,distance};
  }
  // Canvas software rasterizer: same 3D meshes and depth buffer, no WebGL needed.
  let softwareMaze=null;
  function renderSoftwareMaze(data,eye,forward,right,up){
    if(!softwareMaze){
      const surface=document.createElement('canvas');surface.width=640;surface.height=360;
      const context=surface.getContext('2d');
      softwareMaze={surface,context,image:context.createImageData(640,360),depth:new Float32Array(640*360)};
    }
    const {surface,context,image,depth}=softwareMaze,sw=640,sh=360,pixels=image.data;
    depth.fill(0);for(let i=0;i<pixels.length;i+=4){pixels[i]=5;pixels[i+1]=8;pixels[i+2]=14;pixels[i+3]=255}
    const focal=sh*.66;
    const dot=(a,b)=>a[0]*b[0]+a[1]*b[1]+a[2]*b[2];
    for(let k=0;k<data.length;k+=30){
      const cx=(data[k]+data[k+10]+data[k+20])/3-eye[0],cy=(data[k+1]+data[k+11]+data[k+21])/3-eye[1],cz=(data[k+2]+data[k+12]+data[k+22])/3-eye[2];
      if((data[k+3]+data[k+13]+data[k+23])*cx+(data[k+4]+data[k+14]+data[k+24])*cy+(data[k+5]+data[k+15]+data[k+25])*cz>=0)continue;
      let vertices=[];
      for(let v=0;v<3;v++){
        const i=k+v*10,delta=[data[i]-eye[0],data[i+1]-eye[1],data[i+2]-eye[2]],dist=Math.hypot(...delta)||.001;
        const nx=data[i+3],ny=data[i+4],nz=data[i+5],lamp=Math.max(0,-(nx*delta[0]+ny*delta[1]+nz*delta[2])/dist);
        const cone=Math.max(0,Math.min(1,(dot(delta,forward)/dist-.55)/.39));
        const lit=.09+(stage2.hub?.15:0)+.20*Math.max(0,(-.4*nx+ny+.3*nz)/1.118)+lamp*((stage2.hub?.35:0)+(stage2.hub||stage2.flashlight?cone*1.65:0))/(1+dist*dist*.14)+data[i+9];
        const fog=1-Math.exp(-dist*dist*.009),base=[.018,.031,.055];
        const colors=[0,1,2].map(c=>Math.pow(Math.max(0,Math.min(1,data[i+6+c]*lit*(1-fog)+base[c]*fog)),.88)*255);
        vertices.push([dot(delta,right),dot(delta,up),dot(delta,forward),...colors]);
      }
      // Clip triangles at the near plane; geometry behind the camera is discarded.
      const clipped=[];
      for(let i=0;i<3;i++){
        const a=vertices[i],b=vertices[(i+1)%3],ina=a[2]>=.055,inb=b[2]>=.055;
        if(ina)clipped.push(a);
        if(ina!==inb){const t=(.055-a[2])/(b[2]-a[2]);clipped.push(a.map((v,j)=>v+(b[j]-v)*t))}
      }
      if(clipped.length<3)continue;
      const projected=clipped.map(v=>{const iz=1/v[2];return [sw/2+v[0]*focal*iz,sh/2-v[1]*focal*iz,iz,v[3]*iz,v[4]*iz,v[5]*iz]});
      for(let tri=1;tri<projected.length-1;tri++){
        const a=projected[0],b=projected[tri],c=projected[tri+1];
        const area=(b[1]-c[1])*(a[0]-c[0])+(c[0]-b[0])*(a[1]-c[1]);if(Math.abs(area)<.001)continue;
        const minX=Math.max(0,Math.floor(Math.min(a[0],b[0],c[0]))),maxX=Math.min(sw-1,Math.ceil(Math.max(a[0],b[0],c[0])));
        const minY=Math.max(0,Math.floor(Math.min(a[1],b[1],c[1]))),maxY=Math.min(sh-1,Math.ceil(Math.max(a[1],b[1],c[1])));
        const dax=(b[1]-c[1])/area,day=(c[0]-b[0])/area,dbx=(c[1]-a[1])/area,dby=(a[0]-c[0])/area;
        for(let y=minY;y<=maxY;y++){
          let wa=dax*(minX+.5-c[0])+day*(y+.5-c[1]),wb=dbx*(minX+.5-c[0])+dby*(y+.5-c[1]);
          for(let x=minX;x<=maxX;x++,wa+=dax,wb+=dbx){
            const wc=1-wa-wb;if(wa<0||wb<0||wc<0)continue;
            const z=wa*a[2]+wb*b[2]+wc*c[2],idx=y*sw+x;if(z<=depth[idx])continue;
            depth[idx]=z;const p=idx*4;
            pixels[p]=(wa*a[3]+wb*b[3]+wc*c[3])/z;pixels[p+1]=(wa*a[4]+wb*b[4]+wc*c[4])/z;pixels[p+2]=(wa*a[5]+wb*b[5]+wc*c[5])/z;
          }
        }
      }
    }
    context.putImageData(image,0,0);ctx.imageSmoothingEnabled=true;ctx.drawImage(surface,0,0,W,H);
  }
  function renderMaze3D(){
    initMazeGL();if(!mazeGL)return false;
    const {gl,surface,uniforms}=mazeGL,now=gameNow(),data=mazeGL.static.slice();
    for(const item of stage2.items){if(item.got)continue;
      mazeProfile(data,[item.x,0,item.y],[[0,.31,.31],[.08,.31,.31],[.12,.25,.25],[.50,.23,.23],[.55,.28,.28]],[.13,.19,.23],null,8);
      for(const side of [-1,1]){mazeBox(data,item.x+side*.17,.32,item.y+.23,.035,.21,.015,[.11,.72,.68],.7);mazeBox(data,item.x+side*.14,.57,item.y,.04,.04,.46,[.52,.56,.54]);}
      mazeBox(data,item.x,.34,item.y+.243,.17,.12,.02,[.05,.22,.24],.3);
      for(let i=0;i<3;i++)mazeBox(data,item.x-.055+i*.055,.34,item.y+.26,.025,.018,.008,[.12,.83,.64],.8);
      const y=.81+Math.sin(now*.003+item.x)*.055,spin=now*.0008,c=Math.cos(spin),s=Math.sin(spin),basis=[[c,0,s],[0,1,0],[-s,0,c]];
      mazeProfile(data,[item.x,y,item.y],[[-.18,.015,.015],[-.07,.135,.135],[.08,.11,.11],[.25,.005,.005]],[.15,.78,.75],basis,6);
      mazeRound(data,[item.x,y,item.y],[.055,.055,.055],[.60,1,.80],null,.8);
    }
    if(!stage2.hub){
    const portal=stage2.exit,unlocked=stage2.collected===3,pc=unlocked?[.12,.85,.46]:[.8,.15,.25];
    mazeBox(data,portal.x-.32,1,portal.y,.08,2,.15,pc,1.2);
    mazeBox(data,portal.x+.32,1,portal.y,.08,2,.15,pc,1.2);
    mazeBox(data,portal.x,1.96,portal.y,.72,.08,.15,pc,1.2);
    mazeBox(data,portal.x,.05,portal.y,.72,.08,.55,pc,.7);
    for(const side of [-1,1]){mazeBox(data,portal.x+side*.39,.99,portal.y,.085,2.12,.32,[.22,.29,.31]);for(const y of [.2,.8,1.5])mazeBox(data,portal.x+side*.39,y,portal.y+.18,.11,.08,.035,[.5,.55,.56]);}
    mazeBox(data,portal.x,2.08,portal.y,.86,.16,.32,[.19,.24,.27]);
    for(let i=0;i<3;i++)mazeBox(data,portal.x-.18+i*.18,2.09,portal.y+.18,.1,.045,.015,pc,.8);
    }
    for(const o of stage2.obstacles){
      mazeBox(data,o.x,o.h/2,o.z,o.w,o.h,o.d,[.36,.23,.14]);
      for(let i=1;i<4;i++)mazeBox(data,o.x,o.h*i/4,o.z,o.w+.004,.009,o.d+.004,[.17,.12,.08]);
      mazeBox(data,o.x,o.h+.012,o.z,o.w,.025,o.d,[.85,.59,.17],.15);
      for(const sign of [-1,1]){const bx=o.x+(o.w>o.d?sign*o.w*.33:0),bz=o.z+(o.d>o.w?sign*o.d*.33:0);mazeBox(data,bx,o.h/2,bz,o.w>o.d?.045:o.w+.012,o.h+.015,o.d>o.w?.045:o.d+.012,[.19,.25,.27]);}
    }
    for(const c of stage2.candies){if(profile.claimed[c.id])continue;const y=.55+Math.sin(now*.003+c.x)*.07;mazeRound(data,[c.x,y,c.y],[.14,.10,.10],[1,.19,.48],null,.7);mazeBox(data,c.x,y,c.y,.40,.045,.07,[1,.75,.24],.7,now*.002);}
    const {eye,forward,right,up,distance}=mazeCamera(now);
    for(const e of stage2.enemies)if(!mazeGL.software||s2Visible(eye[0],eye[2],e.x,e.y))mazeStressMonster(data,e,now);
    const swing=now<stage2.attackUntil?Math.sin((1-(stage2.attackUntil-now)/220)*Math.PI):0;
    if(stage2.thirdPerson&&distance>.38){
      mazeCharacter(data,stage2.x,stage2.y,stage2.angle-Math.PI/2,stage2.walkPhase||0,stage2.walking,false,false,swing,stage2.jumpZ);
    }else if(!stage2.hub){
      const hand=eye.map((v,i)=>v+forward[i]*.40+right[i]*(.23-swing*.30)-up[i]*.30);
      const elbow=eye.map((v,i)=>v+forward[i]*.19+right[i]*.27-up[i]*.43);
      mazeLimb(data,elbow,hand,.045,rgb(outfit().color));mazeRound(data,hand,[.045,.06,.045],[.74,.49,.32]);
      mazeBox(data,hand[0],hand[1]+.08,hand[2],.045,.36,.025,[.65,.40,.09],0,stage2.angle+swing*1.5);
      for(let i=0;i<7;i++)mazeBox(data,hand[0]-forward[0]*.017,hand[1]-.02+i*.035,hand[2]-forward[2]*.017,.05,.006,.035,[.08,.09,.10],0,stage2.angle);
    }
    if(!stage2.hub&&(!stage2.thirdPerson||distance<=.38)){
      const grip=eye.map((v,i)=>v+forward[i]*.36-right[i]*.24-up[i]*.27),tip=grip.map((v,i)=>v+forward[i]*.16);
      mazeTube(data,grip,tip,.038,.049,[.08,.11,.14]);mazeRound(data,grip,[.046,.048,.045],[.76,.53,.38]);
      mazeRound(data,tip,[.050,.05,.05],stage2.flashlight?[.88,.87,.64]:[.2,.25,.27],null,stage2.flashlight?.7:0);
    }
    if(mazeGL.software){renderSoftwareMaze(data,eye,forward,right,up);return true}
    gl.viewport(0,0,W,H);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);gl.useProgram(mazeGL.program);
    gl.uniform3fv(uniforms.uEye,eye);gl.uniform3fv(uniforms.uForward,forward);gl.uniform3fv(uniforms.uRight,right);gl.uniform3fv(uniforms.uUp,up);gl.uniform1f(uniforms.uAspect,W/H);gl.uniform1f(uniforms.uLamp,stage2.hub||stage2.flashlight?1:0);gl.uniform1f(uniforms.uHub,stage2.hub?1:0);
    gl.bindBuffer(gl.ARRAY_BUFFER,mazeGL.buffer);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(data),gl.DYNAMIC_DRAW);gl.drawArrays(gl.TRIANGLES,0,data.length/10);
    ctx.drawImage(surface,0,0,W,H);return true;
  }
  function drawStage2(){
    ctx.setTransform(1,0,0,1,0,0);ctx.textAlign='left';ctx.textBaseline='alphabetic';ctx.shadowBlur=0;ctx.globalAlpha=1;
    renderMaze3D();
    if(!stage2.hub){const shade=ctx.createRadialGradient(W/2,H/2,120,W/2,H/2,560);shade.addColorStop(0,'transparent');shade.addColorStop(1,'rgba(8,0,12,.66)');ctx.fillStyle=shade;ctx.fillRect(0,0,W,H);}
    if(gameNow()<stage2.invuln){ctx.fillStyle='rgba(255,30,60,.13)';ctx.fillRect(0,0,W,H)}
    // Crosshair
    ctx.save();
    ctx.strokeStyle="rgba(255,255,255,.75)";
    ctx.lineWidth=2;
    ctx.beginPath();
    ctx.moveTo(W/2-8,H/2);ctx.lineTo(W/2+8,H/2);
    ctx.moveTo(W/2,H/2-8);ctx.lineTo(W/2,H/2+8);
    ctx.stroke();
    ctx.restore();

    // Titel / Steuerung
    drawRoundedRect(24,24,410,60,12,"rgba(3,8,18,.74)","rgba(118,235,255,.22)");
    ctx.fillStyle="#ffffff";
    ctx.font="900 20px system-ui";
    ctx.fillText(stage2.hub?"KLASSENZIMMER · START":"DAS VERLASSENE LABYRINTH",40,51);
    ctx.fillStyle="#7deeff";
    ctx.font="700 12px system-ui";
    ctx.fillText(stage2.hub?"Maus · WASD · Space Sprung · V Kamera · E Benutzen":"Maus · WASD · Space Sprung · V Kamera · L Lampe",40,72);
    if(stage2.hub){
      const target=hubTargets.find(t=>Math.hypot(t.x-stage2.x,t.z-stage2.y)<1.85);
      drawRoundedRect(150,H-74,660,44,12,'rgba(3,8,18,.85)');ctx.textAlign='center';ctx.fillStyle='#fff';ctx.font='bold 16px system-ui';
      ctx.fillText(target?'E · '+target.name:'Wandtafel vorne: Level wählen · Garderobe rechts: Kleidung',W/2,H-47);ctx.textAlign='left';
      const cam=mazeCamera(gameNow());
      for(const t of hubTargets){const pos=[t.x,1.9,t.z],d=pos.map((v,i)=>v-cam.eye[i]),z=d.reduce((v,n,i)=>v+n*cam.forward[i],0);if(z>.1){const px=W/2+d.reduce((v,n,i)=>v+n*cam.right[i],0)*H*.66/z,py=H/2-d.reduce((v,n,i)=>v+n*cam.up[i],0)*H*.66/z;if(px>20&&px<W-20&&py>90&&py<H-100){ctx.textAlign='center';ctx.font='bold 15px system-ui';ctx.lineWidth=5;ctx.strokeStyle='#142724';ctx.strokeText(t.id==='levels'?'LEVELAUSWAHL':'GARDEROBE',px,py);ctx.fillStyle='#fff5cf';ctx.fillText(t.id==='levels'?'LEVELAUSWAHL':'GARDEROBE',px,py);ctx.textAlign='left';}}}
    }else{drawRoundedRect(W-260,24,236,62,10,'rgba(3,8,18,.9)');ctx.fillStyle=stage2.lightHeat>.7?'#ff667c':'#b8eeec';ctx.font='bold 13px system-ui';ctx.fillText('L · LAMPE '+(stage2.flashlight?'AN':'AUS'),W-244,47);ctx.fillStyle='#293442';ctx.fillRect(W-244,60,204,8);ctx.fillStyle=stage2.lightHeat>.7?'#ff526d':'#e8c677';ctx.fillRect(W-244,60,204*stage2.lightHeat,8);}
  }


  // ================================================================
  // ETAPPE 3: SCHNELLE NEON-PIXEL-ACTION
  // Optik und Tempo erinnern an stylische Side-Scroller,
  // verwenden aber vollständig eigene Formen, Figuren und Level.
  // ================================================================
  const stage3 = {
    worldW:6800,
    x:80,y:406,w:28,h:44,
    vx:0,vy:0,
    facing:1,
    onGround:true,
    cameraX:0,
    health:3,
    invulnUntil:0,
    attackUntil:0,
    collected:0,
    pickups:[],
    enemies:[],
    platforms:[],
    exitX:6620
  };

  function resetStage3(){
    if(document.pointerLockElement===canvas)document.exitPointerLock?.();
    gameStage=3;
    stage3.x=80; stage3.y=406;
    stage3.vx=0; stage3.vy=0;
    stage3.dashUntil=0;stage3.dashReady=0;stage3.dashDir=1;
    stage3.runPhase=0;stage3.trails=[];stage3.lastTrail=0;
    stage3.lastGround=gameNow();stage3.jumpBuffer=0;
    stage3.landUntil=0;stage3.deadUntil=0;
    stage3.facing=1;
    stage3.onGround=true;
    stage3.cameraX=0;
    stage3.health=3;
    stage3.invulnUntil=0;
    stage3.attackUntil=0;
    stage3.collected=0;
    stage3.candies=[250,610,920,1320,1590,2050,2270,2620,3100,3490,3670,4250,4500,5010,5500,5820,6200,6530].map((x,i)=>({x,y:[610,920,1320,1590,3490,3670,4250,5500,5820,6200].includes(x)?({610:363,920:353,1320:353,1590:278,3490:353,3670:248,4250:343,5500:353,5820:268,6200:348}[x]):420,id:'candy-neon-'+i}));
    stage3.checkpoint=80;stage3.checkpoints=[{x:2200,lit:false},{x:4420,lit:false}];
    stage3.gaps=[{x:1040,w:145},{x:2840,w:170},{x:4770,w:160},{x:6030,w:155}];
    stage3.spikes=[{x:720,w:90},{x:1870,w:105},{x:3280,w:110},{x:4120,w:95},{x:5310,w:115},{x:6300,w:100}];
    stage3.gates=[{x:2470,phase:0},{x:3930,phase:1300},{x:5690,phase:650}];
    stage3.pickups=[
      {x:1590,y:275,label:'Mut',got:false},
      {x:3670,y:245,label:'Fokus',got:false},
      {x:5820,y:265,label:'Ziel',got:false}
    ];
    stage3.enemies=[
      [450,340,650,1],[1360,1240,1730,1],[1760,1650,1840,2],[2050,2000,2140,1],
      [2580,2530,2780,2],[3130,3050,3220,1],[3490,3420,3790,1],
      [4010,3990,4090,2],[4550,4490,4690,1],[5000,4960,5230,2],
      [5510,5460,5630,1],[5900,5830,5990,2],[6490,6430,6550,2]
    ].map(([x,min,max,hp],i)=>({x,y:414,w:28,h:36,min,max,dir:i%2?-1:1,dead:false,hp,maxHp:hp,hitUntil:0}));
    stage3.platforms=[
      {x:570,y:385,w:130,h:18},{x:880,y:375,w:145,h:18},
      {x:1300,y:375,w:150,h:18},{x:1460,y:325,w:130,h:18},{x:1560,y:300,w:130,h:18},
      {x:1990,y:370,w:150,h:18},{x:2690,y:365,w:140,h:18},
      {x:3420,y:375,w:150,h:18},{x:3540,y:320,w:130,h:18},{x:3650,y:270,w:140,h:18},
      {x:4240,y:365,w:145,h:18},{x:4590,y:375,w:160,h:18},
      {x:5450,y:375,w:150,h:18},{x:5610,y:325,w:150,h:18},{x:5780,y:290,w:140,h:18},
      {x:6150,y:370,w:130,h:18}
    ];
    keys.clear();
    stageLabel.innerHTML="<strong>BVJ 2026/27</strong> · Etappe 3: Neon-Action";
    hud.textContent=isCompactMobile() ? "♥♥♥ · ✦ 0/3 · 👾 13" : "Etappe 3/3 · ♥♥♥ · ✦ 0/3";
    updateMobileUI();
  }

  function startStage3(){
    resetStage3();
    showStageCard(
      "⚡ Etappe 3",
      "Die Schattenstadt",
      "Die Perspektive wechselt erneut: schnelle 2D-Side-Scroller-Action mit eigener Neon-Pixel-Optik. Überquere die Schattenstadt mit Abgründen, Dornen und roten Sperren. Die Sperren wechseln zwischen Rot (gefährlich) und Blau (frei); mit X kannst du durch rote Sperren dashen. Grüne Laternen sind Checkpoints. Sammle Mut, Fokus und Ziel. A/D oder ←/→ = laufen, Leertaste = springen, F = Nahkampfangriff. Shift halten = Rennen. X = Dash mit kurzem Schutz (auch in der Luft). Kurzes Drücken der Sprungtaste = kleiner Sprung; gedrückt halten = hoher Sprung.",
      "Neon-Etappe starten"
    );
  }

  function s3Jump(){
    stage3.jumpBuffer=gameNow()+120;
  }

  function s3Dash(){
    const now=gameNow();
    if(now<stage3.dashReady || stage3.deadUntil>now)return;
    stage3.dashDir=stage3.facing;
    stage3.dashUntil=now+180;stage3.dashReady=now+900;
    stage3.invulnUntil=Math.max(stage3.invulnUntil,stage3.dashUntil);
    tone(180,.18,'triangle',.24,0,false,650);
  }

  function s3Attack(){
    if(gameNow()<(stage3.attackUntil||0)+180)return;
    stage3.attackUntil=gameNow()+180;
    effect('attack');
  }

  function s3Rect(){
    return {x:stage3.x,y:stage3.y,w:stage3.w,h:stage3.h};
  }

  function s3GateOn(g,now){return (now+g.phase)%3200<1600}
  function respawnStage3(){
    stage3.x=stage3.checkpoint;stage3.y=406;stage3.vx=0;stage3.vy=0;
    stage3.health=3;stage3.deadUntil=0;stage3.invulnUntil=gameNow()+1800;
    stage3.onGround=true;stage3.dashUntil=0;stage3.dashReady=0;stage3.trails=[];
    stage3.cameraX=Math.max(0,Math.min(stage3.worldW-W,stage3.x-260));
    keys.clear();showMessage('Zurück am Checkpoint · Deine Symbole bleiben erhalten.',1800);
  }
  function hurtStage3(now,fallen=false){
    if(stage3.deadUntil||(!fallen&&now<stage3.invulnUntil))return;
    stage3.health=Math.max(0,stage3.health-1);stage3.invulnUntil=now+1000;beep(150,.15);
    if(stage3.health===0){stage3.deadUntil=now+650;showMessage('Der Schatten erwischt dich · Neustart am Checkpoint',1100);return}
    if(fallen){stage3.x=stage3.checkpoint;stage3.y=406;stage3.vx=0;stage3.vy=0;stage3.onGround=true;stage3.cameraX=Math.max(0,stage3.x-260);stage3.trails=[]}
    else{stage3.vy=-280;stage3.onGround=false}
  }
  function updateStage3(dt,now){
    if(stage3.deadUntil){if(now>=stage3.deadUntil)respawnStage3();return}
    const wasGrounded=stage3.onGround,fallSpeed=stage3.vy;
    if(wasGrounded)stage3.lastGround=now;
    if(stage3.jumpBuffer>now && now-stage3.lastGround<100){
      stage3.vy=-560;stage3.onGround=false;stage3.lastGround=-1000;stage3.jumpBuffer=0;effect('jump');
    }
    const dashing=now<stage3.dashUntil;
    let move=0;
    if(keys.has("KeyA") || keys.has("ArrowLeft")) move-=1;
    if(keys.has("KeyD") || keys.has("ArrowRight")) move+=1;

    stage3.sprinting=!!move&&(keys.has("ShiftLeft")||keys.has("ShiftRight"));
    const desired=move*(stage3.sprinting?GAME_DATA.motion.sprintSpeed:GAME_DATA.motion.walkSpeed);
    const acceleration=(move?2600:3400)*dt;
    stage3.vx+=(desired-stage3.vx)*response(dt);
    if(dashing){stage3.vx=stage3.dashDir*780;stage3.vy=0}
    else if(move)stage3.facing=Math.sign(move);
    stage3.runPhase+=Math.abs(stage3.vx)*dt*.065;
    stage3.trails=stage3.trails.filter(t=>now-t.time<230);
    if(dashing&&now-stage3.lastTrail>28){
      stage3.lastTrail=now;stage3.trails.push({x:stage3.x,y:stage3.y,facing:stage3.dashDir,phase:stage3.runPhase,time:now});
    }

    stage3.x+=stage3.vx*dt;
    stage3.x=Math.max(20,Math.min(stage3.worldW-stage3.w-20,stage3.x));

    const oldBottom=stage3.y+stage3.h;
    if(!dashing)stage3.vy+=(stage3.vy<0&&!keys.has("Space")?2450:1450)*dt;
    stage3.y+=stage3.vy*dt;
    stage3.onGround=false;

    const groundY=450;
    const overGap=stage3.gaps.some(g=>stage3.x+stage3.w*.5>g.x&&stage3.x+stage3.w*.5<g.x+g.w);
    if(stage3.y+stage3.h>=groundY&&!overGap){
      stage3.y=groundY-stage3.h;
      stage3.vy=0;
      stage3.onGround=true;
    }

    // Landen auf Plattformen.
    if(stage3.vy>=0){
      for(const p of stage3.platforms){
        const newBottom=stage3.y+stage3.h;
        const overlapsX=stage3.x+stage3.w>p.x && stage3.x<p.x+p.w;
        if(overlapsX && oldBottom<=p.y && newBottom>=p.y){
          stage3.y=p.y-stage3.h;
          stage3.vy=0;
          stage3.onGround=true;
          break;
        }
      }
    }

    if(stage3.onGround&&!wasGrounded&&fallSpeed>120){stage3.landUntil=now+130;effect('step')}

    if(stage3.y>H+90){hurtStage3(now,true);return}
    for(const cp of stage3.checkpoints){
      if(!cp.lit&&Math.abs(stage3.x-cp.x)<45&&stage3.onGround){cp.lit=true;stage3.checkpoint=cp.x;stage3.health=3;effect('win');showMessage('Checkpoint erreicht · Herzen aufgefüllt',1800)}
    }
    const heroBox=s3Rect();
    if(stage3.spikes.some(h=>rectsOverlap(heroBox,{x:h.x,y:433,w:h.w,h:17})))hurtStage3(now);
    if(stage3.gates.some(g=>s3GateOn(g,now)&&rectsOverlap(heroBox,{x:g.x,y:265,w:18,h:185})))hurtStage3(now);
    if(stage3.deadUntil)return;
    // Pickups
    for(const p of stage3.pickups){
      if(p.got) continue;
      if(Math.hypot((stage3.x+stage3.w/2)-p.x,(stage3.y+stage3.h/2)-p.y)<46){
        p.got=true;
        stage3.collected++;
        beep(830,.07);
        showMessage(`${p.label} gesammelt! ${stage3.collected}/3`,850);
      }
    }

    // Gegner
    const attacking=now<stage3.attackUntil;
    for(const e of stage3.enemies){
      if(e.dead) continue;

      const playerCenter=stage3.x+stage3.w/2;
      const enemyCenter=e.x+e.w/2;
      const dist=playerCenter-enemyCenter;

      const oldEnemyX=e.x;
      e.alert=Math.abs(dist)<300;
      if(e.alert){
        e.dir=Math.sign(dist)||e.dir;
        e.x+=e.dir*(e.maxHp===2?116:142)*dt;
      }else{
        e.x+=e.dir*62*dt;
        if(e.x<e.min){e.x=e.min;e.dir=1}
        if(e.x>e.max){e.x=e.max;e.dir=-1}
      }

      e.x=Math.max(e.min,Math.min(e.max,e.x));
      e.phase=(e.phase||0)+Math.abs(e.x-oldEnemyX)*.09;
      if(attacking&&now>(e.hitUntil||0)){
        const attackCenter=stage3.x+stage3.w/2+stage3.facing*44;
        if(Math.abs(enemyCenter-attackCenter)<48 &&
           Math.abs((e.y+e.h/2)-(stage3.y+stage3.h/2))<48){
          e.hp--;e.hitUntil=now+250;
          e.x=Math.max(e.min,Math.min(e.max,e.x+stage3.facing*28));
          e.dead=e.hp<=0;
          beep(e.dead?880:440,.055);
          burst(
            Math.max(20,Math.min(W-20,e.x-stage3.cameraX)),
            e.y+e.h/2,
            "#f04f88",14
          );
          continue;
        }
      }

      if(now>stage3.invulnUntil &&
         stage3.x<e.x+e.w && stage3.x+stage3.w>e.x &&
         stage3.y<e.y+e.h && stage3.y+stage3.h>e.y){
        hurtStage3(now);
        stage3.x=Math.max(20,stage3.x-Math.sign(dist||1)*28);
        if(stage3.deadUntil)return;
      }
    }

    // Kamera
    stage3.cameraX+=(Math.max(0,Math.min(stage3.worldW-W,stage3.x-260))-stage3.cameraX)*Math.min(1,dt*7);

    // Ziel
    if(stage3.x+stage3.w>=stage3.exitX){
      if(stage3.collected<3){
        showMessage("Dir fehlen noch Mut, Fokus oder Ziel.",900);
        stage3.x=stage3.exitX-stage3.w-8;
      }else{
        finishWholeGame();
      }
    }

    const hearts="♥".repeat(stage3.health)+"♡".repeat(3-stage3.health);
    const remaining=stage3.enemies.filter(e=>!e.dead).length;
    document.getElementById('mobileDash').classList.toggle('cooldown',false);
    hud.textContent=isCompactMobile()
      ? `${hearts} · ✦ ${stage3.collected}/3 · 👾 ${remaining}`
      : `Etappe 3/3 · ${hearts} · ✦ ${stage3.collected}/3 · Gegner ${remaining}`;
  }

  function drawPixelBuilding(x,baseY,w,h,seed,alpha){
    ctx.save();
    ctx.globalAlpha=alpha;
    ctx.fillStyle=seed%2?"#151b38":"#1d1735";
    ctx.fillRect(Math.round(x),Math.round(baseY-h),Math.round(w),Math.round(h));

    ctx.fillStyle=seed%3===0?"#3be7df":"#d2458f";
    const cols=Math.max(2,Math.floor(w/18));
    const rows=Math.max(2,Math.floor(h/26));
    for(let yy=0;yy<rows;yy++){
      for(let xx=0;xx<cols;xx++){
        if((xx+yy+seed)%3===0){
          ctx.globalAlpha=alpha*.55;
          ctx.fillRect(
            Math.round(x+7+xx*16),
            Math.round(baseY-h+10+yy*23),
            5,8
          );
        }
      }
    }
    ctx.restore();
  }

  function drawNeonEnemy(e,x,now){
    ctx.save();ctx.translate(Math.round(x+e.w/2),Math.round(e.y+e.h));ctx.scale(e.dir,1);
    const step=Math.sin(e.phase||0),bob=Math.abs(Math.cos(e.phase||0))*1.3;
    const index=stage3.enemies.indexOf(e),armor=['#ae355d','#6c57b5','#ae6542'][index%3];
    function limb(points,color,width){ctx.strokeStyle=color;ctx.lineWidth=width;ctx.lineCap='square';ctx.lineJoin='bevel';ctx.beginPath();points.forEach((p,i)=>i?ctx.lineTo(p[0],p[1]):ctx.moveTo(p[0],p[1]));ctx.stroke()}
    // Boots, articulated knees, jacket, helmet, illuminated visor and baton.
    limb([[-4,-14],[-6+step*4,-8],[step*9,-1]],'#25253c',6);
    limb([[4,-14],[5-step*4,-8],[-step*9,-1]],'#42445c',6);
    limb([[step*9,-1],[step*9+4,-1]],'#a6adba',3);
    limb([[-step*9,-1],[-step*9+4,-1]],'#a6adba',3);
    ctx.translate(e.alert?3:1,-bob);
    ctx.fillStyle=armor;ctx.fillRect(-9,-29,18,16);
    ctx.fillStyle='#212538';ctx.fillRect(-8,-15,16,4);ctx.fillStyle='#d8b367';ctx.fillRect(-2,-15,4,3);
    ctx.fillStyle='#202537';ctx.fillRect(-8,-38,16,11);
    ctx.fillStyle='#4b526c';ctx.fillRect(-7,-39,14,4);
    ctx.fillStyle=e.alert?'#ff556f':'#b998d9';ctx.fillRect(0,-33,8,3);
    if(e.maxHp===2){ctx.fillStyle='#58416d';ctx.beginPath();ctx.moveTo(-8,-36);ctx.lineTo(-13,-47);ctx.lineTo(-2,-38);ctx.fill();ctx.beginPath();ctx.moveTo(6,-36);ctx.lineTo(12,-46);ctx.lineTo(10,-35);ctx.fill()}
    if((e.hp||0)>1){ctx.fillStyle='#f38bb9';ctx.fillRect(-9,-49,18,2)}
    limb([[-6,-26],[-11,-21],[-9+step*4,-16]],armor,5);
    const hand=e.alert?[16,-23]:[10-step*4,-18];
    limb([[6,-26],[12,-22],hand],armor,5);
    limb([hand,[hand[0]+(e.alert?13:4),hand[1]-12]],'#f5b47a',3);
    ctx.fillStyle='#d4dce4';ctx.fillRect(-5,-26,4,5);
    if(e.alert){ctx.fillStyle='#ffcf73';ctx.font='bold 12px sans-serif';ctx.textAlign='center';ctx.fillText('!',0,-45)}
    ctx.restore();
  }

  function drawNeonHero(x,y,facing,phase,pose,alpha,ghost,now){
    ctx.save();ctx.globalAlpha=alpha;
    ctx.translate(Math.round(x+14),Math.round(y+44));ctx.scale(facing,1);
    const run=pose==='run',dash=pose==='dash',air=pose==='rise'||pose==='fall';
    const stride=run?gait(phase):0;
    const bob=run?Math.abs(Math.cos(phase))*2:pose==='idle'?Math.sin(now*.003)*.8:0;
    const crouch=dash?13:pose==='land'?7:0;
    const lean=dash?12:run?5:pose==='attack'?7:0;
    const cloth=ghost?'#61f4e3':outfit().color,dark=ghost?'#61f4e3':'#283047';
    const skin=ghost?'#61f4e3':'#f0c8a5',pink=ghost?'#61f4e3':outfit().scarf;
    function limb(points,color,width){ctx.strokeStyle=color;ctx.lineWidth=width;ctx.lineCap='square';ctx.lineJoin='bevel';ctx.beginPath();points.forEach((p,i)=>i?ctx.lineTo(p[0],p[1]):ctx.moveTo(p[0],p[1]));ctx.stroke()}
    const hipY=-17+crouch-bob;
    const footA=dash?[-20,-2]:air?[-10,-10]:[stride*12,-Math.max(0,stride)*7];
    const footB=dash?[8,-2]:air?[10,-5]:[-stride*12,-Math.max(0,-stride)*7];
    limb([[-3,hipY],[-6+footA[0]*.45,(hipY+footA[1])*.5],footA],dark,6);
    limb([[3,hipY],[4+footB[0]*.45,(hipY+footB[1])*.5],footB],ghost?dark:'#3d4964',6);
    limb([footA,[footA[0]+5,footA[1]]],dark,4);limb([footB,[footB[0]+5,footB[1]]],dark,4);
    ctx.save();ctx.translate(lean,crouch-bob);ctx.rotate(dash?.28:run?.13:0);
    // Scarf reacts to movement, with a different silhouette in the dash.
    limb([[-3,-33],[-16,-32+Math.sin(phase*.7)*3],[-(dash?37:run?29:20),-28+Math.sin(now*.016)*3]],pink,4);
    ctx.fillStyle=cloth;ctx.fillRect(-8,-33,16,18);ctx.fillStyle=dark;ctx.fillRect(-8,-18,16,4);
    ctx.fillStyle=skin;ctx.fillRect(-6,-44,13,12);ctx.fillStyle=dark;ctx.fillRect(-8,-46,15,6);ctx.fillRect(-9,-41,5,9);
    ctx.fillStyle=pink;ctx.fillRect(-7,-37,16,3);
    if(profile.hat==='beanie'){ctx.fillStyle=pink;ctx.fillRect(-8,-48,16,7);ctx.fillRect(-5,-51,10,4)}
    if(profile.hat==='phones'){ctx.strokeStyle='#54d8df';ctx.lineWidth=2;ctx.beginPath();ctx.arc(0,-39,8,Math.PI,Math.PI*2);ctx.stroke();ctx.fillStyle='#54d8df';ctx.fillRect(-9,-43,4,8)}
    const hand=pose==='attack'?[25,-23]:dash?[15,-18]:air?[9,-28]:[8-stride*7,-21];
    limb([[4,-30],[11,-25],hand],cloth,5);
    limb([[-5,-30],[-10,-23],[-8+stride*7,-18]],ghost?cloth:'#a8b9ce',4);
    const bladeAngle=pose==='attack'?-1.3+(1-(stage3.attackUntil-now)/180)*2.5:dash?-.3:-.85;
    const tx=hand[0]+Math.cos(bladeAngle)*32,ty=hand[1]+Math.sin(bladeAngle)*32;
    limb([hand,[tx,ty]],ghost?cloth:'#8dfff0',2);
    ctx.restore();ctx.restore();
  }

  function drawShadowLandscape(cam,now){
    // Industrial silhouettes and watching eyes behind the traversable foreground.
    for(let i=0;i<25;i++){
      const x=i*290-cam*.65;if(x<-120||x>W+120)continue;
      ctx.fillStyle='#0a0c16';ctx.fillRect(x,210+(i%3)*25,19,240);
      ctx.strokeStyle='#171928';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(x+8,220);ctx.lineTo(x+67,255);ctx.lineTo(x+67,330);ctx.stroke();
      ctx.fillStyle='rgba(230,98,112,.38)';ctx.fillRect(x+35,320,4,2);ctx.fillRect(x+43,320,4,2);
    }
    for(const gap of stage3.gaps){const x=gap.x-cam;if(x>W||x+gap.w<0)continue;
      ctx.fillStyle='#02030a';ctx.fillRect(x,450,gap.w,90);ctx.fillStyle='#b44869';ctx.fillRect(x-3,447,4,5);ctx.fillRect(x+gap.w,447,4,5);
      ctx.fillStyle='rgba(230,63,98,.3)';ctx.fillRect(x+gap.w*.42,505,5,3);ctx.fillRect(x+gap.w*.42+13,505,5,3);
    }
    for(const trap of stage3.spikes){const x=trap.x-cam;if(x>W||x+trap.w<0)continue;
      ctx.fillStyle='#f58d99';for(let i=0;i<trap.w;i+=15){ctx.beginPath();ctx.moveTo(x+i,450);ctx.lineTo(x+i+7,432);ctx.lineTo(x+i+14,450);ctx.fill()}
    }
    for(const gate of stage3.gates){const x=gate.x-cam;if(x<-40||x>W+40)continue;const on=s3GateOn(gate,now);
      ctx.fillStyle='#30364c';ctx.fillRect(x-6,256,30,12);ctx.fillRect(x-6,444,30,6);
      ctx.fillStyle=on?'#f25d7c':'#68d7da';ctx.fillRect(x,264,18,on?180:4);
      if(on){ctx.fillStyle='rgba(238,65,106,.12)';ctx.fillRect(x-10,265,38,179)}
      drawReadableLabel(on?'SHIFT →':'FREI',x+9,245,{font:'bold 10px system-ui',bg:'rgba(5,8,18,.85)'});
    }
    for(const cp of stage3.checkpoints){const x=cp.x-cam;if(x<-70||x>W+70)continue;
      ctx.fillStyle='#293a43';ctx.fillRect(x,346,8,104);ctx.fillStyle=cp.lit?'#6ce4b0':'#d3d8b3';ctx.fillRect(x-10,326,28,25);
      ctx.fillStyle='rgba(105,225,179,.08)';ctx.beginPath();ctx.arc(x+4,340,54,0,Math.PI*2);ctx.fill();
      drawReadableLabel(cp.lit?'GESICHERT':'CHECKPOINT',x+4,317,{font:'bold 10px system-ui',bg:'rgba(5,8,18,.8)'});
    }
  }
  function drawStage3(){
    const now=gameNow();
    ctx.setTransform(1,0,0,1,0,0);
    ctx.textAlign="left";
    ctx.textBaseline="alphabetic";
    ctx.shadowBlur=0;
    ctx.globalAlpha=1;
    ctx.clearRect(0,0,W,H);
    ctx.imageSmoothingEnabled=false;

    // Himmel
    ctx.fillStyle="#090817";
    ctx.fillRect(0,0,W,H);
    ctx.fillStyle="#18102b";
    ctx.fillRect(0,250,W,290);

    // Mond / Neon-Sonne
    ctx.save();
    ctx.globalAlpha=.8;
    ctx.fillStyle="#853f57";
    ctx.beginPath();ctx.arc(760,115,58,0,Math.PI*2);ctx.fill();
    ctx.fillStyle="#090817";
    for(let y=80;y<150;y+=11) ctx.fillRect(700,y,120,4);
    ctx.restore();

    // Parallax city
    for(let layer=0;layer<2;layer++){
      const factor=layer===0?.18:.38;
      const base=layer===0?350:410;
      const alpha=layer===0?.42:.72;
      for(let i=0;i<14;i++){
        const worldX=i*210+(layer*90);
        const sx=worldX-stage3.cameraX*factor;
        const wrap=((sx+250)%2900+2900)%2900-250;
        drawPixelBuilding(wrap,base,110+(i%3)*35,110+(i%5)*28,i+layer*7,alpha);
      }
    }

    const cam=stage3.cameraX;

    // Boden
    ctx.fillStyle="#10131f";
    ctx.fillRect(0,450,W,90);
    ctx.fillStyle="#3ce1d0";
    ctx.fillRect(0,450,W,3);
    ctx.fillStyle="rgba(210,58,137,.18)";
    for(let x=-((cam*.7)%60);x<W;x+=60) ctx.fillRect(x,478,28,3);

    drawShadowLandscape(cam,now);
    // Plattformen
    for(const p of stage3.platforms){
      const sx=p.x-cam;
      if(sx>W+100 || sx+p.w<-100) continue;
      ctx.fillStyle="#24233b";
      ctx.fillRect(sx,p.y,p.w,p.h);
      ctx.fillStyle="#41e5d7";
      ctx.fillRect(sx,p.y,p.w,3);
      ctx.fillStyle="#d34c91";
      for(let x=sx+8;x<sx+p.w-4;x+=26) ctx.fillRect(x,p.y+8,12,3);
    }


    // Pickups
    for(const p of stage3.pickups){
      if(p.got) continue;
      const sx=p.x-cam;
      if(sx<-80 || sx>W+80) continue;
      const pulse=1+Math.sin(now*.006+p.x)*.12;
      ctx.save();
      ctx.translate(sx,p.y);
      ctx.scale(pulse,pulse);
      ctx.shadowColor="#f0cf55";
      ctx.shadowBlur=18;
      ctx.fillStyle="#f4d75f";
      ctx.beginPath();
      ctx.moveTo(0,-15);ctx.lineTo(13,0);ctx.lineTo(0,15);ctx.lineTo(-13,0);ctx.closePath();
      ctx.fill();
      ctx.restore();
      drawReadableLabel(p.label,sx,p.y+37,{font:"800 11px system-ui",bg:"rgba(20,12,32,.82)"});
    }

    for(const candy of stage3.candies||[])if(!profile.claimed[candy.id]&&Math.abs(candy.x-cam-W/2)<W)drawCandy(candy.x-cam,candy.y,.9);
    // Gegner
    for(const e of stage3.enemies){
      if(e.dead) continue;
      const sx=e.x-cam;
      if(sx<-80 || sx>W+80) continue;

      drawNeonEnemy(e,sx,now);
    }

    // Ausgang
    const exitSX=stage3.exitX-cam;
    ctx.save();
    ctx.shadowColor="#62f3ca";
    ctx.shadowBlur=20;
    ctx.fillStyle=stage3.collected===3?"#42e7bc":"#49545a";
    ctx.fillRect(exitSX,337,38,113);
    ctx.fillStyle="#0d1420";
    ctx.fillRect(exitSX+9,350,20,82);
    ctx.restore();
    drawReadableLabel(
      stage3.collected===3?"WEIHNACHTEN":"GESPERRT",
      exitSX+19,330,
      {font:"900 11px system-ui",bg:"rgba(12,17,29,.86)"}
    );

    // Original articulated pixel hero; poses follow velocity and action state.
    for(const t of stage3.trails){
      drawNeonHero(t.x-cam,t.y,t.facing,t.phase,'dash',(1-(now-t.time)/230)*.38,true,now);
    }
    const pose=now<stage3.dashUntil?'dash':now<stage3.attackUntil?'attack':
      !stage3.onGround?(stage3.vy<0?'rise':'fall'):now<stage3.landUntil?'land':
      Math.abs(stage3.vx)>15?'run':'idle';
    const alpha=now<stage3.invulnUntil&&pose!=='dash'&&Math.floor(now/80)%2===0?.4:1;
    drawNeonHero(stage3.x-cam,stage3.y,stage3.facing,stage3.runPhase,pose,alpha,false,now);
    if(pose==='attack'){
      const progress=1-(stage3.attackUntil-now)/180;
      ctx.save();ctx.translate(stage3.x-cam+14,stage3.y+20);ctx.scale(stage3.facing,1);
      ctx.strokeStyle='#efffff';ctx.shadowColor='#5cf5e4';ctx.shadowBlur=14;
      ctx.lineWidth=5;ctx.beginPath();ctx.arc(9,0,49,-1.5+progress*.7,.8+progress*.7);ctx.stroke();
      ctx.strokeStyle='#d34c91';ctx.lineWidth=2;ctx.beginPath();ctx.arc(9,0,57,-1.3+progress*.7,.4+progress*.7);ctx.stroke();ctx.restore();
    }
    // Dash cooldown stays visible beside the control legend.
    const ready=Math.max(0,Math.min(1,1-(stage3.dashReady-now)/900));
    drawRoundedRect(24,91,116,26,7,'rgba(8,7,18,.8)');
    ctx.fillStyle='#374158';ctx.fillRect(32,110,98,3);
    ctx.fillStyle=ready===1?'#71f5da':'#dc5b9f';ctx.fillRect(32,110,98*ready,3);
    ctx.font='bold 11px system-ui';ctx.fillText(ready===1?'RENNEN HALTEN BEREIT':'DASH LÄDT',32,104);

    // Speed lines while moving
    if(Math.abs(stage3.vx)>10){
      ctx.save();
      ctx.strokeStyle="rgba(116,240,226,.18)";
      ctx.lineWidth=2;
      for(let i=0;i<10;i++){
        const y=120+(i*41+Math.floor(now*.05))%300;
        const x=(i*113+Math.floor(now*.18))%W;
        ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x-stage3.facing*34,y);ctx.stroke();
      }
      ctx.restore();
    }

    // Slow moving fog adds atmosphere while leaving the ground readable.
    ctx.save();ctx.fillStyle='rgba(159,152,190,.065)';
    for(let i=0;i<7;i++){ctx.beginPath();ctx.ellipse(((i*210-now*.012)%1250+1250)%1250-120,405+Math.sin(i+now*.0005)*20,160,19,0,0,Math.PI*2);ctx.fill()}
    ctx.restore();
    // Scanlines
    ctx.save();
    ctx.globalAlpha=.08;
    ctx.fillStyle="#ffffff";
    for(let y=0;y<H;y+=4) ctx.fillRect(0,y,W,1);
    ctx.restore();

    // Titel
    drawRoundedRect(22,22,390,61,10,"rgba(8,7,18,.82)","rgba(226,74,141,.30)");
    ctx.fillStyle="#ffffff";
    ctx.font="900 20px system-ui";
    ctx.fillText("ETAPPE 3 · SCHATTENSTADT",38,49);
    ctx.fillStyle="#70eadc";
    ctx.font="700 12px system-ui";
    ctx.fillText("A/D laufen · Space springen · F Angriff · Shift Rennen · X Dash",38,71);
    const zone=stage3.x<2200?'01 · Verlassenes Viertel':stage3.x<4420?'02 · Schattenfabrik':'03 · Das letzte Tor';
    drawReadableLabel(zone,W/2,34,{font:'bold 12px system-ui',bg:'rgba(7,8,16,.8)'});
    ctx.fillStyle='#253043';ctx.fillRect(W-210,30,182,5);ctx.fillStyle='#d479a8';ctx.fillRect(W-210,30,182*Math.min(1,stage3.x/stage3.exitX),5);
  }

  function finishWholeGame(){
    if(finished) return;
    awardCandy('finish-neon',6);effect("win");
    finished=true;
    started=false;
    keys.clear();
    const total=formatTime((gameNow()-startTime)/1000);
    overlay.innerHTML=`
      <div class="card">
        <h1>🎄 Geschafft!</h1>
        <h2>Drei Welten – ein Weg durchs BVJ</h2>
        <p>Du hast die <strong>2D-Welt</strong>, das <strong>3D-Labyrinth</strong> und die <strong>Neon-Action-Etappe</strong> abgeschlossen.</p>
        <p>Gesamtzeit: <strong>${total}</strong></p>
        <p class="small">Viventa · BVJ 2026/27 · Technology &amp; Design</p>
        <button id="againBtn">Zum Spielmenü</button>
      </div>`;
    overlay.style.display="flex";
    document.getElementById("againBtn").onclick=()=>openGameMenu();
  }

  function drawCurrentStage(){
    if(gameStage===1){draw();drawSchoolMission();}
    else if((gameStage===2||gameStage===0)) drawStage2();
    else drawStage3();
  }

  function loop(frameNow){
    const now=gameNow();
    const dt=Math.min(((gameStage===2||gameStage===0) && mazeGL?.software) ? .10 : .032,(now-last)/1000);
    last=now;

    updateAudio(now);
    if(!paused)updateTransitionFX(now);

    if(started && !paused && !finished && !transitionFX.active && !document.hidden){
      if(gameStage===1){
        let dx=0,dy=0;
        if(keys.has("ArrowLeft")||keys.has("KeyA")) dx-=1;
        if(keys.has("ArrowRight")||keys.has("KeyD")) dx+=1;
        if(keys.has("ArrowUp")||keys.has("KeyW")) dy-=1;
        if(keys.has("ArrowDown")||keys.has("KeyS")) dy+=1;

        setFacingFromVector(dx,dy);
        if(dx&&dy){dx*=Math.SQRT1_2;dy*=Math.SQRT1_2}

        movePlayer(dx,dy,dt);
        updateSchoolMission(dt);
        updateEnemies(dt,now);
        updateProjectiles(dt);
        updateParticles(dt);

        const exitHit={...state.exit,y:state.exit.y+Math.sin(now*0.0032)*5};
        if(rectsOverlap(player,exitHit)){
          nextLevel();
        }

        const hearts = "♥".repeat(player.health) + "♡".repeat(player.maxHealth-player.health);
        const jumpMark=isJumping(now)?"↑":"&nbsp;";
        const buttonDone=(state.redButtons||[]).filter(b=>b.pressed).length;
        const buttonAll=(state.redButtons||[]).length;
        if(isCompactMobile()){
          hud.innerHTML=`${hearts}<span class="jump-indicator" aria-hidden="true">${jumpMark}</span> · 2D ${levelIndex+1}/3 · 🎒 ${state.mission.done?"✓":"Mission"} · 🔴 ${buttonDone}/${buttonAll}`;
        }else{
          hud.innerHTML=`${hearts}<span class="jump-indicator" aria-hidden="true">${jumpMark}</span> · Etappe 1/3 · Level ${levelIndex+1}/3 · ${state.mission.done?"✓":"Mission"} · 🔴 ${buttonDone}/${buttonAll}`;
        }
      }else if((gameStage===2||gameStage===0)){
        updateStage2(dt);
      }else{
        updateStage3(dt,now);
      }
    }

    if(gameStage===1) updateSnow(dt);

    if((!started || finished) && gameStage===1){
      updateParticles(dt);
      updateProjectiles(dt);
    }

    if(started&&!paused&&!finished){collectCandies()}
    drawCurrentStage();
    drawReadableLabel('🍬 '+profile.candies,W-55,H-18,{font:'bold 14px system-ui',bg:'rgba(9,15,25,.9)'});

    if(transitionFX.active){
      drawPixelTransition(now);
    }

    requestAnimationFrame(loop);
  }

  function keyDown(code){
    if(code==='Escape'||code==='KeyP'){if(paused)resumeGame();else if(started&&!finished)openGameMenu();return}
    if(paused||!started||finished||transitionFX.active)return;
    if(code==="ShiftLeft" || code==="ShiftRight"){keys.add(code);return;}
    if(code==="KeyL"&&gameStage===2&&!keys.has(code))toggleFlashlight();

    if(code==='KeyV'&&keys.has(code))return;
    keys.add(code);

    if(gameStage===1){
      if(code==="KeyE") interact();
      if(code==="Space") jump();
      if(code==="KeyF") attack();
      if(code==="KeyR" && started && !finished) resetLevel();
    }else if((gameStage===2||gameStage===0)){
      if(code==="KeyV" && started && !finished) toggleMazeCamera();
      if(code==="KeyF" && started && !finished) s2Attack();
      if(code==='Space')s2Jump();
      if(code==='KeyE'&&gameStage===0)hubInteract();
      if(code==="KeyR" && started && !finished){if(gameStage===0)enterClassroom();else resetStage2()}
    }else if(gameStage===3){
      if(code==="KeyX")s3Dash();
      if(code==="Space" && started && !finished) s3Jump();
      if(code==="KeyF" && started && !finished) s3Attack();
      if(code==="KeyR" && started && !finished) resetStage3();
    }
  }

  function keyUp(code){
    keys.delete(code);
  }

  // Shift wird absichtlich abgefangen, damit der Browser oder ein fokussiertes
  // Element damit keine eigene Aktion / Scrollbewegung auslösen kann.
  window.addEventListener("keydown",e=>{
    if(e.code==="ShiftLeft" || e.code==="ShiftRight"){
      e.preventDefault();
      e.stopPropagation();
      keys.delete("ShiftLeft");
      keys.delete("ShiftRight");
      if(!e.repeat)keyDown(e.code);
      return;
    }

    if(["ArrowUp","ArrowDown","ArrowLeft","ArrowRight","Space"].includes(e.code)){
      e.preventDefault();
    }

    if(!e.repeat) keyDown(e.code);
  }, true);

  window.addEventListener("keyup",e=>{
    if(e.code==="ShiftLeft" || e.code==="ShiftRight"){
      e.preventDefault();
      e.stopPropagation();
      keys.delete("ShiftLeft");
      keys.delete("ShiftRight");
      return;
    }
    keyUp(e.code);
  }, true);


  // Ein Daumen genügt: analoger Joystick mit 8 Richtungen.
  // Ist nur im Querformat sichtbar; Tastatur- und Hochformatsteuerung bleiben erhalten.
  const joystick=document.getElementById("joystick");
  const joyKnob=document.getElementById("joyKnob");
  const joyCodes=["ArrowLeft","ArrowRight","ArrowUp","ArrowDown"];
  let joystickPointer=null;
  function stopJoystick(){
    joystickPointer=null;
    joyKnob.style.transform="translate(0px,0px)";
    joyCodes.forEach(code=>keys.delete(code));
  }
  function positionJoystick(e){
    const rect=joystick.getBoundingClientRect();
    const centerX=rect.left+rect.width/2;
    const centerY=rect.top+rect.height/2;
    const maxRadius=Math.min(rect.width,rect.height)*.31;
    const vx=e.clientX-centerX, vy=e.clientY-centerY;
    const distance=Math.hypot(vx,vy);
    const factor=distance>maxRadius ? maxRadius/distance : 1;
    const x=vx*factor, y=vy*factor;
    joyKnob.style.transform=`translate(${Math.round(x)}px,${Math.round(y)}px)`;
    const threshold=maxRadius*.28;
    keys.delete("ArrowLeft"); keys.delete("ArrowRight");
    keys.delete("ArrowUp"); keys.delete("ArrowDown");
    if(x < -threshold) keys.add("ArrowLeft");
    if(x > threshold) keys.add("ArrowRight");
    if(y < -threshold) keys.add("ArrowUp");
    if(y > threshold) keys.add("ArrowDown");
  }
  joystick.addEventListener("pointerdown",e=>{
    e.preventDefault();
    if(joystickPointer!==null || !started || paused || finished || transitionFX.active) return;
    joystickPointer=e.pointerId;
    try{joystick.setPointerCapture(e.pointerId)}catch(_){}
    positionJoystick(e);
  });
  joystick.addEventListener("pointermove",e=>{
    if(e.pointerId!==joystickPointer) return;
    e.preventDefault();
    positionJoystick(e);
  });
  ["pointerup","pointercancel","lostpointercapture"].forEach(type=>{
    joystick.addEventListener(type,e=>{
      if(joystickPointer===null || e.pointerId!==joystickPointer) return;
      if(e.cancelable) e.preventDefault();
      stopJoystick();
    });
  });

  document.querySelectorAll(".ctrl").forEach(el=>{
    let code=el.dataset.key;
    const down=e=>{
      code=el.dataset.key;
      e.preventDefault();
      try{el.setPointerCapture(e.pointerId)}catch(_){}
      el.classList.add("pressed");
      keyDown(code);
    };
    const up=e=>{
      e.preventDefault();
      el.classList.remove("pressed");
      keyUp(code);
      try{if(el.hasPointerCapture?.(e.pointerId)) el.releasePointerCapture(e.pointerId)}catch(_){}
    };
    el.addEventListener("pointerdown",down);
    el.addEventListener("pointerup",up);
    el.addEventListener("pointercancel",up);
    el.addEventListener("lostpointercapture",()=>{
      el.classList.remove("pressed");
      keyUp(code);
    });
  });

  document.getElementById("gamebox").addEventListener("contextmenu",e=>e.preventDefault());

  window.addEventListener("blur",()=>{
    if(started&&!paused&&!finished)openGameMenu();
    stopJoystick();
    keys.clear();
    document.querySelectorAll(".ctrl.pressed").forEach(el=>el.classList.remove("pressed"));
  });

  window.addEventListener("resize",updateMobileUI);
  window.addEventListener("orientationchange",()=>{
    stopJoystick();
    keys.clear();
    setTimeout(updateMobileUI,80);
  });

  function orbitMaze(dx,dy){
    stage2.cameraYaw=(stage2.cameraYaw??stage2.angle)+dx;
    stage2.pitch=Math.max(-.85,Math.min(.65,(stage2.pitch||0)-dy));
    if(!stage2.thirdPerson)stage2.angle=stage2.cameraYaw;
  }
  let cameraDrag=null;
  canvas.addEventListener('pointerdown',event=>{
    if((gameStage!==2&&gameStage!==0)||!started||paused||finished)return;
    unlockAudio();event.preventDefault();
    if(event.pointerType==='touch'){cameraDrag={id:event.pointerId,x:event.clientX,y:event.clientY};try{canvas.setPointerCapture(event.pointerId)}catch(_){}return}
    try{const request=canvas.requestPointerLock?.();request?.catch?.(()=>showMessage('Maus über dem Spielfeld bewegen – freier Blick ist aktiv.',1800))}catch(_){}
  });
  canvas.addEventListener('pointermove',event=>{
    if(paused||!started||(gameStage!==2&&gameStage!==0))return;
    if(cameraDrag&&event.pointerId===cameraDrag.id){orbitMaze((event.clientX-cameraDrag.x)*.005,(event.clientY-cameraDrag.y)*.005);cameraDrag.x=event.clientX;cameraDrag.y=event.clientY}
    else if(event.pointerType==='mouse'&&document.pointerLockElement!==canvas)orbitMaze((event.movementX||0)*.0025,(event.movementY||0)*.0025);
  });
  for(const type of ['pointerup','pointercancel','lostpointercapture'])canvas.addEventListener(type,()=>{cameraDrag=null});
  canvas.addEventListener('wheel',event=>{if((gameStage===2||gameStage===0)&&started&&!paused&&stage2.thirdPerson){event.preventDefault();stage2.zoom=Math.max(.65,Math.min(2.6,(stage2.zoom||1.9)+event.deltaY*.002))}},{passive:false});
  document.addEventListener('mousemove',event=>{if(document.pointerLockElement===canvas&&(gameStage===2||gameStage===0)&&started&&!paused)orbitMaze(event.movementX*.0025,event.movementY*.0025)});

  function enterClassroom(){
    if(paused){pausedTotal+=performance.now()-pauseRealAt;paused=false}
    transitionFX.active=false;transitionFX.onSwitch=null;keys.clear();started=true;finished=false;overlay.style.display='none';
    resetStage2(true);stageLabel.innerHTML='<strong>BVJ 2026/27</strong> · Klassenzimmer';updateMobileUI();last=gameNow();
    showMessage('Willkommen! Gehe zur Wandtafel und drücke E.',3500);
  }
  function resumeGame(){
    if(!started||finished)return;
    if(paused){pausedTotal+=performance.now()-pauseRealAt;paused=false}
    keys.clear();overlay.style.display='none';unlockAudio();last=gameNow();
  }
  function newGame(stage=1){
    if(paused){pausedTotal+=performance.now()-pauseRealAt;paused=false}
    transitionFX.active=false;transitionFX.onSwitch=null;keys.clear();
    beginGame();
    if(stage===2)resetStage2();if(stage===3)resetStage3();
    showMessage(stage===3?'Schattenstadt · Shift / ⇧ = Rennen · X = Dash · P = Pause':'Viel Erfolg! Menü / P = Pause',2000);
  }
  function openGameMenu(view='home'){
    if(started&&!finished&&!paused){pauseRealAt=performance.now();paused=true}
    keys.clear();stopJoystick();cameraDrag=null;
    if(document.pointerLockElement===canvas)document.exitPointerLock?.();
    menuView=view;overlay.style.display='flex';
    const canResume=started&&!finished;
    const heading=view==='levels'?'Wähle deine Etappe':view==='shop'?'Deine Garderobe':view==='help'?'So spielst du':view==='settings'?'Ton & Anzeige':canResume?'Kurze Pause?':'Christmas Escape';
    let body='';
    if(view==='home')body=`<p class="subtitle">Drei Welten auf dem Weg zur Lehrstelle. Entkomme dem Stress und erreiche Weihnachten.</p>
      <div class="menu-actions">${canResume?'<button data-menu="resume">▶ Weiterspielen</button>':''}<button data-menu="classroom">Zum Klassenzimmer</button>${canResume?'<button class="menu-secondary" data-menu="restart">Etappe neu starten</button>':''}</div>

      <div class="menu-actions"><button class="menu-secondary" data-menu="help">Steuerung</button><button class="menu-secondary" data-menu="settings">Einstellungen</button></div>`;
    if(view==='levels')body=`<p class="subtitle">Dein Outfit begleitet dich durch alle Welten.</p>      <div class="menu-grid"><button class="stage-choice" data-stage-start="1">01 · Schule<small>Werkstatt · Drohne · Gespräch</small></button><button class="stage-choice" data-stage-start="2">02 · Labyrinth<small>3D · Das Stress-Monster</small></button><button class="stage-choice" data-stage-start="3">03 · Schattenstadt<small>Schwer · Springen & Dash</small></button></div><div class="menu-actions"><button data-menu="new">Ganzes Abenteuer starten</button><button data-menu="resume">Zurück ins Klassenzimmer</button></div>`;
    if(view==='shop')body=`<p class="subtitle">🍬 ${profile.candies} Bonbons · Sammle Bonbons in allen Etappen.</p><div class="menu-grid">${cosmetics.map(c=>{const own=profile.owned.includes(c.id),equipped=profile[c.kind]===c.id;return `<button class="stage-choice" data-buy="${c.id}" ${!own&&profile.candies<c.price?'disabled':''}><span style="display:inline-block;width:18px;height:18px;border-radius:6px;background:${c.color||'#95a8ba'}"></span> ${c.name}<small>${equipped?'✓ Ausgerüstet':own?'Anziehen':c.price+' 🍬 · Kaufen & anziehen'}</small></button>`}).join('')}</div><p class="small">${saveAvailable?'Kleidung und Bonbons werden in diesem Browser gespeichert.':'Speichern ist hier gesperrt. Kleidung und Bonbons bleiben für diese Sitzung erhalten.'}</p><button data-menu="resume">Zurück ins Klassenzimmer</button>`;
    if(view==='help')body=`<div class="help-grid"><div><strong>Computer</strong><br>WASD / Pfeile: bewegen<br>Space: springen · F: angreifen<br>E: Mission / Schalter benutzen<br><strong>Shift halten: Rennen · X: Dash in Etappe 3</strong><br>P / Esc: Pause</div><div><strong>Handy</strong><br>Linker Daumen: Joystick<br>Rechts: Nehmen, Sprung, Angriff<br><strong>⇧ halten: Rennen · X: Dash</strong><br>Sprung halten = höher springen<br>Querformat bietet mehr Platz.</div><div><strong>3D-Kamera</strong><br>Maus bewegen · Klick fängt Maus ein<br>Handy: auf Bild wischen<br>V oder Kamera-Taste: Ansicht<br>Mausrad: Zoom · Q/C: drehen<br>E: Wandtafel / Garderobe benutzen</div><div><strong>Schattenstadt</strong><br>Alle drei Symbole sammeln.<br>Über Abgründe und Dornen springen.<br>Rote Sperren: warten oder dashen.<br>Grüne Laternen sichern den Weg.</div></div><button data-menu="home">Zurück</button>`;
    if(view==='settings')body=`<p class="subtitle">Die Musik der Schattenstadt bleibt im bisherigen Techno-Stil. Schule und Labyrinth haben neue Musik.</p><div class="menu-actions"><button data-menu="music">Musik: ${sound.music?'an':'aus'}</button><button data-menu="fx">Geräusche: ${sound.fx?'an':'aus'}</button><button class="menu-secondary" data-menu="full">Vollbild</button></div><p class="small">Falls Vollbild auf deinem Handy nicht unterstützt wird, spiele direkt im Browser im Querformat.</p><button data-menu="home">Zurück</button>`;
    overlay.innerHTML=`<div class="card menu-card"><div class="menu-kicker">Viventa · BVJ 2026/27</div><h1>${heading}</h1>${body}<p class="small">Klassenzimmer · Garderobe · Bonbons · Drei Welten</p></div>`;
    overlay.querySelectorAll('[data-menu]').forEach(button=>button.onclick=()=>{
      const action=button.dataset.menu;
      if(action==='classroom')enterClassroom();else if(action==='resume')resumeGame();else if(action==='new')newGame(1);
      else if(action==='restart'){const stage=gameStage;resumeGame();if(stage===0)enterClassroom();if(stage===1)resetLevel();if(stage===2)resetStage2();if(stage===3)resetStage3()}
      else if(action==='music'||action==='fx'){document.getElementById(action==='music'?'musicToggle':'fxToggle').click();openGameMenu('settings')}
      else if(action==='full')toggleFullscreen();else openGameMenu(action);
    });
    overlay.querySelectorAll('[data-buy]').forEach(button=>button.onclick=()=>{purchaseCosmetic(button.dataset.buy);openGameMenu('shop')});
    overlay.querySelectorAll('[data-stage-start]').forEach(button=>button.onclick=()=>newGame(Number(button.dataset.stageStart)));
  }
  async function toggleFullscreen(){
    try{if(document.fullscreenElement)await document.exitFullscreen();else if(document.documentElement.requestFullscreen)await document.documentElement.requestFullscreen();else showMessage('Bitte drehe dein Handy ins Querformat.',2300)}catch(_){showMessage('Vollbild nicht verfügbar · Querformat verwenden.',2300)}
  }
  document.getElementById('menuToggle').onclick=()=>paused?resumeGame():openGameMenu();
  document.getElementById('fullToggle').onclick=toggleFullscreen;
  function beginGame(){
    unlockAudio();
    // Schutz gegen den zusätzlichen synthetischen Click nach einem Touch.


    gameStage=1;
    started=true;
    finished=false;
    levelIndex=0;
    overlay.style.display="none";
    startTime=gameNow();
    stageLabel.innerHTML="<strong>BVJ 2026/27</strong> · Etappe 1: 2D";
    updateMobileUI();
    resetLevel();
  }

  startBtn.addEventListener("click",beginGame);

  // Auf iPhone/Android direkt auf das Loslassen des Fingers reagieren.
  // Dadurch hängt der Start nicht davon ab, ob der Browser danach noch
  // einen synthetischen Click erzeugt.
  startBtn.addEventListener("pointerup",e=>{
    if(e.pointerType==="touch"){
      e.preventDefault();
      beginGame();
    }
  });

  resetLevel();
  updateMobileUI();
  enterClassroom();
  requestAnimationFrame(loop);
})();
